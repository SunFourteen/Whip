/* Git Repo - core: repository state and actions, no DOM.
 * Renderers handle the path input and drawing; every action goes through this core. */
(function () {
  'use strict';

  var repo = '';
  var data = null;
  var busy = false;
  var msg = '';
  var msgErr = false;
  var subs = [];

  function shq(s) { return "'" + String(s == null ? '' : s).replace(/'/g, "'\\''") + "'"; }
  function run(cmd, cwd) {
    var opts = { timeoutMs: 12000 };
    if (cwd) opts.cwd = cwd;
    var r = JSON.parse(SshBridge.run(cmd, JSON.stringify(opts)) || '{}');
    if (!r || !r.ok) throw new Error((r && r.error) || 'ssh');
    return r.stdout || '';
  }
  function git(args) { return run('git -C ' + shq(repo) + ' ' + args); }
  function expand(p) {
    p = String(p || '').trim();
    if (!p) return '~';
    if (p === '~' || p.indexOf('~/') === 0) {
      var home = '';
      try { home = run('printf %s "$HOME"').trim(); } catch (e) {}
      if (home) p = home + (p === '~' ? '' : p.slice(1));
    }
    return p;
  }
  function codeOf(xy) {
    if (!xy) return '?';
    if (xy === '??') return '?';
    var X = xy.charAt(0), Y = xy.charAt(1);
    return (Y !== ' ' && Y !== '?') ? Y : X;
  }

  function notify() {
    subs.forEach(function (f) { try { f(data, msg, msgErr); } catch (e) {} });
  }

  function load(show) {
    if (busy || !repo) return;
    busy = true;
    if (show) { msg = 'Loading…'; msgErr = false; }
    try {
      var branch = git('symbolic-ref --short -q HEAD 2>/dev/null || git rev-parse --short HEAD').trim();
      var head = git('log -1 --pretty=%s 2>/dev/null').trim();
      var raw = git('status --porcelain=v1 -z 2>&1');
      var files = [];
      if (raw) {
        raw.split('\0').forEach(function (e) {
          if (!e) return;
          if (e.length >= 4 && e.charAt(2) === ' ') {
            files.push({ xy: e.slice(0, 2), path: e.slice(3) });
          } else {
            files.push({ xy: '??', path: e });
          }
        });
      }
      var staged = 0, unstaged = 0, untracked = 0, conflict = false;
      files.forEach(function (f) {
        if (f.xy === '??') untracked++;
        else {
          if (f.xy.charAt(0) !== ' ' && f.xy.charAt(0) !== '?') staged++;
          if (f.xy.charAt(1) !== ' ' && f.xy.charAt(1) !== '?') unstaged++;
          if (f.xy.indexOf('U') >= 0) conflict = true;
        }
      });
      var commits = [];
      try {
        git('log -8 --pretty=%h%x09%s 2>/dev/null').split('\n').forEach(function (l) {
          var t = l.split('\t');
          if (t.length >= 2) commits.push({ h: t[0], s: t.slice(1).join('\t') });
        });
      } catch (e) {}
      data = { repo: repo, branch: branch || '(detached)', head: head,
        files: files.slice(0, 8), totalFiles: files.length,
        staged: staged, unstaged: unstaged, untracked: untracked,
        conflict: conflict, commits: commits };
      msg = '';
      msgErr = false;
    } catch (e) {
      data = null;
      msg = 'Not a git repo: ' + repo;
      msgErr = true;
    }
    busy = false;
    notify();
  }

  function open(path, show) {
    repo = expand(path);
    try { SshBridge.prefsSet('git_repo', repo); } catch (e) {}
    load(show !== false);
  }

  function act(a) {
    if (!repo) return;
    msg = (a === 'refresh' ? 'Refreshing…' : a + '…');
    msgErr = false;
    notify();
    try {
      if (a === 'fetch') git('fetch --all --prune');
      else if (a === 'pull') git('pull --ff-only');
      else if (a === 'push') git('push');
      else if (a === 'stage') git('add -A');
      msg = a === 'refresh' ? '' : a + ' ok';
      msgErr = false;
      load(true);
    } catch (e) {
      msg = a + ' failed: ' + (e.message || 'git');
      msgErr = true;
      notify();
    }
  }

  window.VmGitCore = {
    open: open,
    act: act,
    getData: function () { return data; },
    subscribe: function (f) { if (f) subs.push(f); },
    codeOf: codeOf,
    esc: function (s) { return String(s == null ? '' : s)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
  };
})();
