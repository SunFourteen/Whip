/* Git Repo - square/round renderer (drawing and path input only). */
(function () {
  'use strict';

  var esc2 = VmGitCore.esc;

  function draw(data, msg, err) {
    var dot = document.getElementById('dot');
    var on = false;
    try { on = !!SshBridge.isConnected(); } catch (e) {}
    if (dot) dot.className = 'dot ' + (on ? 'on' : 'off');
    var v = document.getElementById('view');
    if (!data) {
      v.innerHTML = '<div class="empty">Open a repo to start.</div>'
        + '<div class="msg' + (err ? ' err' : '') + '">' + esc2(msg) + '</div>';
      return;
    }
    var badge = data.conflict ? 'conflict'
      : data.staged + '/' + data.unstaged + '/' + data.untracked;
    var html = '<div class="repo' + (data.conflict ? ' conflict' : '') + '">'
      + '<span class="badge">' + esc2(badge) + '</span>'
      + '<div class="br">⎇ ' + esc2(data.branch) + '</div>'
      + '<div class="cnt">' + esc2(data.head || '') + '</div></div>'
      + '<div class="btnrow">'
      + '<button data-a="fetch">Fetch</button>'
      + '<button data-a="pull">Pull</button>'
      + '<button data-a="push">Push</button></div>'
      + '<div class="btnrow">'
      + '<button data-a="stage">Stage</button>'
      + '<button class="primary" data-a="refresh">Refresh</button></div>'
      + '<div class="msg' + (err ? ' err' : '') + '">' + esc2(msg || '') + '</div>'
      + '<div class="sec">CHANGES ' + data.totalFiles + '</div>'
      + (data.files.length ? data.files.map(function (f) {
          var c = VmGitCore.codeOf(f.xy);
          return '<div class="file"><span class="code ' + esc2(c) + '">'
            + esc2(c) + '</span><span class="path">' + esc2(f.path)
            + '</span></div>';
        }).join('') : '<div class="empty">Clean.</div>')
      + (data.totalFiles > data.files.length
          ? '<div class="empty">+' + (data.totalFiles - data.files.length) + ' more</div>' : '')
      + '<div class="sec">LOG</div>'
      + (data.commits.length ? data.commits.map(function (c) {
          return '<div class="commit"><span class="h">' + esc2(c.h) + '</span>'
            + '<span class="s">' + esc2(c.s) + '</span></div>';
        }).join('') : '<div class="empty">No commits.</div>');
    v.innerHTML = html;
    v.querySelectorAll('button[data-a]').forEach(function (b) {
      b.addEventListener('click', function () { VmGitCore.act(b.getAttribute('data-a')); });
    });
  }

  document.getElementById('back').addEventListener('click', function () { history.back(); });
  document.getElementById('open').addEventListener('click', function () {
    VmGitCore.open(document.getElementById('repo').value || '~', true);
  });
  var saved = '';
  try { saved = SshBridge.prefsGet('git_repo'); } catch (e) {}
  document.getElementById('repo').value = saved || '~';
  VmGitCore.subscribe(function (d, msg, err) { draw(d, msg, err); });
  draw(null, '', false);
  VmGitCore.open(saved || '~', false);
  setInterval(function () {
    var d = VmGitCore.getData();
    if (d && d.repo) VmGitCore.open(d.repo, false);
  }, 5000);
})();
