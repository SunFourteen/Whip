'use strict';

/* ============================================================
 *  Git Repo plugin — pure HTML/CSS/JS, no external libs.
 *  Runs git commands over the shared SSH session via SshBridge.
 *  Includes: commit graph, working-tree management, diff viewer,
 *  branches / stash / remotes, reset / rebase / cherry-pick GUI.
 * ============================================================ */

/* ---------------- utils ---------------- */
function $(id) { return document.getElementById(id); }
function esc(s) { return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function q(s) { return "'" + String(s).replace(/'/g, "'\\''") + "'"; }
function b64(s) {
  var bytes = new TextEncoder().encode(s);
  var bin = '';
  for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin);
}
function fmtDate(iso) {
  var d = new Date(iso);
  if (isNaN(d.getTime())) return String(iso || '');
  function p2(x) { return (x < 10 ? '0' : '') + x; }
  return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()) +
         ' ' + p2(d.getHours()) + ':' + p2(d.getMinutes());
}

var toastTimer = null;
function toast(msg, isErr) {
  var t = $('toast');
  t.textContent = msg;
  t.className = 'show' + (isErr ? ' err' : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function () { t.className = ''; }, 3200);
}

function openModal(title, bodyHtml, actions) {
  $('modalTitle').textContent = title;
  $('modalBody').innerHTML = bodyHtml;
  var wrap = $('modalActions');
  wrap.innerHTML = '';
  actions.forEach(function (a) {
    var b = document.createElement('button');
    b.textContent = a.label;
    b.className = a.cls || 'ghost';
    b.onclick = function () { a.onClick && a.onClick(); };
    wrap.appendChild(b);
  });
  $('modal').classList.add('show');
}
function closeModal() { $('modal').classList.remove('show'); }

function confirmModal(title, bodyHtml, okLabel, danger) {
  return new Promise(function (resolve) {
    openModal(title, bodyHtml, [
      { label: 'Cancel', onClick: function () { closeModal(); resolve({ ok: false, chk: false }); } },
      {
        label: okLabel || 'Confirm',
        cls: danger ? 'danger' : 'ghost',
        onClick: function () {
          var chk = document.getElementById('confirmChk');
          if (chk && !chk.checked) { toast('Please tick the confirmation box', true); return; }
          closeModal();
          resolve({ ok: true, chk: chk ? chk.checked : false });
        }
      }
    ]);
  });
}

function ssh(cmd) {
  if (typeof SshBridge === 'undefined') throw new Error('bridge missing');
  if (!SshBridge.isConnected()) throw new Error('disconnected');
  var r = JSON.parse(SshBridge.run(cmd, '{}'));
  if (!r.ok) {
    throw new Error('SSH error: ' + (r.error || ('exit ' + r.exitCode)) +
                   (r.stderr ? ' - ' + r.stderr.slice(0, 200) : ''));
  }
  return r.stdout || '';
}
function git(args) { return 'git -C ' + q(state.repo) + ' ' + args; }
function runGit(args) { return ssh(git(args) + ' 2>&1'); }
function expandHome(p) {
  p = String(p || '');
  if (p === '~') return state.home || p;
  if (p.indexOf('~/') === 0) return (state.home || '') + p.slice(1);
  return p;
}

/* ---------------- repo selection ----------------
 * The plugin never asks for a path on open: it remembers the last repo and, on a
 * fresh device, discovers candidates on the host (agent session workspaces plus the
 * usual project directories), keeping only real git repositories. */
var REPO_KEY = 'git_repo_v1';
var repoCandidates = [];

function savedRepo() {
  try { return SshBridge.prefsGet(REPO_KEY) || ''; } catch (e) { return ''; }
}
function saveRepo(p) {
  try { SshBridge.prefsSet(REPO_KEY, p || ''); } catch (e) {}
}

/** One round trip; prints only directories that really are git repos. */
function discoverRepos() {
  var cmd = [
    'ws=$(sed -n \'s/.*"workspace":"\\([^"]*\\)".*/\\1/p\' ' +
      '"$HOME/.whip/monitor/state/cards.json" 2>/dev/null | sort -u)',
    'for p in "$HOME" "$HOME/workspace" "$HOME/projects" "$HOME/src" ' +
      '"$HOME/code" "$HOME/repos" "$HOME/workspace"/* "$HOME/projects"/* ' +
      '"$HOME/src"/* "$HOME/code"/* "$HOME/repos"/* $ws; do',
    '  [ -n "$p" ] && [ -d "$p/.git" ] && printf "%s\\n" "$p"',
    'done 2>/dev/null; true'
  ].join('\n');
  try {
    return ssh(cmd).split('\n')
      .map(function (s) { return s.trim(); })
      .filter(function (s, i, a) { return s && a.indexOf(s) === i; });
  } catch (e) { return []; }
}

function openRepo(p) {
  var path = expandHome(p);
  if (!path) return;
  state.repo = path;
  state.selected = null;
  saveRepo(path);
  $('repoPath').value = path;
  renderChips();
  loadAll(true);
}

function renderChips() {
  var wrap = $('repoChips');
  if (!wrap) return;
  var list = repoCandidates.slice();
  if (state.repo && list.indexOf(state.repo) < 0) list.unshift(state.repo);
  wrap.innerHTML = '';
  list.slice(0, 8).forEach(function (p) {
    var b = document.createElement('button');
    b.className = 'chip' + (p === state.repo ? ' on' : '');
    b.textContent = state.home && p.indexOf(state.home) === 0
      ? '~' + p.slice(state.home.length) : p;
    b.title = p;
    b.onclick = function () { openRepo(p); };
    wrap.appendChild(b);
  });
}

/* ---------------- state ---------------- */
var state = {
  connected: false,
  repo: '',
  head: null,          // {sha, short, branch, author, email, date, subject, refs}
  upstream: '', ahead: 0, behind: 0,
  statusFiles: [],     // [{xy, path, orig}]
  commits: [],         // [{hash, parents[], author, date, dateShort, subject, refs[]}]
  branches: [],        // [{name, sha, tracking, ahead, behind, current}]
  remotes: [],         // [{name, url}]
  remoteBranches: [],
  stashes: [],         // [{sha, gd, subject}]
  selected: null,
  opInProgress: '',    // '', 'rebase', 'cherry-pick', 'merge'
  graph: null
};

/* ---------------- parsers ---------------- */
function parseStatusZ(raw) {
  var files = [];
  var tokens = raw.split('\u0000');
  for (var i = 0; i < tokens.length; i++) {
    var t = tokens[i];
    if (!t) continue;
    if (t.length >= 2 && /^[MADRCU?!\s]{2}/.test(t)) {
      var xy = t.substring(0, 2);
      var path = t.length > 3 ? t.substring(3) : t.substring(2);
      if (path.length && (path[0] === ' ' || path[0] === '?' || path[0] === 'M' || path[0] === 'A' || path[0] === 'D')) {
        // safety: not a status code, treat as path
      }
      var orig = '';
      if ((xy[0] === 'R' || xy[0] === 'C') && i + 1 < tokens.length && tokens[i + 1]) {
        orig = path;
        path = tokens[++i];
      }
      files.push({ xy: xy, path: path, orig: orig });
    } else if (files.length) {
      // trailing rename destination without code (defensive)
      if ((files[files.length - 1].xy[0] === 'R' || files[files.length - 1].xy[0] === 'C') &&
          !files[files.length - 1].orig) {
        files[files.length - 1].orig = files[files.length - 1].path;
        files[files.length - 1].path = t;
      }
    }
  }
  return files;
}
function parseBranchStatusLine(line) {
  var res = { branch: '', upstream: '', ahead: 0, behind: 0 };
  var rest = line.replace(/^##\s*/, '');
  var am = rest.match(/ahead (\d+)/), bm = rest.match(/behind (\d+)/);
  if (am) res.ahead = parseInt(am[1], 10) || 0;
  if (bm) res.behind = parseInt(bm[1], 10) || 0;
  var base = rest.replace(/\[.*\]/, '').trim();
  var parts = base.split('...');
  res.branch = parts[0] || '';
  res.upstream = parts[1] || '';
  return res;
}
function parseBranches(text) {
  var rows = [];
  text.split('\n').forEach(function (l) {
    l = l.replace(/\r$/, '');
    var m = l.match(/^([* ])\s+(\S+)\s+([0-9a-f]{4,40})(?:\s+\[([^\]]+)\])?(?:\s+(.*))?$/);
    if (!m) return;
    var track = m[4] || '';
    var ahead = 0, behind = 0;
    var am = track.match(/ahead (\d+)/), bm = track.match(/behind (\d+)/);
    if (am) ahead = parseInt(am[1], 10) || 0;
    if (bm) behind = parseInt(bm[1], 10) || 0;
    rows.push({ name: m[2], sha: m[3], tracking: track.split(':')[0] || '', ahead: ahead, behind: behind, current: m[1] === '*' });
  });
  return rows;
}
function parseRefs(dec) {
  if (!dec || dec === '(no output)' || dec.indexOf('(no output)') === 0) return [];
  var out = [];
  dec.split(', ').forEach(function (r) {
    var label = r.replace(/^HEAD -> /, '');
    label = label.replace(/^tag: /, '');
    var head = r.indexOf('HEAD -> ') === 0;
    out.push({ label: label, head: head, tag: /^tag: /.test(r) });
  });
  return out;
}
function parseGraphCommit(line) {
  var f = line.split('\u001f');
  if (f.length < 7) return null;
  return {
    hash: f[0],
    parents: f[1] ? f[1].split(' ') : [],
    author: f[2],
    email: f[3],
    date: f[4],
    dateShort: fmtDate(f[4]),
    subject: f[5],
    refs: parseRefs(f[6])
  };
}

/* ---------------- commit graph layout ---------------- */
var PALETTE = ['#00D4AA', '#00A6FF', '#d4aa00', '#d4004a', '#aa00d4', '#ff7f2a', '#4ad4ff', '#b3ff4d', '#ff5c8a', '#8affaa'];
function laneColor(i) { return PALETTE[i % PALETTE.length]; }
function buildLayout(commits) {
  var lanes = [];   // lanes[i] = promised commit hash or null
  var free = [];
  var rows = [];
  commits.forEach(function (c) {
    var lane = -1;
    for (var i = 0; i < lanes.length; i++) if (lanes[i] === c.hash) { lane = i; break; }
    if (lane < 0) {
      lane = free.length ? free.shift() : lanes.length;
      if (lane >= lanes.length) lanes.push(null);
    }
    var edges = [];
    if (c.parents.length) {
      lanes[lane] = c.parents[0];
      for (var pi = 1; pi < c.parents.length; pi++) {
        var p = c.parents[pi];
        var j = -1;
        for (var k = 0; k < lanes.length; k++) if (lanes[k] === p) { j = k; break; }
        if (j < 0) {
          j = free.length ? free.shift() : lanes.length;
          if (j >= lanes.length) lanes.push(null);
          lanes[j] = p;
        }
        edges.push({ from: lane, to: j });
      }
    } else {
      lanes[lane] = null;
      if (free.indexOf(lane) < 0) free.push(lane);
    }
    rows.push({ commit: c, lane: lane, edges: edges });
  });
  return { rows: rows, lanes: lanes, laneCount: lanes.length };
}

function renderGraph() {
  var svg = $('graphSvg');
  if (!state.commits.length) { svg.innerHTML = '<text x="14" y="24" fill="#777" font-size="12">No commits found.</text>'; return; }
  var layout = buildLayout(state.commits);
  state.graph = layout;
  var rowH = 34, laneW = 18, padL = 14, padT = 12;
  var rowCount = layout.rows.length;
  var maxSubject = 0;
  state.commits.forEach(function (c) { maxSubject = Math.max(maxSubject, c.subject.length); });
  var width = Math.max(padL + layout.laneCount * laneW + maxSubject * 7.2 + 190, $('graphScroll').clientWidth || 860);
  var height = padT + rowCount * rowH + 14;
  svg.setAttribute('width', width);
  svg.setAttribute('height', height);
  function lx(i) { return padL + i * laneW + laneW / 2; }

  var html = '';
  for (var r = 0; r < rowCount; r++) {
    var y = padT + r * rowH;
    var row = layout.rows[r];
    layout.lanes.forEach(function (promise, li) {
      if (promise) {
        html += '<line x1="' + lx(li) + '" y1="' + y + '" x2="' + lx(li) + '" y2="' + (y + rowH) +
                '" stroke="' + laneColor(li) + '" stroke-width="2" opacity="0.5"/>';
      }
    });
    row.edges.forEach(function (e) {
      html += '<path d="M ' + lx(e.from) + ' ' + y + ' C ' + (lx(e.from) + 10) + ' ' + y + ', ' +
              (lx(e.to) - 10) + ' ' + y + ', ' + lx(e.to) + ' ' + y + '" stroke="' + laneColor(e.to) +
              '" stroke-width="2" fill="none" opacity="0.65"/>';
    });
  }

  for (var r = 0; r < rowCount; r++) {
    var row = layout.rows[r];
    var c = row.commit;
    var y = padT + r * rowH;
    var x = lx(row.lane);
    var color = laneColor(row.lane);
    var isHead = state.head && c.hash === state.head.sha;
    var selected = state.selected && state.selected.hash === c.hash;
    var refX = padL + layout.laneCount * laneW + 8;
    var refHtml = '';
    (c.refs || []).forEach(function (ref) {
      var w = ref.label.length * 6.1 + 12;
      var rc = ref.head ? '#00D4AA' : (ref.tag ? '#aa00d4' : '#00A6FF');
      refHtml += '<rect x="' + refX + '" y="' + (y - 9) + '" width="' + w + '" height="13" rx="6" fill="' + rc + '" opacity="0.9"/>' +
                 '<text x="' + (refX + 6) + '" y="' + y + '" class="g-ref" text-anchor="start" dominant-baseline="middle">' + esc(ref.label) + '</text>';
      refX += w + 4;
    });
    var subjectX = refX;
    var subj = c.subject;
    var subjW = width - subjectX - 10;
    var subjMax = Math.floor(subjW / 6.6);
    if (subj.length > subjMax && subjMax > 3) subj = subj.slice(0, subjMax - 1) + '…';
    var meta = esc(c.author) + ' · ' + esc(c.dateShort);
    html += '<g class="graph-commit' + (selected ? ' selected' : '') + '" data-hash="' + c.hash + '">' +
      '<line x1="' + (x - 10) + '" y1="' + y + '" x2="' + (x + 10) + '" y2="' + y + '" stroke="' + (isHead ? color : 'transparent') + '" stroke-width="1.5"/>' +
      '<circle cx="' + x + '" cy="' + y + '" r="' + (isHead ? 5.5 : 4) + '" fill="' + (c.parents.length > 1 ? '#0F0F1A' : color) + '" stroke="' + color + '" stroke-width="' + (isHead ? 2.5 : 1.5) + '"/>' +
      (isHead ? '<circle cx="' + x + '" cy="' + y + '" r="8" fill="none" stroke="' + color + '" stroke-width="1" opacity="0.5"/>' : '') +
      refHtml +
      '<text x="' + subjectX + '" y="' + (y - 0.5) + '" class="g-subject' + (isHead ? ' head' : '') + '" fill="' + (isHead ? '#ffffff' : '#cccccc') + '" text-anchor="start">' + esc(subj) + '</text>' +
      '<text x="' + subjectX + '" y="' + (y + 11) + '" class="g-meta">' + meta + '</text>' +
      '</g>';
  }
  svg.innerHTML = html;
}

/* ---------------- loading ---------------- */
function loadAll(showBusy) {
  if (!state.repo) return;
  if (showBusy) $('sbMsg').textContent = 'Loading...';
  try {
    var check = runGit('rev-parse --is-inside-work-tree');
    if (/fatal|not a git repository/i.test(check) || check.trim() !== 'true') {
      $('sbMsg').textContent = '';
      toast('Not a git repository: ' + state.repo, true);
      state.commits = []; state.statusFiles = []; state.branches = []; state.head = null;
      renderAll();
      return;
    }
    var raw = runGit('status -sb') + '\n==S==\n' + runGit("log -1 --pretty=format:'%H%x1f%h%x1f%an%x1f%ae%x1f%aI%x1f%s%x1f%D'");
    var parts = raw.split('==S==');
    var firstLine = parts[0].split('\n')[0] || '';
    var op = '';
    if (/rebase/i.test(firstLine)) op = 'rebase';
    else if (/cherry-pick/i.test(firstLine)) op = 'cherry-pick';
    else if (/merge/i.test(firstLine)) op = 'merge';
    state.opInProgress = op;

    var bs = parseBranchStatusLine(firstLine);
    var headLine = parts[1] || '';
    var hf = headLine.split('\u001f');
    state.head = hf.length >= 7 ? {
      sha: hf[0], short: hf[1], author: hf[2], email: hf[3], date: hf[4], subject: hf[5], refs: parseRefs(hf[6])
    } : null;
    state.branch = bs.branch;
    state.upstream = bs.upstream;
    state.ahead = bs.ahead;
    state.behind = bs.behind;

    state.statusFiles = parseStatusZ(runGit('status --porcelain=v1 -z'));
    var braw = runGit('branch -vv --no-color') + '\n==R==\n' + runGit('branch -r --no-color');
    var bp = braw.split('==R==');
    state.branches = parseBranches(bp[0]);
    state.remoteBranches = parseBranches(bp[1]).map(function (b) {
      return { name: b.name.replace(/^remotes\//, ''), sha: b.sha };
    });
    state.remotes = [];
    runGit('remote -v').split('\n').forEach(function (l) {
      var m = l.match(/^(\S+)\s+(\S+)\s+\((fetch|push)\)$/);
      if (m) state.remotes.push({ name: m[1], url: m[2] });
    });
    state.stashes = [];
    runGit("stash list --format='%H%x1f%gd%x1f%s'").split('\n').forEach(function (l) {
      var f = l.split('\u001f');
      if (f.length >= 2 && /^[0-9a-f]{40}$/.test(f[0])) state.stashes.push({ sha: f[0], gd: f[1], subject: f[2] || '' });
    });
    var craw = runGit("log --all --topo-order --date=iso-strict --pretty=format:'%H%x1f%P%x1f%an%x1f%ae%x1f%aI%x1f%s%x1f%D' -n 400");
    state.commits = [];
    craw.split('\n').forEach(function (l) {
      var c = parseGraphCommit(l);
      if (c) state.commits.push(c);
    });
    renderAll();
    $('sbMsg').textContent = 'Loaded ' + state.commits.length + ' commits';
  } catch (e) {
    $('sbMsg').textContent = '';
    if (String(e.message).indexOf('disconnected') >= 0 || String(e.message).indexOf('bridge') >= 0) {
      showOffline();
    } else {
      toast('Error: ' + e.message, true);
    }
  }
}

function renderAll() {
  updateConn(true);
  renderStatusBar();
  renderSidebar();
  renderGraph();
  renderChanges();
  renderCommitList();
  renderConflictBanner();
  if (state.selected) {
    // re-find selected commit in fresh data
    var found = state.commits.filter(function (c) { return c.hash === state.selected.hash; })[0];
    state.selected = found || null;
  }
  renderCommitDetail();
}

function renderStatusBar() {
  $('sbBranch').textContent = state.branch ? ('\u2387 ' + state.branch) : '(detached)';
  $('sbHead').textContent = state.head ? state.head.short : '-';
  var ah = [];
  if (state.ahead) ah.push(state.ahead + ' ahead');
  if (state.behind) ah.push(state.behind + ' behind');
  $('sbAhead').textContent = ah.join(', ');
  var staged = state.statusFiles.filter(function (f) { return f.xy[0] !== ' ' && f.xy[0] !== '?'; }).length;
  var unstaged = state.statusFiles.filter(function (f) { return f.xy[1] !== ' ' && f.xy[1] !== '?'; }).length;
  var untracked = state.statusFiles.filter(function (f) { return f.xy === '??'; }).length;
  $('sbCounts').textContent = 'staged ' + staged + ' · unstaged ' + unstaged + ' · untracked ' + untracked;
}

function renderSidebar() {
  $('sdBranch').textContent = state.branch || '(detached)';
  $('sdHead').textContent = state.head ? state.head.short : '-';
  $('sdUpstream').textContent = state.upstream || '-';
  $('sdLast').textContent = state.head ? state.head.subject : '-';

  var bl = $('branchList');
  if (!state.branches.length) bl.innerHTML = '<div class="empty">No local branches</div>';
  else {
    bl.innerHTML = state.branches.map(function (b) {
      // Tracking info is labelled and kept next to the name; the action icons stay at
      // the far right so checkout and delete are not a thumb-width apart.
      var meta = b.tracking ? ('→ ' + b.tracking +
        (b.ahead || b.behind ? ' [' + (b.ahead ? b.ahead + '↑' : '') + (b.behind ? b.behind + '↓' : '') + ']' : '')) : '';
      return '<div class="list-item' + (b.current ? ' current' : '') + '" data-branch="' + esc(b.name) + '">' +
        '<span class="nm" title="' + esc(b.name) + '">' + (b.current ? '\u25b6 ' : '') + esc(b.name) + '</span>' +
        '<span class="meta">' + esc(meta) + '</span>' +
        (b.current ? '' : '<span class="op" title="Checkout" data-act="checkout">\u23ce</span>') +
        (b.current ? '' : '<span class="op del" title="Delete" data-act="delbranch">\u2715</span>') +
        '</div>';
    }).join('');
  }
  var rl = $('remoteList');
  rl.innerHTML = state.remotes.length ? state.remotes.map(function (r) {
    return '<div class="list-item remote"><span class="nm">' + esc(r.name) + '</span><span class="meta">' + esc(r.url) + '</span></div>';
  }).join('') : '<div class="empty">No remotes</div>';

  var sl = $('stashList');
  sl.innerHTML = state.stashes.length ? state.stashes.map(function (s, i) {
    return '<div class="list-item dim-item" data-stash="' + i + '">' +
      '<span class="nm">' + esc(s.subject || s.gd) + '</span>' +
      '<span class="op" title="Apply" data-act="stashapply">\u21e9</span>' +
      '<span class="op del" title="Drop" data-act="stashdrop">\u2715</span>' +
      '<span class="meta">' + esc(s.gd) + '</span></div>';
  }).join('') : '<div class="empty">Empty stash</div>';
}

function renderChanges() {
  var el = $('changeList');
  if (!state.statusFiles.length) { el.innerHTML = '<div class="empty">Working tree clean — nothing to commit.</div>'; return; }
  var staged = [], unstaged = [], untracked = [];
  state.statusFiles.forEach(function (f) {
    var X = f.xy[0], Y = f.xy[1];
    if (X === '?' && Y === '?') untracked.push(f);
    else if (X !== ' ' && X !== '?') staged.push(f);
    else unstaged.push(f);
    // files both staged & unstaged appear twice conceptually; keep simple: primary group by X
  });
  var html = '';
  function badge(xy) {
    var code = xy === '??' ? 'Q' : (xy[1] !== ' ' && xy[1] !== '?' ? xy[1] : xy[0]);
    return '<span class="badge ' + code + '">' + code + '</span>';
  }
  function rowHtml(f, group) {
    var isRen = f.orig ? true : false;
    var show = f.orig ? esc(f.orig) + ' \u2192 <b>' + esc(f.path) + '</b>' : esc(f.path);
    var ops = '';
    if (f.xy === '??') {
      ops += '<span class="change-op" title="Stage" data-act="stage">+</span>';
      ops += '<span class="change-op danger" title="Delete file" data-act="deluntracked">\u2715</span>';
    } else {
      var X = f.xy[0], Y = f.xy[1];
      if (X !== ' ' && X !== '?') ops += '<span class="change-op" title="Unstage" data-act="unstage">\u2212</span>';
      if (Y !== ' ' && Y !== '?') ops += '<span class="change-op" title="Stage" data-act="stage">+</span>';
      if (Y !== ' ' && Y !== '?') ops += '<span class="change-op danger" title="Discard changes" data-act="discard">\u21ba</span>';
    }
    return '<div class="change-row" data-path="' + esc(f.path) + '" data-xy="' + esc(f.xy) + '">' +
      badge(f.xy) + '<span class="change-path' + (isRen ? ' ren' : '') + '">' + show + '</span>' + ops + '</div>';
  }
  if (staged.length) html += '<div class="group-label">Staged</div>' + staged.map(function (f) { return rowHtml(f, 'staged'); }).join('');
  if (unstaged.length) html += '<div class="group-label">Unstaged</div>' + unstaged.map(function (f) { return rowHtml(f, 'unstaged'); }).join('');
  if (untracked.length) html += '<div class="group-label">Untracked</div>' + untracked.map(function (f) { return rowHtml(f, 'untracked'); }).join('');
  el.innerHTML = html;
}

function renderCommitList() {
  var qText = ($('commitSearch').value || '').trim().toLowerCase();
  var list = state.commits.filter(function (c) {
    if (!qText) return true;
    return (c.subject + ' ' + c.author + ' ' + c.hash).toLowerCase().indexOf(qText) >= 0;
  });
  var el = $('commitList');
  if (!list.length) { el.innerHTML = '<div class="empty">No commits match.</div>'; return; }
  el.innerHTML = list.map(function (c) {
    return '<div class="commit-row" data-hash="' + c.hash + '">' +
      '<span class="h">' + esc(c.hash.slice(0, 7)) + '</span>' +
      '<span class="s">' + esc(c.subject) + '</span>' +
      '<span class="m">' + esc(c.author) + ' · ' + esc(c.dateShort) + '</span></div>';
  }).join('');
}

function renderConflictBanner() {
  var conflict = state.opInProgress !== '' || state.statusFiles.some(function (f) { return f.xy[0] === 'U' || f.xy[1] === 'U'; });
  $('conflictBanner').style.display = conflict ? 'flex' : 'none';
}

/* ---------------- commit detail ---------------- */
function selectCommit(hash) {
  var c = state.commits.filter(function (x) { return x.hash === hash; })[0];
  if (!c) return;
  state.selected = c;
  document.querySelectorAll('.graph-commit').forEach(function (g) {
    g.classList.toggle('selected', g.dataset.hash === hash);
  });
  renderCommitDetail();
}

function renderCommitDetail() {
  var empty = $('cdEmpty'), body = $('cdBody');
  var c = state.selected;
  if (!c) { empty.style.display = ''; body.style.display = 'none'; return; }
  empty.style.display = 'none';
  body.style.display = '';
  var head = state.head && c.hash === state.head.sha;
  var parents = c.parents.length ? c.parents.map(function (p) { return p.slice(0, 7); }).join(', ') : '(root commit)';
  var refs = (c.refs || []).map(function (r) {
    return '<span class="cd-ref">' + esc(r.label) + '</span>';
  }).join('');
  body.innerHTML =
    '<div class="cd-title">' + esc(c.subject) + (head ? ' <span class="cd-ref" style="color:#0F0F1A;background:#00D4AA">HEAD</span>' : '') + '</div>' +
    '<div class="cd-meta">' + esc(c.author) + ' &lt;' + esc(c.email || '') + '&gt;</div>' +
    '<div class="cd-meta">' + esc(c.dateShort) + '</div>' +
    '<div class="cd-meta">parents: <b>' + esc(parents) + '</b></div>' +
    (refs ? '<div class="cd-refs">' + refs + '</div>' : '') +
    '<div class="cd-hash">' + esc(c.hash) + '<button class="ghost sm" id="btnCopySha">Copy</button></div>' +
    '<div class="cd-actions">' +
      '<button class="ghost" id="cdDiff">&#128196; View diff</button>' +
      '<button class="ghost" id="cdCheckout">&#8627; Checkout (detached)</button>' +
      '<div class="grp"><button class="ghost" id="cdCherry">Cherry-pick</button><button class="ghost" id="cdBranch">Branch here</button></div>' +
      '<div class="grp"><button class="ghost" id="cdRebase">Rebase onto</button><button class="ghost" id="cdRebaseI">Rebase -i</button></div>' +
      '<div class="grp"><button class="ghost" id="cdRevert">Revert</button><button class="ghost" id="cdReset">Reset here</button></div>' +
    '</div>';
  $('btnCopySha').onclick = function () {
    var ta = document.createElement('textarea');
    ta.value = c.hash; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); toast('SHA copied'); } catch (e) {}
    ta.remove();
  };
  $('cdDiff').onclick = function () { showCommitDiff(c.hash, c.subject); };
  $('cdCheckout').onclick = function () { actCheckout(c.hash); };
  $('cdCherry').onclick = function () { actCherryPick(c.hash); };
  $('cdBranch').onclick = function () { actBranchHere(c.hash); };
  $('cdRebase').onclick = function () { actRebaseOnto(c.hash, c.subject); };
  $('cdRebaseI').onclick = function () { actRebaseInteractive(c.hash, c.subject); };
  $('cdRevert').onclick = function () { actRevert(c.hash); };
  $('cdReset').onclick = function () { actReset(c.hash); };
}

function afterMutation(msg, isErr) {
  if (msg) toast(msg, isErr);
  setTimeout(function () { loadAll(false); }, 200);
}

function actCheckout(sha) {
  confirmModal('Checkout ' + sha.slice(0, 7), 'Switch to <span class="mono">' + esc(sha.slice(0, 7)) + '</span> in detached HEAD mode?', 'Checkout').then(function (r) {
    if (!r.ok) return;
    try { var out = runGit('checkout --detach ' + sha); afterMutation(out.trim(), /error|fatal/i.test(out)); }
    catch (e) { toast(e.message, true); }
  });
}
function actCherryPick(sha) {
  confirmModal('Cherry-pick ' + sha.slice(0, 7), 'Apply commit <span class="mono">' + esc(sha.slice(0, 7)) + '</span> onto the current branch?', 'Cherry-pick').then(function (r) {
    if (!r.ok) return;
    try { var out = runGit('cherry-pick ' + sha); afterMutation(out.trim(), /error|fatal|conflict/i.test(out)); }
    catch (e) { toast(e.message, true); }
  });
}
function actBranchHere(sha) {
  openModal('Create branch at ' + sha.slice(0, 7),
    '<input type="text" id="newBranchName" placeholder="branch name" autocomplete="off">',
    [
      { label: 'Cancel', onClick: closeModal },
      { label: 'Create', cls: 'ghost', onClick: function () {
          var n = $('newBranchName').value.trim();
          if (!n) { toast('Branch name required', true); return; }
          closeModal();
          try { var out = runGit('checkout -b ' + q(n) + ' ' + sha); afterMutation(out.trim(), /error|fatal/i.test(out)); }
          catch (e) { toast(e.message, true); }
      } }
    ]);
}
function actRebaseOnto(sha, subject) {
  confirmModal('Rebase onto ' + sha.slice(0, 7),
    'Replay current branch commits on top of <span class="mono">' + esc(sha.slice(0, 7)) + '</span> (' + esc(subject) + ')?<br>Uncommitted changes are stashed automatically.',
    'Rebase', true).then(function (r) {
    if (!r.ok) return;
    try { var out = runGit('-c rebase.autoStash=true rebase ' + sha); afterMutation(out.trim(), /error|fatal|conflict/i.test(out)); }
    catch (e) { toast(e.message, true); }
  });
}
function actRebaseInteractive(sha, subject) {
  var list = [];
  try {
    var raw = runGit("log --reverse --pretty=format:'%H%x1f%s' " + sha + '..HEAD');
    raw.split('\n').forEach(function (l) {
      var f = l.split('\u001f');
      if (f.length >= 2 && /^[0-9a-f]{40}$/.test(f[0])) list.push({ hash: f[0], subject: f[1], action: 'pick' });
    });
  } catch (e) { toast(e.message, true); return; }
  if (!list.length) { toast('No commits to rebase', true); return; }
  var rows = list.map(function (c) {
    return '<div class="rebase-row"><select data-hash="' + c.hash + '">' +
      '<option value="pick">pick</option><option value="squash">squash</option>' +
      '<option value="reword">reword</option><option value="drop">drop</option></select>' +
      '<span class="h">' + esc(c.hash.slice(0, 7)) + '</span><span class="msg">' + esc(c.subject) + '</span></div>';
  }).join('');
  openModal('Interactive rebase', 'Replay ' + list.length + ' commit(s) onto <span class="mono">' + esc(sha.slice(0, 7)) + '</span>. Adjust actions below.',
    [
      { label: 'Cancel', onClick: closeModal },
      { label: 'Start rebase', cls: 'danger', onClick: function () {
          var todo = '';
          document.querySelectorAll('#modalBody .rebase-row').forEach(function (row) {
            var sel = row.querySelector('select');
            var hash = sel.dataset.hash;
            var act = sel.value;
            if (act === 'drop') return;
            var subject = row.querySelector('.msg').textContent;
            todo += act + ' ' + hash.slice(0, 7) + ' ' + subject + '\n';
          });
          if (!todo.trim()) { toast('Nothing to do', true); return; }
          closeModal();
          try {
            var cmd = 'echo ' + b64(todo) + ' | base64 -d > /tmp/whip_todo && ' +
              "GIT_SEQUENCE_EDITOR='cp /tmp/whip_todo' GIT_EDITOR=true " +
              git('-c rebase.autoStash=true rebase -i ' + sha) + ' 2>&1';
            var out = ssh(cmd);
            afterMutation(out.trim(), /error|fatal|conflict/i.test(out));
          } catch (e) { toast(e.message, true); }
      } }
    ]);
  // attach list rows
  var body = $('modalBody');
  body.insertAdjacentHTML('beforeend', '<div class="rebase-list">' + rows + '</div>');
}
function actRevert(sha) {
  confirmModal('Revert ' + sha.slice(0, 7), 'Create a new commit that undoes <span class="mono">' + esc(sha.slice(0, 7)) + '</span>?', 'Revert').then(function (r) {
    if (!r.ok) return;
    try { var out = runGit('revert --no-edit ' + sha); afterMutation(out.trim(), /error|fatal|conflict/i.test(out)); }
    catch (e) { toast(e.message, true); }
  });
}
function actReset(sha) {
  openModal('Reset to ' + sha.slice(0, 7),
    '<div class="kv"><span>soft</span><b>move HEAD only; keep index &amp; worktree</b></div>' +
    '<div class="kv"><span>mixed</span><b>move HEAD + unstage; keep worktree (default)</b></div>' +
    '<div class="kv"><span>hard</span><b>discard all local changes — destructive!</b></div>' +
    '<label class="chk"><input type="checkbox" id="confirmChk"> I understand this operation</label>',
    [
      { label: 'Cancel', onClick: closeModal },
      { label: 'soft', cls: 'ghost', onClick: function () { doReset('soft', sha); } },
      { label: 'mixed', cls: 'ghost', onClick: function () { doReset('mixed', sha); } },
      { label: 'hard', cls: 'danger', onClick: function () { doReset('hard', sha); } }
    ]);
}
function doReset(mode, sha) {
  var chk = document.getElementById('confirmChk');
  if (mode === 'hard' && (!chk || !chk.checked)) { toast('Tick the confirmation box for hard reset', true); return; }
  closeModal();
  try { var out = runGit('reset --' + mode + ' ' + sha); afterMutation(out.trim(), /error|fatal/i.test(out)); }
  catch (e) { toast(e.message, true); }
}

/* ---------------- diff ---------------- */
function openDrawer(title, html) {
  $('diffTitle').textContent = title;
  $('diffBody').innerHTML = html;
  $('drawerMask').classList.add('show');
}
function closeDrawer() { $('drawerMask').classList.remove('show'); }

function parseDiff(raw) {
  if (!raw || raw.indexOf('(no output)') === 0) return '<div class="diff-empty">No changes.</div>';
  var lines = raw.split('\n');
  var html = '', inDiff = false, found = false;
  var oldStart = 0, newStart = 0, oldLn = 0, newLn = 0;
  lines.forEach(function (l) {
    if (l.indexOf('diff --git ') === 0) {
      inDiff = true; found = true;
      html += '<div class="diff-file"><div class="diff-head">' + esc(l.slice(11)) + '</div>';
      return;
    }
    if (!inDiff) return;
    if (l.indexOf('@@ ') === 0) {
      var m = l.match(/@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@/);
      if (m) { oldStart = parseInt(m[1], 10); newStart = parseInt(m[2], 10); }
      oldLn = oldStart; newLn = newStart;
      html += '<div class="diff-hunk">' + esc(l) + '</div>';
      return;
    }
    if (l.indexOf('+++ ') === 0 || l.indexOf('--- ') === 0 || l.indexOf('index ') === 0 ||
        l.indexOf('new file') === 0 || l.indexOf('deleted file') === 0 ||
        l.indexOf('similarity index') === 0 || l.indexOf('rename from') === 0 ||
        l.indexOf('rename to') === 0 || l.indexOf('Binary files') === 0) return;
    if (l.indexOf('\\ No newline') === 0) { html += '<div class="diff-line note">\\ No newline at end of file</div>'; return; }
    var sign = l.charAt(0);
    var cls = sign === '+' ? 'add' : (sign === '-' ? 'del' : 'ctx');
    var ol = '', nl = '';
    if (sign === '+') { nl = newLn++; }
    else if (sign === '-') { ol = oldLn++; }
    else { ol = oldLn++; nl = newLn++; }
    html += '<div class="diff-line ' + cls + '"><span class="ln">' + (ol || '') + '</span><span class="ln2">' + (nl || '') + '</span>' +
            '<span class="code">' + esc(l) + '</span></div>';
  });
  if (!found) return '<div class="diff-empty">No file diff (merge commit or empty).</div>';
  return html;
}
function showCommitDiff(sha, subject) {
  try {
    var raw = runGit('show --no-color --format=medium ' + sha);
    openDrawer('Diff ' + sha.slice(0, 7) + ' · ' + subject, parseDiff(raw));
  } catch (e) { toast(e.message, true); }
}
function showFileDiff(path, staged) {
  try {
    var raw = staged ? runGit('diff --cached --no-color -- ' + q(path)) : runGit('diff --no-color -- ' + q(path));
    openDrawer('Diff ' + path, parseDiff(raw));
  } catch (e) { toast(e.message, true); }
}

/* ---------------- changes actions ---------------- */
function stagePath(path) {
  try { var out = runGit('add -- ' + q(path)); afterMutation(out.trim(), /error|fatal/i.test(out)); }
  catch (e) { toast(e.message, true); }
}
function unstagePath(path) {
  try { var out = runGit('reset -q HEAD -- ' + q(path)); afterMutation(out.trim(), /error|fatal/i.test(out)); }
  catch (e) { toast(e.message, true); }
}
function discardPath(path, xy) {
  var danger = xy === '??';
  confirmModal(danger ? 'Delete untracked file?' : 'Discard changes?',
    danger
      ? 'Delete <span class="mono">' + esc(path) + '</span> permanently? This cannot be undone.'
      : 'Discard unstaged changes in <span class="mono">' + esc(path) + '</span>?',
    danger ? 'Delete' : 'Discard', true).then(function (r) {
    if (!r.ok) return;
    try {
      var out = danger ? ssh('rm -f -- ' + q(path) + ' 2>&1') : runGit('restore -- ' + q(path));
      afterMutation(out.trim(), /error|fatal/i.test(out));
    } catch (e) { toast(e.message, true); }
  });
}
function commitChanges() {
  var msg = $('commitMsg').value;
  if (!msg.trim()) { toast('Commit message is empty', true); return; }
  var amend = $('chkAmend').checked;
  var hasStaged = state.statusFiles.some(function (f) { return f.xy[0] !== ' ' && f.xy[0] !== '?'; });
  if (!hasStaged && !amend) { toast('Nothing staged — stage files first (or tick amend)', true); return; }
  try {
    var cmd = 'echo ' + b64(msg) + ' | base64 -d > /tmp/whip_msg && ' +
      git('commit' + (amend ? ' --amend' : '') + ' -F /tmp/whip_msg') + ' 2>&1';
    var out = ssh(cmd);
    $('commitMsg').value = '';
    $('chkAmend').checked = false;
    afterMutation(out.trim(), /error|fatal/i.test(out));
  } catch (e) { toast(e.message, true); }
}

/* ---------------- sidebar / branch actions ---------------- */
function checkoutBranch(name) {
  confirmModal('Checkout branch', 'Switch to branch <span class="mono">' + esc(name) + '</span>?', 'Checkout').then(function (r) {
    if (!r.ok) return;
    try { var out = runGit('checkout ' + q(name)); afterMutation(out.trim(), /error|fatal/i.test(out)); }
    catch (e) { toast(e.message, true); }
  });
}
function deleteBranch(name) {
  confirmModal('Delete branch', 'Delete <span class="mono">' + esc(name) + '</span>?<br>Use Force if it has unmerged commits.', 'Delete', true).then(function (r) {
    if (!r.ok) return;
    try {
      var out = runGit('branch -d ' + q(name));
      if (/error|fatal/.test(out)) out = runGit('branch -D ' + q(name));
      afterMutation(out.trim(), /error|fatal/i.test(out));
    } catch (e) { toast(e.message, true); }
  });
}
function newBranch() {
  openModal('New branch',
    '<input type="text" id="newBranchName" placeholder="branch name" autocomplete="off">',
    [
      { label: 'Cancel', onClick: closeModal },
      { label: 'Create & checkout', cls: 'ghost', onClick: function () {
          var n = $('newBranchName').value.trim();
          if (!n) { toast('Branch name required', true); return; }
          closeModal();
          try { var out = runGit('checkout -b ' + q(n)); afterMutation(out.trim(), /error|fatal/i.test(out)); }
          catch (e) { toast(e.message, true); }
      } }
    ]);
}
function stashApply(i) {
  var s = state.stashes[i]; if (!s) return;
  confirmModal('Apply stash', 'Apply <span class="mono">' + esc(s.gd) + '</span> (' + esc(s.subject) + ')?', 'Apply').then(function (r) {
    if (!r.ok) return;
    try { var out = runGit('stash apply ' + q(s.gd)); afterMutation(out.trim(), /error|fatal|conflict/i.test(out)); }
    catch (e) { toast(e.message, true); }
  });
}
function stashDrop(i) {
  var s = state.stashes[i]; if (!s) return;
  confirmModal('Drop stash', 'Drop <span class="mono">' + esc(s.gd) + '</span> permanently?', 'Drop', true).then(function (r) {
    if (!r.ok) return;
    try { var out = runGit('stash drop ' + q(s.gd)); afterMutation(out.trim(), /error|fatal/i.test(out)); }
    catch (e) { toast(e.message, true); }
  });
}
function conflictContinue() {
  var op = state.opInProgress || 'merge';
  try {
    var out;
    if (op === 'rebase') out = runGit('-c core.editor=true rebase --continue');
    else if (op === 'cherry-pick') out = runGit('cherry-pick --continue');
    else out = runGit('commit --no-edit');
    afterMutation(out.trim(), /error|fatal|conflict/i.test(out));
  } catch (e) { toast(e.message, true); }
}
function conflictAbort() {
  var op = state.opInProgress || 'merge';
  confirmModal('Abort operation', 'Abort the in-progress ' + op + ' and return to the previous state?', 'Abort', true).then(function (r) {
    if (!r.ok) return;
    try {
      var out = op === 'rebase' ? runGit('rebase --abort')
              : op === 'cherry-pick' ? runGit('cherry-pick --abort')
              : runGit('merge --abort');
      afterMutation(out.trim(), /error|fatal/i.test(out));
    } catch (e) { toast(e.message, true); }
  });
}
function doFetch() { try { afterMutation(runGit('fetch --all --prune').trim()); } catch (e) { toast(e.message, true); } }
function doPull() { try { var o = runGit('pull --ff-only'); afterMutation(o.trim(), /error|fatal/i.test(o)); } catch (e) { toast(e.message, true); } }
function doPush() { try { var o = runGit('push'); afterMutation(o.trim(), /error|fatal/i.test(o)); } catch (e) { toast(e.message, true); } }

/* ---------------- offline ---------------- */
function updateConn(on) {
  state.connected = on;
  $('connDot').className = 'dot ' + (on ? 'on' : 'off');
}
function showOffline() {
  var el = document.createElement('div');
  el.style.cssText = 'position:fixed;inset:0;background:#1A1A2E;display:flex;flex-direction:column;' +
    'align-items:center;justify-content:center;gap:12px;z-index:100;';
  el.innerHTML = '<div style="color:#d4004a;font-size:38px">&#9679;</div>' +
    '<div style="color:#fff;font-size:15px">SSH not connected</div>' +
    '<div style="color:#888;font-size:12px">Connect in the Terminal tab first, then come back here.</div>' +
    '<button class="ghost" id="retryBtn">Retry</button>';
  document.body.appendChild(el);
  $('retryBtn').onclick = function () {
    try { ssh('echo ok'); el.remove(); init(); } catch (e) {}
  };
}

/* ---------------- events ---------------- */
function bindEvents() {
  document.querySelectorAll('.tab').forEach(function (t) {
    t.addEventListener('click', function () {
      document.querySelectorAll('.tab').forEach(function (x) { x.classList.remove('on'); });
      document.querySelectorAll('.panel').forEach(function (p) { p.classList.remove('on'); });
      t.classList.add('on');
      $('tab-' + t.dataset.tab).classList.add('on');
      if (t.dataset.tab === 'graph') renderGraph();
    });
  });
  $('btnOpen').addEventListener('click', function () {
    openRepo($('repoPath').value.trim() || state.repo || '~');
  });
  $('btnRefresh').addEventListener('click', function () { loadAll(true); });
  $('btnCommit').addEventListener('click', commitChanges);
  $('btnStageAll').addEventListener('click', function () {
    try { var out = runGit('add -A'); afterMutation(out.trim(), /error|fatal/i.test(out)); }
    catch (e) { toast(e.message, true); }
  });
  $('btnFetch').addEventListener('click', doFetch);
  $('btnPull').addEventListener('click', doPull);
  $('btnPush').addEventListener('click', doPush);
  $('btnNewBranch').addEventListener('click', newBranch);
  $('btnConflictContinue').addEventListener('click', conflictContinue);
  $('btnConflictAbort').addEventListener('click', conflictAbort);
  $('btnDiffClose').addEventListener('click', closeDrawer);
  $('drawerMask').addEventListener('click', function (e) { if (e.target === this) closeDrawer(); });
  $('commitSearch').addEventListener('input', renderCommitList);

  // graph click
  $('graphSvg').addEventListener('click', function (e) {
    var g = e.target.closest ? e.target.closest('.graph-commit') : null;
    if (g) selectCommit(g.dataset.hash);
  });
  // commit list click
  $('commitList').addEventListener('click', function (e) {
    var row = e.target.closest ? e.target.closest('.commit-row') : null;
    if (!row) return;
    var c = state.commits.filter(function (x) { return x.hash === row.dataset.hash; })[0];
    if (c) { selectCommit(c.hash); showCommitDiff(c.hash, c.subject); }
  });
  // changes click
  $('changeList').addEventListener('click', function (e) {
    var row = e.target.closest ? e.target.closest('.change-row') : null;
    if (!row) return;
    var op = e.target.dataset ? e.target.dataset.act : null;
    var path = row.dataset.path, xy = row.dataset.xy;
    if (op === 'stage') { stagePath(path); return; }
    if (op === 'unstage') { unstagePath(path); return; }
    if (op === 'discard') { discardPath(path, xy); return; }
    if (op === 'deluntracked') { discardPath(path, '??'); return; }
    // default: open diff
    var X = xy[0], Y = xy[1];
    var staged = (X !== ' ' && X !== '?') && (Y === ' ' || Y === '?');
    showFileDiff(path, staged);
  });
  // sidebar clicks
  $('branchList').addEventListener('click', function (e) {
    var item = e.target.closest ? e.target.closest('.list-item') : null;
    if (!item) return;
    var name = item.dataset.branch;
    var act = e.target.dataset ? e.target.dataset.act : null;
    if (act === 'checkout') checkoutBranch(name);
    else if (act === 'delbranch') deleteBranch(name);
  });
  $('stashList').addEventListener('click', function (e) {
    var item = e.target.closest ? e.target.closest('.list-item') : null;
    if (!item) return;
    var i = parseInt(item.dataset.stash, 10);
    var act = e.target.dataset ? e.target.dataset.act : null;
    if (act === 'stashapply') stashApply(i);
    else if (act === 'stashdrop') stashDrop(i);
  });
}

/* ---------------- init ---------------- */
function init() {
  try { ssh('echo ok'); updateConn(true); } catch (e) { updateConn(false); showOffline(); return; }
  try { state.home = ssh('echo $HOME').trim(); } catch (e) { state.home = ''; }
  if (!state.bound) { state.bound = true; bindEvents(); }
  // No typing on open: last used repo if we have one, otherwise the first discovered.
  repoCandidates = discoverRepos();
  var saved = savedRepo();
  openRepo(saved || repoCandidates[0] || '~');
}

init();
