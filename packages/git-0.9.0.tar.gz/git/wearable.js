/* Git Repo - wearable layer: worktree (state+actions) / commit / log, with the original
 * diff drawer reused. The phone page stays in the background and app.js does the work. */
(function () {
  'use strict';

  /** Three-screen routing: phone keeps the original HTML, square/round share one compact UI */
  function screenMode() {
    var c = document.documentElement.className || '';
    if (c.indexOf('shape-round') >= 0) return 'round';
    if (c.indexOf('shape-square') >= 0) return 'square';
    if (c.indexOf('wearable') >= 0) return 'square';
    return 'phone';
  }

  var TITLES = ['Changes', 'Commit', 'Log'];
  var root = null;
  var pagesEl = null;
  var dotsEl = null;
  var pageWorks = null;
  var pageCommit = null;
  var pageLog = null;
  var commitMsg = null;
  var commitAmend = null;
  var commitBtn = null;
  var started = false;
  var toastTimer = null;
  var lastWorksFp = '';
  var lastLogFp = '';

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;');
  }
  function connected() {
    return !!(typeof state !== 'undefined' && state && state.connected);
  }
  function wearToast(msg, err) {
    var w = root.querySelector('#wearToast');
    if (!w) return;
    w.textContent = msg;
    w.className = 'show' + (err ? ' err' : '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { w.className = ''; }, 3000);
  }

  function build() {
    root = document.createElement('div');
    root.id = 'wearRoot';
    root.setAttribute('data-screen', screenMode());
    root.innerHTML =
      '<div class="wear-head">'
      + '<button class="wear-back" id="wearBack">‹</button>'
        + '<div class="wear-title">Changes</div>'
      + '<span class="wear-dot off"></span></div>'
      + '<div class="wear-body"><div class="wear-pages" id="wearPages"></div></div>'
      + '<div class="wear-dots" id="wearDots"></div>'
      + '<div id="wearToast"></div>';
    document.body.appendChild(root);
    pagesEl = root.querySelector('#wearPages');
    dotsEl = root.querySelector('#wearDots');

    pageWorks = document.createElement('section');
    pageWorks.className = 'wear-page';
    pageWorks.id = 'wpage-works';
    pageCommit = document.createElement('section');
    pageCommit.className = 'wear-page';
    pageCommit.id = 'wpage-commit';
    pageLog = document.createElement('section');
    pageLog.className = 'wear-page';
    pageLog.id = 'wpage-log';
    pagesEl.appendChild(pageWorks);
    pagesEl.appendChild(pageCommit);
    pagesEl.appendChild(pageLog);

    var arr = [];
    for (var i = 0; i < 3; i++) arr.push('<i' + (i === 0 ? ' class="on"' : '') + '></i>');
    dotsEl.innerHTML = arr.join('');
    pagesEl.addEventListener('scroll', syncDots, { passive: true });
    dotsEl.addEventListener('click', function (e) {
      if (e.target && e.target.tagName === 'I') {
        var idx = Array.prototype.indexOf.call(dotsEl.children, e.target);
        goPage(idx);
      }
    });
    root.querySelector('#wearBack').addEventListener('click', function () { history.back(); });

    // Commit page (static structure)
    pageCommit.innerHTML =
      '<div class="w-section-title">COMMIT MESSAGE</div>'
      + '<textarea class="w-textarea" id="wearMsg" placeholder="Commit message..."></textarea>'
        + '<div class="w-optrow"><input type="checkbox" id="wearAmend"><span>amend last commit</span></div>'
      + '<div class="w-btnrow"><button class="primary" id="wearCommit">Commit</button></div>'
        + '<div class="w-section-title" id="wearCommitHint"></div>';
    commitMsg = root.querySelector('#wearMsg');
    commitAmend = root.querySelector('#wearAmend');
    commitBtn = root.querySelector('#wearCommit');
    commitBtn.addEventListener('click', doWearCommit);
  }

  function syncDots() {
    if (pagesEl.clientWidth <= 0) return;
    var i = Math.round(pagesEl.scrollLeft / pagesEl.clientWidth);
    var cs = dotsEl.children;
    for (var k = 0; k < cs.length; k++) cs[k].className = (k === i) ? 'on' : '';
    root.querySelector('.wear-title').textContent = TITLES[i] || '';
  }
  function goPage(i) {
    pagesEl.scrollTo({ left: i * pagesEl.clientWidth, behavior: 'smooth' });
  }

  function changeCode(f) {
    if (!f || !f.xy) return '?';
    var X = f.xy[0], Y = f.xy[1];
    if (X === '?' && Y === '?') return '?';
    return (Y !== ' ' && Y !== '?') ? Y : X;
  }
  function isStagedOnly(f) {
    var X = f.xy[0], Y = f.xy[1];
    return X !== ' ' && X !== '?' && (Y === ' ' || Y === '?');
  }

  function renderWorks() {
    if (!connected()) {
      lastWorksFp = '';
      pageWorks.innerHTML = '<div class="wear-empty">SSH not connected.</div>'
        + '<div style="text-align:center"><button id="wearRetry" style="'
        + 'background:#15152a;color:#9fd0ff;border:1px solid #2a2a4a;border-radius:7px;'
        + 'padding:4px 8px;font:8px monospace;cursor:pointer;">Retry</button></div>';
      var btn = pageWorks.querySelector('#wearRetry');
      if (btn) btn.addEventListener('click', function () {
        try { if (typeof init === 'function') init(); } catch (e) {}
      });
      return;
    }
    if (typeof state === 'undefined' || !state.repo) {
      lastWorksFp = '';
      pageWorks.innerHTML = '<div class="wear-empty">Loading repo…</div>';
      return;
    }
    var files = state.statusFiles || [];
    var staged = 0, unstaged = 0, untracked = 0;
    files.forEach(function (f) {
      if (f.xy === '??') untracked++;
      else {
        if (f.xy[0] !== ' ' && f.xy[0] !== '?') staged++;
        if (f.xy[1] !== ' ' && f.xy[1] !== '?') unstaged++;
      }
    });
    var conflict = state.opInProgress !== '' || files.some(function (f) {
      return f.xy[0] === 'U' || f.xy[1] === 'U';
    });
    var fp = JSON.stringify([
      state.branch, state.ahead, state.behind, conflict,
      (state.head && state.head.subject) || '',
      files.map(function (f) { return [f.xy, f.path]; })
    ]);
    if (fp === lastWorksFp && pageWorks.querySelector('.w-repo')) return;
    lastWorksFp = fp;
    var head = state.head || {};
    var html = '<div class="w-repo' + (conflict ? ' conflict' : '') + '">'
      + '<div><div class="br">⎇ ' + esc(state.branch || '(detached)') + '</div>'
      + '<div class="cnt">' + esc(head.subject || '') + '</div></div>'
        + '<span class="badge">' + (conflict ? 'conflict' : (staged + '/' + unstaged + '/' + untracked))
      + '</span></div>';

    if (conflict) {
      html += '<div class="wear-empty" style="padding:4px 3px;color:#ff8baa;font-size:8px;">'
        + esc('Unresolved conflicts.') + '</div>';
    }
    html += '<div class="w-btnrow">'
      + '<button id="bFetch">Fetch</button><button id="bPull">Pull</button>'
      + '<button id="bPush">Push</button></div>'
      + '<div class="w-btnrow">'
        + '<button id="bStage">Stage all</button><button class="primary" id="bGoCommit">Commit</button>'
        + '<button id="bRefresh">Refresh</button></div>';

    html += '<div class="w-section-title">CHANGES (' + files.length + ')</div>';
    if (!files.length) {
        html += '<div class="wear-empty" style="padding:8px 4px;">Nothing to commit.</div>';
    } else {
      var shown = files.slice(0, 8);
      shown.forEach(function (f) {
        html += '<div class="w-file" data-path="' + esc(f.path) + '" data-xy="' + esc(f.xy) + '">'
          + '<span class="code ' + esc(changeCode(f)) + '">' + esc(changeCode(f)) + '</span>'
          + '<span class="path">' + esc(f.orig ? f.orig + ' → ' + f.path : f.path) + '</span>'
          + '<span class="arrow">›</span></div>';
      });
      if (files.length > shown.length) {
        html += '<div class="wear-empty" style="padding:6px 4px;">'
          + (files.length - shown.length) + ' more files hidden</div>';
      }
    }
    pageWorks.innerHTML = html;

    root.querySelector('#bFetch').addEventListener('click', function () {
      try { doFetch(); } catch (e) { wearToast(e.message, true); }
    });
    root.querySelector('#bPull').addEventListener('click', function () {
      try { doPull(); } catch (e) { wearToast(e.message, true); }
    });
    root.querySelector('#bPush').addEventListener('click', function () {
      try { doPush(); } catch (e) { wearToast(e.message, true); }
    });
    root.querySelector('#bStage').addEventListener('click', function () {
      try { var b = document.getElementById('btnStageAll'); if (b) b.click(); }
      catch (e) { wearToast(e.message, true); }
    });
    root.querySelector('#bGoCommit').addEventListener('click', function () { goPage(1); });
    root.querySelector('#bRefresh').addEventListener('click', function () {
      try { loadAll(true); } catch (e) { wearToast(e.message, true); }
    });
    pageWorks.querySelectorAll('.w-file').forEach(function (row) {
      row.addEventListener('click', function () {
        var path = row.getAttribute('data-path');
        var xy = row.getAttribute('data-xy') || '??';
        var f = { path: path, xy: xy };
        try { showFileDiff(path, isStagedOnly(f)); }
        catch (e) { wearToast(e.message, true); }
      });
    });
  }

  function doWearCommit() {
    var msg = commitMsg.value.trim();
      if (!msg) { wearToast('Commit message is empty', true); return; }
    var staged = (state.statusFiles || []).some(function (f) {
      return f.xy[0] !== ' ' && f.xy[0] !== '?';
    });
    if (!staged && !commitAmend.checked) {
        wearToast('No staged files', true);
      return;
    }
    try {
      var origMsg = document.getElementById('commitMsg');
      var origAmend = document.getElementById('chkAmend');
      if (origMsg) origMsg.value = msg;
      if (origAmend) origAmend.checked = commitAmend.checked;
      commitChanges();
      commitMsg.value = '';
      commitAmend.checked = false;
        wearToast('Committed');
    } catch (e) {
      wearToast(e.message, true);
    }
  }

  function renderLog() {
    if (!connected() || typeof state === 'undefined') {
      lastLogFp = '';
      pageLog.innerHTML = '<div class="wear-empty">No log.</div>';
      return;
    }
    var commits = (state.commits || []).slice(0, 8);
    if (!commits.length) {
      lastLogFp = '';
      pageLog.innerHTML = '<div class="wear-empty">No commits.</div>';
      return;
    }
    var fp = JSON.stringify(commits.map(function (c) {
      return [c.hash, c.subject, c.author];
    }));
    if (fp === lastLogFp && pageLog.querySelector('.w-commit')) return;
    lastLogFp = fp;
    pageLog.innerHTML = '<div class="w-section-title">RECENT COMMITS</div>'
      + commits.map(function (c) {
          return '<div class="w-commit" data-hash="' + esc(c.hash) + '" data-subj="'
            + esc(c.subject) + '">'
            + '<span class="h">' + esc(String(c.hash).slice(0, 7)) + '</span>'
            + '<span class="s">' + esc(c.subject) + '</span>'
            + '<span class="m">' + esc(c.author || '') + '</span></div>';
        }).join('');
    pageLog.querySelectorAll('.w-commit').forEach(function (row) {
      row.addEventListener('click', function () {
        try {
          showCommitDiff(row.getAttribute('data-hash'), row.getAttribute('data-subj'));
        } catch (e) { wearToast(e.message, true); }
      });
    });
  }

  function mirrorToast() {
    var t = document.getElementById('toast');
    if (!t) return;
    if (t.className.indexOf('show') >= 0 && t.textContent) {
      wearToast(t.textContent, t.className.indexOf('err') >= 0);
    }
  }

  function tick() {
    var d = root.querySelector('.wear-dot');
    if (d) d.className = 'wear-dot ' + (connected() ? 'on' : 'off');
    renderWorks();
    renderLog();
    mirrorToast();
  }

  var tries = 0;
  var iv = setInterval(function () {
    if (screenMode() === 'phone') {
      if (++tries > 60) clearInterval(iv);
      return;
    }
    clearInterval(iv);
    if (started) return;
    started = true;
    // The wearable layer is built in the same task: lift vm-boot hiding
    try { var h = document.documentElement; if (h) {
      h.className = h.className.replace(/\bvm-boot\b/g, '').replace(/\s+/g, ' ').trim();
    } } catch(e) {}
    build();
    tick();
    setInterval(tick, 1200);
  }, 150);
})();
