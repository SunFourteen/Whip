/* System Info - square/round renderer (drawing only).
 * Data is collected by vm-core.js and pushed through subscriptions. */
(function () {
  'use strict';

  var sel = null;

  function cell(key, label) {
    var d = VmSysCore.getData();
    var isNet = key === 'net';
    var v = d ? (isNet ? VmSysCore.fmtBytes(d.rx) + '/s'
      : VmSysCore.pct(d[key + 'Pct'])) : 'Collecting…';
    var cls = isNet ? '' : VmSysCore.warn(d ? d[key + 'Pct'] : 0);
    return '<div class="tile ' + cls + '" data-k="' + key + '">'
      + '<div class="l">' + label + '</div>'
      + '<div class="v">' + v + '</div>'
      + '<div class="s">' + (key === 'cpu' ? 'cpu'
          : key === 'mem' ? 'mem'
          : key === 'disk' ? (d ? d.diskMount : 'disk')
          : 'tx ' + (d ? VmSysCore.fmtBytes(d.tx) + '/s' : '')) + '</div>'
      + '</div>';
  }

  function detail(d) {
    var el = document.getElementById('detail');
    if (!d || !sel) { if (el) el.className = ''; return; }
    var html = '';
    if (sel === 'cpu') {
      html = kv('user/sys/io', Math.round(d.cpuU) + '/' + Math.round(d.cpuS)
        + '/' + Math.round(d.cpuIo) + '%');
    } else if (sel === 'mem') {
      html = kv('used', VmSysCore.fmtBytes(d.memUsed))
        + kv('avail', VmSysCore.fmtBytes(d.memAvail));
    } else if (sel === 'disk') {
      html = kv('used', VmSysCore.fmtBytes(d.diskUsed))
        + kv('avail', VmSysCore.fmtBytes(d.diskAvail));
    } else if (sel === 'net') {
      html = kv('rx', VmSysCore.fmtBytes(d.rx) + '/s')
        + kv('tx', VmSysCore.fmtBytes(d.tx) + '/s');
    }
    el.innerHTML = html;
    el.className = 'show';
  }
  function kv(k, v) {
    return '<div class="kv"><span>' + k + '</span><b>'
      + (v == null ? '-' : v) + '</b></div>';
  }

  function draw(err) {
    var d = VmSysCore.getData();
    var dot = document.getElementById('dot');
    var on = false;
    try { on = !!SshBridge.isConnected(); } catch (e) {}
    if (dot) dot.className = 'dot ' + (on ? 'on' : 'off');
    var grid = document.querySelector('#body .grid');
    if (!grid) return;
    if (!d) {
      grid.innerHTML = '<div class="empty">' + (err ? 'Collect failed' : 'Collecting…')
        + '</div>';
      return;
    }
    if (grid.innerHTML.indexOf('data-k') < 0 || err) {
      grid.innerHTML = cell('cpu', 'CPU') + cell('mem', 'MEM')
        + cell('disk', 'DISK') + cell('net', 'NET');
      grid.querySelectorAll('.tile').forEach(function (t) {
        t.addEventListener('click', function () {
          sel = t.getAttribute('data-k');
          draw();
        });
      });
    } else {
      grid.querySelectorAll('.tile').forEach(function (t) {
        var k = t.getAttribute('data-k');
        var isNet = k === 'net';
        var v = t.querySelector('.v');
        var s = t.querySelector('.s');
        if (v) v.textContent = isNet ? VmSysCore.fmtBytes(d.rx) + '/s'
          : VmSysCore.pct(d[k + 'Pct']);
        if (s && isNet) s.textContent = 'tx ' + VmSysCore.fmtBytes(d.tx) + '/s';
        t.className = 'tile ' + (isNet ? '' : VmSysCore.warn(d[k + 'Pct']));
      });
    }
    detail(d);
  }

  document.getElementById('back').addEventListener('click', function () { history.back(); });
  var host = '';
  try { host = (JSON.parse(SshBridge.vmInfo() || '{}')).host || ''; } catch (e) {}
  VmSysCore.subscribe(function (d, err) { draw(err); });
  draw();
  VmSysCore.start(host);
})();
