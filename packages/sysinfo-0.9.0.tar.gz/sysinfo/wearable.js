/* System Info - wearable layer. Reuses the plugin's state and charts (the phone page
 * keeps refreshing in the background); this layer only renders. */
(function () {
  'use strict';

  /** Three-screen routing: phone keeps the original HTML, square/round share one compact UI */
  function screenMode() {
    var c = document.documentElement.className || '';
    if (c.indexOf('shape-round') >= 0) return 'round';
    if (c.indexOf('shape-square') >= 0) return 'square';
    if (c.indexOf('wearable') >= 0) return 'square';
    return 'phone';
  }

  var root = null;
  var homeEl = null;
  var metricEl = null;
  var pagesEl = null;
  var dotsEl = null;
  var started = false;
  var lastProcFetch = 0;

  function fmtBytes(n) {
    if (n == null || isNaN(n)) return '-';
    if (n < 1024) return n + ' B';
    var u = ['KB','MB','GB','TB','PB'], i = -1;
    do { n /= 1024; i++; } while (n >= 1024 && i < u.length - 1);
    return n.toFixed(n >= 100 ? 0 : n >= 10 ? 1 : 2) + ' ' + u[i];
  }
  function fmtRate(n) { return fmtBytes(n) + '/s'; }
  function pct(n) {
    n = Number(n);
    return isNaN(n) ? '-' : n.toFixed(0) + '%';
  }
  function cls(v) { return v >= 85 ? 'high' : (v >= 60 ? 'mid' : 'low'); }
  function last(series) {
    if (!series || !series.data || !series.data.length) return NaN;
    return series.data[series.data.length - 1] || NaN;
  }
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;');
  }
  function connected() {
    return !!(typeof state !== 'undefined' && state && state.connected);
  }

  function build() {
    root = document.createElement('div');
    root.id = 'wearRoot';
    root.setAttribute('data-screen', screenMode());
    root.innerHTML =
      '<div class="wear-head">'
      + '<button class="wear-back" id="wearBack">‹</button>'
      + '<div class="wear-title" id="wearTitle">Monitor</div>'
      + '<span class="wear-dot off"></span></div>'
      + '<div id="wearHome"></div>'
      + '<div id="wearMetric">'
      + '<div class="wear-pages" id="wearPages"></div>'
      + '<div class="wear-dots" id="wearDots"></div>'
      + '</div>';
    document.body.appendChild(root);
    homeEl = root.querySelector('#wearHome');
    metricEl = root.querySelector('#wearMetric');
    pagesEl = root.querySelector('#wearPages');
    dotsEl = root.querySelector('#wearDots');
    var back = root.querySelector('#wearBack');
    back.addEventListener('click', showHome);

    ['cpu', 'mem', 'disk', 'net'].forEach(function (k) {
      var sec = document.createElement('section');
      sec.className = 'wear-page';
      sec.id = 'wpage-' + k;
      pagesEl.appendChild(sec);
    });
    var arr = [];
    for (var i = 0; i < 4; i++) arr.push('<i' + (i === 0 ? ' class="on"' : '') + '></i>');
    dotsEl.innerHTML = arr.join('');
    pagesEl.addEventListener('scroll', syncDots, { passive: true });
    dotsEl.addEventListener('click', function (e) {
      if (e.target && e.target.tagName === 'I') {
        var idx = Array.prototype.indexOf.call(dotsEl.children, e.target);
        goPage(idx);
      }
    });
  }

  function syncDots() {
    if (pagesEl.clientWidth <= 0) return;
    var i = Math.round(pagesEl.scrollLeft / pagesEl.clientWidth);
    var cs = dotsEl.children;
    for (var k = 0; k < cs.length; k++) cs[k].className = (k === i) ? 'on' : '';
    if (i === 0) maybeFetchProcs();
  }
  function goPage(i) {
    pagesEl.scrollTo({ left: i * pagesEl.clientWidth, behavior: 'smooth' });
  }
  function showMetric(i) {
    homeEl.style.display = 'none';
    metricEl.classList.add('show');
    root.querySelector('#wearBack').classList.add('show');
    goPage(i);
    syncDots();
    maybeFetchProcs();
  }
  function showHome() {
    metricEl.classList.remove('show');
    homeEl.style.display = '';
    root.querySelector('#wearBack').classList.remove('show');
    root.querySelector('#wearTitle').textContent = 'Monitor';
  }
  function maybeFetchProcs() {
    if (typeof fetchProcs !== 'function') return;
    var now = Date.now();
    if (now - lastProcFetch > 4000) {
      lastProcFetch = now;
      try { fetchProcs(); } catch (e) {}
    }
  }

  function tile(label, val, sub, warn) {
    var c = warn === 'crit' ? ' crit' : warn === 'warn' ? ' warn' : '';
    return '<div class="wear-tile' + c + '"><div class="t-label">' + label + '</div>'
      + '<div class="t-val">' + esc(val) + '</div>'
      + '<div class="t-sub">' + esc(sub) + '</div></div>';
  }

  function renderHome() {
    if (!connected()) {
      homeEl.innerHTML = '<div class="wear-empty">SSH not connected.</div>'
        + '<div style="text-align:center"><button id="wearRetry" style="'
        + 'background:#15152a;color:#9fd0ff;border:1px solid #2a2a4a;border-radius:7px;'
      + 'padding:4px 8px;font:8px monospace;cursor:pointer;">Retry</button></div>';
      var btn = homeEl.querySelector('#wearRetry');
      if (btn) btn.addEventListener('click', function () {
        try { if (typeof init === 'function') init(); } catch (e) {}
      });
      return;
    }
    if (typeof state === 'undefined' || typeof charts === 'undefined') return;
    var cpu = last(charts.cpu.series[0]);
    var m = state.mem || {};
    var memPct = m.total ? (m.used / m.total * 100) : 0;
    var disks = state.disks || [];
    var rootDisk = null;
    for (var i = 0; i < disks.length; i++) {
      if (disks[i].mount === '/') { rootDisk = disks[i]; break; }
    }
    if (!rootDisk) rootDisk = disks[0];
    var dPct = rootDisk ? (rootDisk.pct || 0) : 0;
    root.querySelector('#wearTitle').textContent = 'Monitor · ' + (state.host || 'host');
    homeEl.innerHTML =
      '<div class="wear-grid">'
      + tile('CPU', pct(cpu), (state.cores || '-') + ' cores',
          cpu >= 85 ? 'crit' : cpu >= 60 ? 'warn' : '')
      + tile('MEM', pct(memPct),
          fmtBytes(m.used || 0) + ' / ' + fmtBytes(m.total || 0),
          memPct >= 85 ? 'crit' : memPct >= 60 ? 'warn' : '')
      + tile('DISK', dPct + '%', rootDisk ? rootDisk.mount : '-',
          dPct >= 85 ? 'crit' : dPct >= 60 ? 'warn' : '')
      + tile('NET', fmtRate(state.rxRate), 'TX ' + fmtRate(state.txRate), '')
      + '</div>';
    var ts = homeEl.querySelectorAll('.wear-tile');
    for (var k = 0; k < ts.length; k++) {
      (function (idx) {
        ts[idx].addEventListener('click', function () { showMetric(idx); });
      })(k);
    }
  }

  function bar(p) {
    var v = Math.max(0, Math.min(100, Number(p) || 0)).toFixed(0);
    return '<div class="w-barwrap"><div class="w-bar ' + cls(Number(p) || 0)
      + '" style="width:' + v + '%"></div></div>';
  }

  function renderMetricPages() {
    if (!connected() || typeof state === 'undefined' || typeof charts === 'undefined') return;

    var cpu = last(charts.cpu.series[0]);
    var cu = last(charts.cpuBig.series[0]);
    var cs = last(charts.cpuBig.series[1]);
    var cio = last(charts.cpuBig.series[2]);
    var cpuPage = root.querySelector('#wpage-cpu');
    var procs = (state.procs || []).slice().sort(function (a, b) { return b.cpu - a.cpu; })
      .slice(0, 3);
    cpuPage.innerHTML =
      '<div class="w-big">' + pct(cpu) + '<small> cpu</small></div>'
      + '<div class="w-kvrow"><span>user</span><b>' + pct(cu) + '</b></div>'
      + '<div class="w-kvrow"><span>system</span><b>' + pct(cs) + '</b></div>'
      + '<div class="w-kvrow"><span>iowait</span><b>' + pct(cio) + '</b></div>'
      + '<div class="w-sec"><div class="w-sec-title">TOP PROCESSES</div>'
      + (procs.length ? procs.map(function (p) {
          return '<div class="w-proc"><b>' + esc(p.pid) + '</b>'
            + '<span class="cmd">' + esc(p.cmd) + '</span>'
            + '<span class="pct">' + (Number(p.cpu) || 0).toFixed(0) + '%</span></div>';
      }).join('') : '<div class="wear-empty">No process data</div>')
      + '</div>';

    var m = state.mem || {};
    var memPct = m.total ? (m.used / m.total * 100) : 0;
    root.querySelector('#wpage-mem').innerHTML =
      '<div class="w-big">' + pct(memPct) + '<small> mem</small></div>'
      + bar(memPct)
      + '<div class="w-kvrow"><span>used</span><b>' + fmtBytes(m.used) + '</b></div>'
      + '<div class="w-kvrow"><span>available</span><b>' + fmtBytes(m.avail) + '</b></div>'
      + '<div class="w-kvrow"><span>swap</span><b>' + fmtBytes(m.swapUsed)
        + ' / ' + fmtBytes(m.swapTotal) + '</b></div>';

    var disks = (state.disks || []).slice(0, 4);
    root.querySelector('#wpage-disk').innerHTML = disks.length
      ? disks.map(function (d) {
          return '<div class="w-kvrow"><span>' + esc(d.mount) + '</span><b>'
            + fmtBytes(d.used) + ' / ' + fmtBytes(d.size) + ' (' + d.pct + '%)</b></div>'
            + bar(d.pct);
        }).join('')
      : '<div class="wear-empty">No disk data</div>';

    var ifs = (state.ifs || []).slice(0, 3);
    root.querySelector('#wpage-net').innerHTML =
      '<div class="w-big">' + fmtRate(state.rxRate) + '<small> ↓</small></div>'
      + '<div class="w-kvrow"><span>upload</span><b>' + fmtRate(state.txRate) + '</b></div>'
      + '<div class="w-sec"><div class="w-sec-title">INTERFACES</div>'
      + (ifs.length ? ifs.map(function (f) {
          return '<div class="w-kvrow"><span>' + esc(f.name)
            + (f.ip ? ' ' + esc(f.ip) : '')
            + '</span><b>↓ ' + fmtRate(f.rxRate) + ' ↑ ' + fmtRate(f.txRate) + '</b></div>';
      }).join('') : '<div class="wear-empty">No network data</div>')
      + '</div>';
  }

  function tick() {
    var d = root.querySelector('.wear-dot');
    if (d) d.className = 'wear-dot ' + (connected() ? 'on' : 'off');
    renderHome();
    renderMetricPages();
  }

  var tries = 0;
  var iv = setInterval(function () {
    if (screenMode() === 'phone') {
      if (++tries > 60) clearInterval(iv);
      return;
    }
    clearInterval(iv);
    if (started) return;
    started = true;
    // The wearable layer is built in the same task: lift vm-boot hiding
    try { var h = document.documentElement; if (h) {
      h.className = h.className.replace(/\bvm-boot\b/g, '').replace(/\s+/g, ' ').trim();
    } } catch(e) {}
    build();
    tick();
    setInterval(tick, 1200);
  }, 150);
})();
