'use strict';

/* ============================================================
 *  System Monitor plugin — pure HTML/CSS/JS, no external libs.
 *  All data comes from shell commands executed over the shared
 *  SSH session through SshBridge.run().
 * ============================================================ */

/* ---------------- utils ---------------- */
function $(id) { return document.getElementById(id); }
function esc(s) { return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function fmtBytes(n) {
  if (n == null || isNaN(n)) return '-';
  if (n < 1024) return n + ' B';
  var u = ['KB','MB','GB','TB','PB'], i = -1;
  do { n /= 1024; i++; } while (n >= 1024 && i < u.length - 1);
  return n.toFixed(n >= 100 ? 0 : n >= 10 ? 1 : 2) + ' ' + u[i];
}
function fmtRate(n) { return fmtBytes(n) + '/s'; }
function fmtPct(n) { return (isNaN(n) ? 0 : n).toFixed(1) + '%'; }
function fmtLoad(n) { return (isNaN(n) ? 0 : n).toFixed(2); }
function fmtDuration(sec) {
  sec = Math.floor(sec || 0);
  var d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600),
      m = Math.floor(sec % 3600 / 60), s = sec % 60;
  function p2(x) { return (x < 10 ? '0' : '') + x; }
  return (d > 0 ? d + 'd ' : '') + p2(h) + ':' + p2(m) + ':' + p2(s);
}
function pctClass(v) { return v >= 85 ? 'high' : (v >= 60 ? 'mid' : 'low'); }
var PCT_COLOR = { low: '#00D4AA', mid: '#d4aa00', high: '#d4004a' };

/* ---------------- toast / modal ---------------- */
var toastTimer = null;
function toast(msg, isErr) {
  var t = $('toast');
  t.textContent = msg;
  t.className = 'show' + (isErr ? ' err' : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function () { t.className = ''; }, 2600);
}
function confirmModal(title, bodyHtml, okLabel) {
  return new Promise(function (resolve) {
    $('modalTitle').textContent = title;
    $('modalBody').innerHTML = bodyHtml;
    var ok = $('modalOk');
    ok.textContent = okLabel || 'Confirm';
    ok.className = (okLabel === 'Kill' || okLabel === 'Delete') ? 'danger' : 'ghost';
    $('modal').classList.add('show');
    function done(v) { $('modal').classList.remove('show'); ok.onclick = null; $('modalCancel').onclick = null; resolve(v); }
    ok.onclick = function () { done(true); };
    $('modalCancel').onclick = function () { done(false); };
  });
}

/* ---------------- SSH bridge ---------------- */
function ssh(cmd) {
  if (typeof SshBridge === 'undefined') throw new Error('bridge missing');
  if (!SshBridge.isConnected()) throw new Error('disconnected');
  var r = JSON.parse(SshBridge.run(cmd, '{}'));
  if (!r.ok) {
    throw new Error('SSH error: ' + (r.error || ('exit ' + r.exitCode)) +
                   (r.stderr ? ' - ' + r.stderr.slice(0, 200) : ''));
  }
  return r.stdout || '';
}

/* ---------------- LineChart (canvas) ---------------- */
class LineChart {
  constructor(id, opts) {
    this.canvas = $(id);
    this.ctx = this.canvas.getContext('2d');
    this.series = (opts.series || [{ name: 'v', color: '#00D4AA' }]).map(function (s) {
      return { name: s.name, color: s.color, data: [], fmt: s.fmt || function (x) { return x; }, fill: s.fill !== false };
    });
    this.maxPoints = opts.maxPoints || 90;
    this.max = opts.max || 0;
    this.unit = opts.unit || '';
    // Fixed CSS logical height (canvas.height is dpr-scaled, never read it back)
    this.baseH = parseInt(this.canvas.getAttribute('height'), 10) || 120;
    this.cssW = 0; this.cssH = this.baseH;
    if (opts.legendId) { this.legendEl = $(opts.legendId); this.renderLegend(); }
    this.bindTooltip();
  }
  renderLegend() {
    if (!this.legendEl) return;
    this.legendEl.innerHTML = this.series.map(function (s) {
      return '<span><i style="background:' + s.color + '"></i>' + esc(s.name) + '</span>';
    }).join('');
  }
  push(values) {
    values.forEach(function (v, i) { this.series[i].data.push(v); }, this);
    var n = this.series[0].data.length;
    if (n > this.maxPoints) this.series.forEach(function (s) { s.data.shift(); });
    if (this.isVisible()) this.draw();
  }
  clear() { this.series.forEach(function (s) { s.data = []; }); this.draw(); }
  isVisible() { return this.canvas.offsetParent !== null; }
  resize() {
    // Cap dpr at 1.5: a full-size backing store on 3x screens exhausts WebView tile memory
    var dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    var w = this.canvas.clientWidth || 300;
    var h = this.baseH;
    this.cssW = w; this.cssH = h;
    this.canvas.width = Math.max(1, Math.round(w * dpr));
    this.canvas.height = Math.max(1, Math.round(h * dpr));
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.draw();
  }
  draw() {
    var ctx = this.ctx;
    var w = this.cssW || this.canvas.clientWidth || 300;
    var h = this.cssH || this.baseH;
    if (!w || !h) return;
    var padL = 42, padR = 8, padT = 8, padB = 18;
    var pw = w - padL - padR, ph = h - padT - padB;
    ctx.clearRect(0, 0, w, h);
    if (pw <= 0 || ph <= 0) return;

    var n = this.series[0].data.length;
    var maxVal = this.max;
    if (!maxVal) {
      maxVal = 1;
      this.series.forEach(function (s) {
        s.data.forEach(function (v) { if (v > maxVal) maxVal = v; });
      });
      maxVal *= 1.15;
    }
    if (this.max === 100) maxVal = 100;

    ctx.font = '9px monospace';
    var rows = 4, i;
    for (i = 0; i <= rows; i++) {
      var y = padT + ph - (ph * i / rows);
      ctx.strokeStyle = 'rgba(255,255,255,0.06)';
      ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(w - padR, y); ctx.stroke();
      var val = maxVal * i / rows;
      ctx.fillStyle = '#666';
      ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      ctx.fillText(this.unit === '%' ? Math.round(val) + '%' : this.series[0].fmt(val), padL - 5, y);
    }
    if (n < 2) return;
    var last = n - 1;

    this.series.forEach(function (s, si) {
      if (s.data.length < 2) return;
      ctx.strokeStyle = s.color; ctx.lineWidth = 1.6; ctx.lineJoin = 'round';
      ctx.beginPath();
      s.data.forEach(function (v, i) {
        var x = padL + pw * i / last, y = padT + ph - (v / maxVal) * ph;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      });
      ctx.stroke();
      if (s.fill && si === 0) {
        ctx.lineTo(padL + pw, padT + ph); ctx.lineTo(padL, padT + ph); ctx.closePath();
        var g = ctx.createLinearGradient(0, padT, 0, padT + ph);
        g.addColorStop(0, s.color + '44'); g.addColorStop(1, s.color + '00');
        ctx.fillStyle = g; ctx.fill();
      }
    });
  }
  bindTooltip() {
    var self = this;
    var tip = document.createElement('div');
    tip.style.cssText = 'position:fixed;background:#0a0a14;border:1px solid #33334a;color:#ccc;' +
      'border-radius:6px;padding:6px 9px;font:10px monospace;pointer-events:none;z-index:40;display:none;';
    document.body.appendChild(tip);
    this.canvas.addEventListener('mousemove', function (e) {
      var rect = self.canvas.getBoundingClientRect();
      var n = self.series[0].data.length;
      if (n < 1) return;
      var padL = 42, padR = 8;
      var pw = (self.cssW || rect.width) - padL - padR;
      var span = Math.min(n, self.maxPoints) - 1;
      var idx = Math.round((e.clientX - rect.left - padL) / pw * span);
      idx = Math.max(0, Math.min(n - 1, idx));
      var html = '';
      self.series.forEach(function (s) {
        html += '<div style="color:' + s.color + '">' + esc(s.name) + ': ' + s.fmt(s.data[idx]) + '</div>';
      });
      tip.innerHTML = html;
      tip.style.display = 'block';
      tip.style.left = (e.clientX + 12) + 'px';
      tip.style.top = (e.clientY + 10) + 'px';
    });
    this.canvas.addEventListener('mouseleave', function () { tip.style.display = 'none'; });
  }
}

/* ---------------- state ---------------- */
var state = {
  connected: false, intervalMs: 2000, paused: false,
  timer: null, busy: false,
  host: '', os: '', kernel: '', cpuModel: '', cores: 0,
  load: [0, 0, 0], uptime: 0, rxRate: 0, txRate: 0,
  mem: {}, disks: [], ifs: [], ports: [], procs: [],
  ipMap: {}, coreList: [],
  prevStat: null, prevCores: {}, prevNet: {}, lastTickTs: 0,
  procSort: { k: 'cpu', dir: -1 }, procFilter: '',
  tickCount: 0
};

/* ---------------- charts ---------------- */
var charts = {
  cpu:    new LineChart('chartCpu',    { series: [{ name: 'CPU', color: '#00D4AA', fmt: fmtPct }], max: 100, legendId: 'legendCpu' }),
  mem:    new LineChart('chartMem',    { series: [{ name: 'Memory', color: '#00A6FF', fmt: fmtPct }], max: 100, legendId: 'legendMem' }),
  net:    new LineChart('chartNet',    { series: [{ name: 'RX', color: '#00D4AA', fmt: fmtRate }, { name: 'TX', color: '#d4aa00', fmt: fmtRate }], legendId: 'legendNet' }),
  load:   new LineChart('chartLoad',   { series: [{ name: '1m', color: '#00D4AA', fmt: fmtLoad }, { name: '5m', color: '#00A6FF', fmt: fmtLoad }, { name: '15m', color: '#d4aa00', fmt: fmtLoad }] }),
  cpuBig: new LineChart('chartCpuBig', { series: [{ name: 'User', color: '#00D4AA', fill: true, fmt: fmtPct }, { name: 'System', color: '#d4aa00', fmt: fmtPct }, { name: 'I/O wait', color: '#d4004a', fmt: fmtPct }], max: 100, legendId: 'legendCpuBig' }),
  memBig: new LineChart('chartMemBig', { series: [{ name: 'Memory', color: '#00A6FF', fmt: fmtPct }], max: 100, legendId: 'legendMemBig' }),
  netBig: new LineChart('chartNetBig', { series: [{ name: 'RX', color: '#00D4AA', fmt: fmtRate }, { name: 'TX', color: '#d4aa00', fmt: fmtRate }], legendId: 'legendNetBig' })
};
var allCharts = [charts.cpu, charts.mem, charts.net, charts.load, charts.cpuBig, charts.memBig, charts.netBig];

/* ---------------- parsers ---------------- */
function parseStat(text) {
  var out = { cpu: null, cores: {} };
  text.split('\n').forEach(function (l) {
    l = l.trim(); if (!l) return;
    var p = l.split(/\s+/);
    if (p[0] === 'cpu') {
      var f = p.slice(1).map(Number);
      var idle = f[3] + f[4], user = f[0] + f[1], sys = f[2] + f[5] + f[6];
      out.cpu = { total: f.reduce(function (a, b) { return a + b; }, 0), idle: idle, user: user, sys: sys, io: f[4] };
    } else if (/^cpu\d+$/.test(p[0])) {
      var g = p.slice(1).map(Number);
      out.cores[p[0]] = { total: g.reduce(function (a, b) { return a + b; }, 0), idle: g[3] + g[4] };
    }
  });
  return out;
}
function cpuDelta(cur, prev) {
  if (!prev || !cur) return null;
  var d = cur.total - prev.total;
  if (d <= 0) return null;
  return {
    user: (cur.user - prev.user) / d * 100,
    sys: (cur.sys - prev.sys) / d * 100,
    io: (cur.io - prev.io) / d * 100,
    total: (d - (cur.idle - prev.idle)) / d * 100
  };
}
function parseMeminfo(text) {
  var m = {};
  text.split('\n').forEach(function (l) {
    var mm = l.match(/^(\w+):\s+(\d+)/);
    if (mm) m[mm[1]] = parseInt(mm[2], 10) * 1024;
  });
  var total = m.MemTotal || 0, avail = m.MemAvailable || 0;
  var used = total - avail;
  var buffCache = (m.Buffers || 0) + (m.Cached || 0) + (m.SReclaimable || 0);
  var st = m.SwapTotal || 0, sf = m.SwapFree || 0;
  return { total: total, used: used, avail: avail, buffCache: buffCache,
           swapTotal: st, swapUsed: st - sf, swapPct: st ? (st - sf) / st * 100 : 0 };
}
function parseNetDev(text) {
  var out = {};
  var lines = text.split('\n');
  for (var i = 2; i < lines.length; i++) {
    var l = lines[i]; if (!l.trim()) continue;
    var c = l.split(':');
    if (c.length < 2) continue;
    var f = c[1].trim().split(/\s+/).map(Number);
    out[c[0].trim()] = { rx: f[0] || 0, tx: f[8] || 0 };
  }
  return out;
}

/* ---------------- fetch & render ---------------- */
/* One SSH round trip per tick. Sections are labelled so the parser picks out the ones
 * this tick asked for: the heavy scans (disk / ports / processes) only run while their
 * tab is on screen, and everything travels in a single command. */
function buildTickCmd(want) {
  var cmds = [
    ['stat', 'cat /proc/stat'],
    ['mem', 'cat /proc/meminfo'],
    ['net', 'cat /proc/net/dev'],
    ['load', 'cat /proc/loadavg'],
    ['uptime', 'cat /proc/uptime'],
    ['host', 'hostname'],
    ['kernel', 'uname -srm'],
    ['cores', 'nproc'],
    ['cpuModel', "grep 'model name' /proc/cpuinfo | head -1 | cut -d: -f2"],
    ['os', "grep 'PRETTY_NAME' /etc/os-release 2>/dev/null | head -1 | cut -d= -f2 | tr -d '\"'"]
  ];
  if (want.disk) cmds.push(['disk', 'df -P -B1 -T 2>/dev/null']);
  if (want.net) {
    cmds.push(['ips', 'ip -4 -o addr show 2>/dev/null || hostname -I 2>/dev/null']);
    cmds.push(['ports', 'ss -tulnp 2>/dev/null | tail -n +2 || netstat -tulnp 2>/dev/null | tail -n +2']);
  }
  if (want.temp) {
    cmds.push(['temp', 'for z in /sys/class/thermal/thermal_zone*/temp; do ' +
      '[ -r "$z" ] && echo "$(basename $z):$(( $(cat $z) / 1000 ))"; done 2>/dev/null; true']);
  }
  if (want.proc) {
    cmds.push(['proc', 'ps -eo pid,ppid,user,%cpu,%mem,rss,etime,stat,comm,args ' +
      '--sort=-%cpu 2>/dev/null | head -n 151']);
  }
  return cmds.map(function (c) { return 'echo "==SEC:' + c[0] + '=="; ' + c[1]; }).join('; ');
}

function splitSections(raw) {
  var out = {};
  var parts = String(raw).split(/==SEC:([a-zA-Z]+)==\n?/);
  // First occurrence wins: `ps` prints this very command line, so the marker text also
  // shows up inside the proc section — those later hits must not overwrite real data.
  for (var i = 1; i + 1 < parts.length; i += 2) {
    if (!(parts[i] in out)) out[parts[i]] = parts[i + 1];
  }
  return out;
}

function tick() {
  if (state.busy) return;
  state.busy = true;
  try {
    var want = {
      disk: state.tickCount % 3 === 0,
      temp: state.tickCount % 12 === 0,
      net: $('tab-net').classList.contains('on'),
      proc: $('tab-proc').classList.contains('on')
    };
    var raw = ssh(buildTickCmd(want));
    var sec = splitSections(raw);
    if (!sec.stat || !sec.mem || !sec.net) throw new Error('unexpected output');

    var st = parseStat(sec.stat);
    state.mem = parseMeminfo(sec.mem);
    var net = parseNetDev(sec.net);
    var load = sec.load.trim().split(/\s+/).map(Number);
    state.load = [load[0] || 0, load[1] || 0, load[2] || 0];
    state.uptime = parseFloat(sec.uptime) || 0;
    state.host = sec.host.trim();
    state.kernel = sec.kernel.trim();
    state.cores = parseInt(sec.cores.trim(), 10) || 0;
    state.cpuModel = sec.cpuModel.trim();
    var os = sec.os.trim().replace(/^"|"$/g, '');
    if (os) state.os = os;
    if (sec.ips) applyIps(sec.ips);

    var now = Date.now();
    var d = cpuDelta(st.cpu, state.prevStat);
    state.prevStat = st.cpu;

    var coreList = [];
    Object.keys(st.cores).forEach(function (k) {
      var c = st.cores[k], p = state.prevCores[k];
      var pct = 0;
      if (p) {
        var dt = c.total - p.total;
        pct = dt > 0 ? Math.max(0, (dt - (c.idle - p.idle)) / dt * 100) : 0;
      }
      coreList.push({ name: k.replace('cpu', 'C'), pct: pct });
      state.prevCores[k] = c;
    });
    state.coreList = coreList;

    var rx = 0, tx = 0, ifRows = [];
    Object.keys(net).forEach(function (name) {
      var cur = net[name], p = state.prevNet[name];
      var el = now - state.lastTickTs;
      var rxr = 0, txr = 0;
      if (p && el > 0) { rxr = Math.max(0, (cur.rx - p.rx) / el * 1000); txr = Math.max(0, (cur.tx - p.tx) / el * 1000); }
      rx += rxr; tx += txr;
      ifRows.push({ name: name, rxRate: rxr, txRate: txr, rxTotal: cur.rx, txTotal: cur.tx, ip: state.ipMap[name] || '' });
    });
    ifRows.sort(function (a, b) { return b.rxRate - a.rxRate; });
    state.ifs = ifRows;
    state.prevNet = net;
    state.lastTickTs = now;
    state.rxRate = rx; state.txRate = tx;

    var memPct = state.mem.total ? state.mem.used / state.mem.total * 100 : 0;
    if (d) { charts.cpu.push([Math.max(0, Math.min(100, d.total))]); charts.cpuBig.push([Math.max(0, d.user), Math.max(0, d.sys), Math.max(0, d.io)]); }
    else { charts.cpu.push([0]); charts.cpuBig.push([0, 0, 0]); }
    charts.mem.push([memPct]); charts.memBig.push([memPct]);
    charts.load.push([state.load[0], state.load[1], state.load[2]]);
    charts.net.push([rx, tx]); charts.netBig.push([rx, tx]);

    renderOverview(); renderCpu(); renderMem(); renderNetRows();
    updateConn(true);

    state.tickCount++;
    if (sec.disk) applyDisks(sec.disk);
    if (sec.temp) applyTemps(sec.temp);
    if (sec.ports) applyPorts(sec.ports);
    if (sec.proc) applyProcs(sec.proc);
  } catch (e) {
    updateConn(false);
    if (String(e.message).indexOf('disconnected') >= 0 || String(e.message).indexOf('bridge') >= 0) {
      stopPolling(); showOffline();
    } else {
      toast('Monitor error: ' + e.message, true);
    }
  } finally {
    state.busy = false;
  }
}

function renderOverview() {
  $('ovHost').textContent = state.host || '-';
  $('ovOs').textContent = state.os || '-';
  $('ovKernel').textContent = state.kernel || '-';
  $('ovCpuModel').textContent = state.cpuModel || '-';
  $('ovCores').textContent = state.cores || '-';
  $('ovUptime').textContent = fmtDuration(state.uptime);
  var l = state.load;
  $('ovLoad1').textContent = '1m ' + fmtLoad(l[0]);
  $('ovLoad5').textContent = '5m ' + fmtLoad(l[1]);
  $('ovLoad15').textContent = '15m ' + fmtLoad(l[2]);
  [['ovLoad1', l[0]], ['ovLoad5', l[1]], ['ovLoad15', l[2]]].forEach(function (p) {
    var el = $(p[0]); el.className = 'pill';
    if (state.cores && p[1] > state.cores * 0.7) el.classList.add(p[1] > state.cores ? 'danger' : 'warn');
  });
  var m = state.mem;
  if (m.total) {
    var pct = m.used / m.total * 100;
    $('ovMemPct').textContent = fmtPct(pct);
    var b = $('ovMemBar');
    b.style.width = pct.toFixed(1) + '%'; b.className = 'bar mem ' + pctClass(pct);
    $('ovMemUsed').textContent = fmtBytes(m.used) + ' / ' + fmtBytes(m.total);
    $('ovMemSwap').textContent = m.swapTotal ? fmtBytes(m.swapUsed) + ' / ' + fmtBytes(m.swapTotal) : 'none';
  }
  $('ovNetRx').textContent = fmtRate(state.rxRate);
  $('ovNetTx').textContent = fmtRate(state.txRate);
}

function renderCpu() {
  var grid = $('coreGrid'); grid.innerHTML = '';
  (state.coreList || []).forEach(function (c) {
    grid.insertAdjacentHTML('beforeend',
      '<div class="core"><div class="name">' + c.name + '</div><div class="val">' + c.pct.toFixed(0) + '%</div>' +
      '<div class="bar-wrap"><div class="bar ' + pctClass(c.pct) + '" style="width:' + c.pct.toFixed(1) + '%"></div></div></div>');
  });
  var top = state.procs.slice().sort(function (a, b) { return b.cpu - a.cpu; }).slice(0, 10);
  var tb = $('cpuProcTable').querySelector('tbody'); tb.innerHTML = '';
  top.forEach(function (p) {
    tb.insertAdjacentHTML('beforeend',
      '<tr><td class="mono">' + p.pid + '</td><td>' + esc(p.user) + '</td>' +
      '<td class="num">' + p.cpu.toFixed(1) + '</td><td class="num">' + p.mem.toFixed(1) + '</td>' +
      '<td>' + esc(p.cmd) + '</td></tr>');
  });
}

function renderMem() {
  var m = state.mem; if (!m.total) return;
  var pct = m.used / m.total * 100;
  $('memBigPct').textContent = fmtPct(pct);
  var b = $('memBigBar');
  b.style.width = pct.toFixed(1) + '%'; b.className = 'bar mem ' + pctClass(pct);
  $('memUsed').textContent = fmtBytes(m.used);
  $('memAvail').textContent = fmtBytes(m.avail);
  $('memBuffCache').textContent = fmtBytes(m.buffCache);
  $('memSwap').textContent = m.swapTotal ? fmtBytes(m.swapUsed) + ' / ' + fmtBytes(m.swapTotal) + ' (' + m.swapPct.toFixed(0) + '%)' : 'none';
}

function applyDisks(raw) {
  try {
    var rows = [];
    var lines = raw.split('\n');
    for (var i = 1; i < lines.length; i++) {
      var l = lines[i].trim(); if (!l) continue;
      var parts = l.split(/\s+/); if (parts.length < 7) continue;
      rows.push({ fs: parts[0], type: parts[1], size: Number(parts[2]), used: Number(parts[3]), free: Number(parts[4]),
                  pct: parseInt(parts[5], 10) || 0, mount: parts.slice(6).join(' ') });
    }
    state.disks = rows;
    renderDiskSummary(); renderDiskTable();
  } catch (e) {}
}
function renderDiskSummary() {
  var el = $('ovDisks');
  if (!state.disks.length) { el.innerHTML = '<div class="kv"><span>No data</span><b>-</b></div>'; return; }
  el.innerHTML = state.disks.slice(0, 5).map(function (d) {
    return '<div class="kv"><span>' + esc(d.mount) + '</span><b>' + fmtBytes(d.used) + ' / ' + fmtBytes(d.size) + '</b></div>' +
      '<div class="bar-wrap"><div class="bar ' + pctClass(d.pct) + '" style="width:' + d.pct + '%"></div></div>';
  }).join('');
}
function renderDiskTable() {
  var tb = $('diskTable').querySelector('tbody'); tb.innerHTML = '';
  state.disks.forEach(function (d) {
    var color = PCT_COLOR[pctClass(d.pct)];
    tb.insertAdjacentHTML('beforeend',
      '<tr><td class="mono">' + esc(d.fs) + '</td><td>' + esc(d.type) + '</td>' +
      '<td class="num">' + fmtBytes(d.size) + '</td><td class="num">' + fmtBytes(d.used) + '</td>' +
      '<td class="num">' + fmtBytes(d.free) + '</td>' +
      '<td class="num"><span class="dbar"><i style="width:' + d.pct + '%;background:' + color + '"></i></span>' + d.pct + '%</td>' +
      '<td>' + esc(d.mount) + '</td></tr>');
  });
}

function renderNetRows() {
  var tb = $('ifTable').querySelector('tbody'); tb.innerHTML = '';
  (state.ifs || []).forEach(function (f) {
    tb.insertAdjacentHTML('beforeend',
      '<tr><td class="mono">' + esc(f.name) + '</td><td>' + esc(f.ip || '-') + '</td>' +
      '<td class="num">' + fmtRate(f.rxRate) + '</td><td class="num">' + fmtRate(f.txRate) + '</td>' +
      '<td class="num">' + fmtBytes(f.rxTotal) + '</td><td class="num">' + fmtBytes(f.txTotal) + '</td></tr>');
  });
}
function applyIps(raw) {
  try {
    var map = {};
    raw.split('\n').forEach(function (l) {
      var m = l.match(/^\d+:\s+(\w+)[^0-9]*inet\s+([0-9.]+)/);
      if (m) map[m[1]] = m[2];
    });
    state.ipMap = map;
    renderNetRows();
  } catch (e) {}
}
function applyTemps(raw) {
  try {
    var rows = [];
    raw.split('\n').forEach(function (l) {
      var c = l.split(':');
      if (c.length === 2 && !isNaN(parseInt(c[1], 10))) rows.push({ name: c[0], temp: parseInt(c[1], 10) });
    });
    if (rows.length) {
      $('cardTemp').style.display = '';
      $('tempList').innerHTML = rows.map(function (t) {
        return '<span class="temp-chip">' + esc(t.name) + ' <b>' + t.temp + '°C</b></span>';
      }).join('');
    } else {
      $('cardTemp').style.display = 'none';
    }
  } catch (e) {}
}
function applyPorts(raw) {
  try {
    var rows = [];
    raw.split('\n').forEach(function (l) {
      l = l.trim(); if (!l) return;
      var m = l.match(/^(tcp6?|udp6?)\s+(\S+)\s+\S+\s+\S+\s+(\S+)\s+\S+\s+(.*)$/);
      if (m) { rows.push({ proto: m[1], state: m[2], local: m[3], proc: m[4] || '' }); return; }
      var m2 = l.match(/^(tcp6?|udp6?)\s+\S+\s+\S+\s+(\S+)\s+\S+\s+(\S+)\s+(.*)$/);
      if (m2) rows.push({ proto: m2[1], local: m2[2], state: m2[3], proc: m2[4] || '' });
    });
    state.ports = rows;
    var tb = $('portTable').querySelector('tbody'); tb.innerHTML = '';
    rows.forEach(function (p) {
      tb.insertAdjacentHTML('beforeend',
        '<tr><td class="mono">' + esc(p.proto) + '</td><td>' + esc(p.local) + '</td>' +
        '<td>' + esc(p.state) + '</td><td class="dim">' + esc(p.proc) + '</td></tr>');
    });
  } catch (e) {}
}
function applyProcs(raw) {
  try {
    var rows = [];
    var lines = raw.split('\n');
    for (var i = 1; i < lines.length; i++) {
      var l = lines[i]; if (!l.trim()) continue;
      var t = l.trim().split(/\s+/); if (t.length < 9) continue;
      // Skip the collector's own processes (their command line contains the markers).
      if (l.indexOf('==SEC:') >= 0) continue;
      rows.push({ pid: t[0], ppid: t[1], user: t[2], cpu: parseFloat(t[3]) || 0, mem: parseFloat(t[4]) || 0,
                  rss: Number(t[5]) * 1024 || 0, etime: t[6], stat: t[7], comm: t[8], cmd: t.slice(9).join(' ') });
    }
    state.procs = rows;
    renderProcs();
  } catch (e) {}
}
function renderProcs() {
  var q = state.procFilter.toLowerCase();
  var list = state.procs.filter(function (p) {
    if (!q) return true;
    return (p.cmd + ' ' + p.pid + ' ' + p.user).toLowerCase().indexOf(q) >= 0;
  });
  var k = state.procSort.k, dir = state.procSort.dir;
  list.sort(function (a, b) {
    var va = a[k], vb = b[k];
    if (typeof va === 'string') return va.localeCompare(vb) * dir;
    return ((va || 0) - (vb || 0)) * dir;
  });
  $('procCount').textContent = list.length + ' shown';
  var tb = $('procTable').querySelector('tbody'); tb.innerHTML = '';
  list.forEach(function (p) {
    tb.insertAdjacentHTML('beforeend',
      '<tr><td class="mono">' + p.pid + '</td><td>' + esc(p.user) + '</td>' +
      '<td class="num">' + p.cpu.toFixed(1) + '</td><td class="num">' + p.mem.toFixed(1) + '</td>' +
      '<td class="num">' + fmtBytes(p.rss) + '</td><td>' + esc(p.etime) + '</td><td>' + esc(p.stat) + '</td>' +
      '<td>' + esc(p.cmd) + '</td>' +
      '<td><button class="ghost kill" data-pid="' + p.pid + '" data-cmd="' + esc(p.cmd) + '">Kill</button></td></tr>');
  });
}

/* ---------------- events ---------------- */
document.querySelectorAll('.tab').forEach(function (t) {
  t.addEventListener('click', function () {
    document.querySelectorAll('.tab').forEach(function (x) { x.classList.remove('on'); });
    document.querySelectorAll('.panel').forEach(function (p) { p.classList.remove('on'); });
    t.classList.add('on');
    $('tab-' + t.dataset.tab).classList.add('on');
    allCharts.forEach(function (c) { c.resize(); });
    // A tick now carries the sections for whichever tab is visible.
    tick();
  });
});
$('intervalSel').addEventListener('change', function () {
  state.intervalMs = parseInt(this.value, 10) || 0;
  if (state.intervalMs > 0) tick();
  startPolling();
});
$('btnPause').addEventListener('click', function () {
  state.paused = !state.paused;
  this.innerHTML = state.paused ? '&#9654;' : '&#9208;';
  this.title = state.paused ? 'Resume' : 'Pause';
  if (state.paused) stopPolling(); else { tick(); startPolling(); }
});
$('btnRefresh').addEventListener('click', function () { tick(); });
$('procSearch').addEventListener('input', function () { state.procFilter = this.value.trim(); renderProcs(); });
document.querySelectorAll('#procTable th[data-k]').forEach(function (th) {
  th.addEventListener('click', function () {
    var k = th.dataset.k;
    if (state.procSort.k === k) state.procSort.dir *= -1;
    else { state.procSort.k = k; state.procSort.dir = (k === 'cmd' || k === 'user' || k === 'etime' || k === 'stat') ? 1 : -1; }
    renderProcs();
  });
});
document.addEventListener('click', function (e) {
  var b = e.target.closest ? e.target.closest('.kill') : null;
  if (!b) return;
  var pid = b.dataset.pid, cmd = b.dataset.cmd;
  confirmModal('Kill process ' + pid + '?', 'Terminate <span class="mono">' + esc(cmd) + '</span> with <b>SIGKILL</b>?', 'Kill').then(function (ok) {
    if (!ok) return;
    try {
      var r = ssh('kill -9 ' + pid + ' 2>&1');
      toast('kill -9 ' + pid + ' done', r && r.indexOf('Error') === 0);
      setTimeout(tick, 400);
    } catch (err) { toast(err.message, true); }
  });
});
document.addEventListener('visibilitychange', function () {
  if (document.hidden) stopPolling();
  else if (state.intervalMs > 0 && !state.paused) { tick(); startPolling(); }
});

/* ---------------- polling ---------------- */
function startPolling() {
  stopPolling();
  if (state.intervalMs <= 0 || state.paused) return;
  state.timer = setTimeout(function () { tick(); startPolling(); }, state.intervalMs);
}
function stopPolling() { clearTimeout(state.timer); state.timer = null; }

function updateConn(on) {
  state.connected = on;
  $('connDot').className = 'dot ' + (on ? 'on' : 'off');
  $('hostLabel').textContent = state.host || '';
}

function showOffline() {
  var el = document.createElement('div');
  el.id = 'offlineMask';
  el.style.cssText = 'position:fixed;inset:0;background:#1A1A2E;display:flex;flex-direction:column;' +
    'align-items:center;justify-content:center;gap:12px;z-index:100;';
  el.innerHTML = '<div style="color:#d4004a;font-size:38px">&#9679;</div>' +
    '<div style="color:#fff;font-size:15px">SSH not connected</div>' +
    '<div style="color:#888;font-size:12px">Connect in the Terminal tab first, then come back here.</div>' +
    '<button class="ghost" id="retryBtn">Retry</button>';
  document.body.appendChild(el);
  $('retryBtn').onclick = function () {
    try { ssh('echo ok'); el.remove(); init(); } catch (e) {}
  };
}

function init() {
  try { ssh('echo ok'); } catch (e) { updateConn(false); showOffline(); return; }
  updateConn(true);
  tick();   // one round trip: sections for the visible tab are included
  startPolling();
}

window.addEventListener('load', function () { allCharts.forEach(function (c) { c.resize(); }); });
init();
