'use strict';

/* Agent Monitor - fallback wearable layer for remote copies that lack square/round
 * entries. Same data source as VM/phone: base Agents + Driver. */
(function () {
  function screenMode() {
    var c = document.documentElement.className || '';
    if (c.indexOf('shape-round') >= 0) return 'round';
    if (c.indexOf('shape-square') >= 0) return 'square';
    if (c.indexOf('wearable') >= 0) return 'square';
    return 'phone';
  }

  var BASE = (typeof WhipBase !== 'undefined') ? WhipBase : null;
  var Driver = BASE ? BASE.Driver : null;
  var Agents = BASE ? BASE.Agents : null;
  var DETAIL = /index\.html(\?|$)/.test(location.pathname);
  var qAgent = '', qSession = '';
  if (DETAIL) {
    try {
      var u = new URLSearchParams(location.search);
      qAgent = u.get('agent') || '';
      qSession = u.get('session') || '';
    } catch (e) {}
  }
  var root = null;
  var pagesEl = null;
  var dotsEl = null;
  var l3 = null;
  var l3Body = null;
  var lastFp = '';
  var lastHomeFp = '';
  var started = false;

  var CFG = {
    cardsPath: '/root/.whip/monitor/state/cards.json',
    livePath: '/root/.whip/monitor/state/agent.ndjson',
    feedId: DETAIL ? 'agent-events-wear-detail' : 'agent-events-wear-home',
    backlog: 30,
    legacyArchKey: 'summ_archived_v1',
    monitorIds: ['agent-base', 'agent-monitor', 'agent-summarizer']
  };
  if (DETAIL && qSession) {
    CFG.focus = { agent: qAgent, sessionId: qSession, requireRaw: true };
  }

  function ensureDriver() {
    if (!BASE) return;
    if (!Driver) { Driver = BASE.Driver; Agents = BASE.Agents; }
    if (Driver && !Driver.cfg) Driver.start(CFG);
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  function cap(s, n) {
    s = String(s == null ? '' : s);
    return s.length > n ? s.slice(0, n) + '…' : s;
  }
  function ago(ms) {
    if (!ms) return '';
    var s = Math.max(0, Math.floor((Date.now() - ms) / 1000));
    if (s < 60) return s + 's';
    if (s < 3600) return Math.floor(s / 60) + 'm';
    return Math.floor(s / 3600) + 'h';
  }
  function conn() {
    try { return !!SshBridge.isConnected(); } catch (e) { return false; }
  }
  function dot() {
    var d = root && root.querySelector('.wear-dot');
    if (d) d.className = 'wear-dot ' + (conn() ? 'on' : 'off');
  }

  function makePage(inner) {
    var sec = document.createElement('section');
    sec.className = 'wear-page';
    sec.innerHTML = inner || '';
    return sec;
  }

  function buildShell(title, pagesHtml, dots, back) {
    root = document.createElement('div');
    root.id = 'wearRoot';
    root.setAttribute('data-screen', screenMode());
    var head = '<div class="wear-head">'
      + (back ? '<button class="wear-back" id="wearBack">‹</button>' : '')
      + '<div class="wear-title">' + esc(title) + '</div>'
      + '<span class="wear-dot off" id="wearDot"></span>'
      + '</div>';
    root.innerHTML = head
      + '<div class="wear-body"><div class="wear-pages" id="wearPages"></div></div>'
      + '<div class="wear-dots" id="wearDots"></div>'
      + '<div class="wear-l3" id="wearL3"><div class="wear-head">'
      + '<button class="wear-back" id="wearL3Back">‹</button>'
        + '<div class="wear-title">Events</div></div>'
      + '<div class="wear-l3-body" id="wearL3Body"></div></div>';
    document.body.appendChild(root);

    pagesEl = root.querySelector('#wearPages');
    dotsEl = root.querySelector('#wearDots');
    l3 = root.querySelector('#wearL3');
    l3Body = root.querySelector('#wearL3Body');

    pagesHtml.forEach(function (p) { pagesEl.appendChild(makePage(p)); });
    var n = pagesHtml.length;
    if (n > 1) {
      var arr = [];
      for (var i = 0; i < n; i++) arr.push('<i' + (i === 0 ? ' class="on"' : '') + '></i>');
      dotsEl.innerHTML = arr.join('');
      dotsEl.style.display = 'flex';
      pagesEl.addEventListener('scroll', syncDots, { passive: true });
      dotsEl.addEventListener('click', function (e) {
        if (e.target && e.target.tagName === 'I') {
          var idx = Array.prototype.indexOf.call(dotsEl.children, e.target);
          goPage(idx);
        }
      });
    } else {
      dotsEl.style.display = 'none';
    }
    var b = root.querySelector('#wearBack');
    if (b) b.addEventListener('click', function () { history.back(); });
    var b3 = root.querySelector('#wearL3Back');
    if (b3) b3.addEventListener('click', closeL3);
  }

  function syncDots() {
    if (!pagesEl || pagesEl.clientWidth <= 0) return;
    var i = Math.round(pagesEl.scrollLeft / pagesEl.clientWidth);
    var cs = dotsEl.children;
    for (var k = 0; k < cs.length; k++) {
      cs[k].className = k === i ? 'on' : '';
    }
  }
  function goPage(i) {
    if (!pagesEl) return;
    pagesEl.scrollTo({ left: i * pagesEl.clientWidth, behavior: 'smooth' });
  }
  function openL3(text, title) {
    if (title) {
      var th = l3.querySelector('.wear-title');
      if (th) th.textContent = title;
    }
    l3Body.innerHTML = esc(text);
    l3.classList.add('show');
  }
  function closeL3() {
    l3.classList.remove('show');
    l3Body.innerHTML = '';
  }

  function shellList() {
    try {
      var arr = JSON.parse(SshBridge.listShells() || '[]');
      return Array.isArray(arr) ? arr : [];
    } catch (e) { return []; }
  }
  function matchedShell(tty) {
    if (!tty) return null;
    var list = shellList();
    for (var i = 0; i < list.length; i++) {
      if (list[i] && list[i].tty === tty) return list[i];
    }
    return null;
  }
  function rowJump(r) {
    if (!BASE || !r) return;
    var sh = matchedShell((r.details && r.details.tty) || '');
    if (sh && r.isActive) { jumpToShell(sh); return; }
    var ws = (r.details && r.details.workspace) || '';
    var cmd = BASE.resumeCmd(r.agent, r.sessionId);
    if (ws || cmd) {
      try {
        JSON.parse(SshBridge.openShellWith(ws || '', cmd));
      } catch (e) {
        openL3('Resume failed: ' + e.message, 'Resume');
      }
      return;
    }
    openTermChooser();
  }
  function jumpToShell(sh) {
    if (!sh || !sh.id) return;
    try {
      var r = JSON.parse(SshBridge.openTerminalShell(sh.id));
      if (!r || !r.ok) {
        openL3('Cannot open terminal: ' + (r && r.error ? r.error : 'unknown'), 'Terminal');
      }
    } catch (e) {
      openL3('Terminal failed: ' + e.message, 'Terminal');
    }
  }
  function openTermChooser() {
    var shells = shellList();
    if (!shells.length) {
      openL3('No terminal shells.', 'Terminal');
      return;
    }
    if (shells.length === 1) { jumpToShell(shells[0]); return; }
    var html = '';
    shells.forEach(function (sh) {
      html += '<div class="wear-term-row" data-id="' + esc(sh.id) + '">'
        + '<span class="tn">' + esc(sh.name || sh.id) + '</span>'
        + '<span class="ts' + (sh.status === 'closed' ? ' closed' : '') + '">'
        + (sh.status === 'closed' ? 'closed' : 'running') + '</span></div>';
    });
    l3Body.innerHTML = html;
    var th = l3.querySelector('.wear-title');
    if (th) th.textContent = 'Select terminal';
    l3.classList.add('show');
    l3Body.querySelectorAll('.wear-term-row').forEach(function (row) {
      row.addEventListener('click', function () {
        var id = row.getAttribute('data-id');
        var found = null;
        shells.forEach(function (sh) { if (sh.id === id) found = sh; });
        closeL3();
        jumpToShell(found);
      });
    });
  }

  function homePage() {
    return '<div class="wear-page" id="wearHome"><div class="wear-empty">Connecting…</div></div>';
  }

  function renderHome() {
    var page = root.querySelector('#wearHome');
    if (!conn()) {
      page.innerHTML = '<div class="wear-empty">SSH not connected.</div>';
      return;
    }
    if (!Driver || !Agents) {
      page.innerHTML = '<div class="wear-empty">Data layer not ready.</div>';
      return;
    }
    var rs = Driver.rows();
    if (!rs.length) {
      lastHomeFp = '';
      page.innerHTML = '<div class="wear-empty">No agent sessions.</div>';
      return;
    }
    var fp = JSON.stringify(rs.map(function (r) {
      var d = r.details || {};
      return [r.agent, r.sessionId, r.state, r.lastActiveMs, r.seq,
        r.isActive ? 1 : 0, d.tty, d.tool, d.action, d.result, d.message,
        d.status, d.liveState, d.rounds || 0, d.tools || 0, d.subs || 0];
    }));
    if (fp === lastHomeFp) return;
    lastHomeFp = fp;
    var groups = {};
    rs.forEach(function (r) {
      groups[r.agent] = (groups[r.agent] || 0) + 1;
      r.__n = groups[r.agent];
    });
    var html = '';
    rs.forEach(function (r) {
      var st = BASE.stateUI(r.state || 'idle');
      var name = (groups[r.agent] > 1)
        ? (r.agent + ' #' + r.__n) : (r.name || r.agent);
      html += '<div class="wear-row' + (r.isActive ? ' live' : '')
        + '" data-agent="' + esc(r.agent) + '" data-sid="'
        + esc(r.sessionId) + '">'
        + '<span class="wear-stdot" style="background:' + st.color + '"></span>'
        + '<span class="wear-row-main"><span class="wear-row-name">' + esc(name)
        + (r.isActive ? ' ●' : '') + '</span>'
        + '<div class="wear-row-sub">' + esc(r.agent) + ' · '
        + ago(r.lastActiveMs) + ' ago</div>'
        + (r.details && (r.details.tool || r.details.action)
            ? '<div class="wear-row-sub2">'
              + esc(cap((r.details.tool || '-')
                + (r.details.action ? ' · ' + r.details.action : ''), 56))
              + '</div>' : '')
        + '</span>'
        + '<span class="wear-state" style="background:' + st.color + '">'
        + esc(st.label) + '</span>'
        + '<button class="wear-term" type="button">›_</button>'
        + '<button class="wear-term wear-arch" type="button">Arc</button>'
        + '</div>';
    });
    page.innerHTML = html;
    page.querySelectorAll('.wear-row').forEach(function (row) {
      var agent = row.getAttribute('data-agent');
      var sid = row.getAttribute('data-sid');
      row.addEventListener('click', function () {
        location.href = 'index.html?agent=' + encodeURIComponent(agent)
          + '&session=' + encodeURIComponent(sid);
      });
      var tb = row.querySelector('.wear-term');
      if (tb) {
        tb.addEventListener('click', function (e) {
          e.stopPropagation();
          rowJump(Agents.find(agent, sid));
        });
      }
      var ab = row.querySelector('.wear-arch');
      if (ab) {
        ab.addEventListener('click', function (e) {
          e.stopPropagation();
          Agents.archive(agent, sid);
          renderHome();
        });
      }
    });
  }

  function detailPages() {
    return [
      '<div class="wear-page" id="wearNow"><div class="wear-now">'
      + '<div class="wear-chiprow" id="wearChips"></div>'
      + '<div id="wearMsg" class="wear-msgbox"></div>'
      + '<div class="wear-kvs" id="wearKvs"></div>'
      + '<div class="wear-actions"><button class="wear-termbtn" id="wearTermBtn" type="button">›_ Terminal</button>'
      + '<button class="wear-termbtn" id="wearArchBtn" type="button">Archive</button></div>'
      + '</div></div>',
      '<div class="wear-page" id="wearEvt"><div class="wear-empty">No events.</div></div>'
    ];
  }

  function nowInnerHtml() {
    return '<div class="wear-chiprow" id="wearChips"></div>'
      + '<div class="wear-msgbox" id="wearMsg"></div>'
      + '<div class="wear-kvs" id="wearKvs"></div>'
      + '<div class="wear-actions"><button class="wear-termbtn" id="wearTermBtn" type="button">›_ Terminal</button>'
      + '<button class="wear-termbtn" id="wearArchBtn" type="button">Archive</button></div>';
  }

  function current() {
    if (!Driver || !Agents) return null;
    if (!qSession) return Driver.rows()[0] || null;
    // Same as the phone detail: archived sessions load the full card too, undo carries the key
    if (Agents.isArchived(qAgent || '', qSession)) {
      return Driver.ensureFocus(true)
        || Agents.ensure(qAgent || '', qSession) || null;
    }
    return Driver.ensureFocus(true) || null;
  }

  function snapFp(s) {
    if (!s) return '';
    var d = s.details || {};
    return JSON.stringify([s.agent, s.sessionId, s.state, d.tool, s.lastActiveMs,
      s.seq, d.message, (d.events || []).slice(-8), d.tty, d.action, d.result,
      d.status, d.liveState, d.rounds || 0, d.tools || 0, d.subs || 0]);
  }

  /* Monitoring surface: the small-screen detail expands the card fields. */
  function kvsHtml(d) {
    var kv = function (k, v) {
      return '<div class="wear-kv"><span>' + esc(k) + '</span><b>'
        + esc(v == null || v === '' ? '—' : cap(String(v), 90)) + '</b></div>';
    };
    return kv('tool', d.tool) + kv('action', d.action) + kv('result', d.result)
      + kv('workspace', d.workspace) + kv('tty', d.tty)
      + kv('r/t/s', (d.rounds || 0) + '/' + (d.tools || 0) + '/'
        + (d.subs || 0))
      + kv('status', (d.status || '') + (d.liveState
        ? (d.status ? ' · ' : '') + d.liveState : ''));
  }

  function renderDetail() {
    ensureDriver();
    var nowPage = root.querySelector('#wearNow');
    if (!conn()) {
      lastFp = '';
      nowPage.innerHTML = '<div class="wear-now"><div class="wear-empty">SSH not connected.</div></div>';
      var evEl2 = root.querySelector('#wearEvt');
      if (evEl2) evEl2.innerHTML = '<div class="wear-empty">SSH not connected.</div>';
      return;
    }
    var nowInner = nowPage.querySelector('.wear-now');
    if (!nowInner || !nowInner.querySelector('#wearChips')) {
      nowInner.innerHTML = nowInnerHtml();
    }
    var s = current();
    if (!s) {
      lastFp = '';
      nowPage.innerHTML = '<div class="wear-now"><div class="wear-empty">Waiting for agent state…</div></div>';
      return;
    }
    if (Agents.isArchived(s.agent, s.sessionId)) {
      var fpA = 'archived:' + s.agent + '\u0001' + s.sessionId;
      if (fpA !== lastFp) {
        lastFp = fpA;
        nowPage.innerHTML = '<div class="wear-now">'
          + '<div class="wear-chiprow" id="wearChips">'
          + '<span class="wear-chip" style="background:#555">archived</span></div>'
          + '<div class="wear-msgbox">Session archived.</div>'
          + '<div class="wear-actions">'
          + '<button class="wear-termbtn" id="wearUnarchBtn" type="button">Unarchive</button>'
          + '</div></div>';
        var evElA = root.querySelector('#wearEvt');
        if (evElA) evElA.innerHTML = '<div class="wear-empty">(archived)</div>';
      }
      var ub = nowPage.querySelector('#wearUnarchBtn');
      if (ub) {
        ub.onclick = function () {
          Driver.unarchive(s.agent, s.sessionId, s.key);
          Driver.loadCard(s.agent, s.sessionId, s.key);
          nowPage.innerHTML = '<div class="wear-now">' + nowInnerHtml() + '</div>';
          lastFp = '';
          renderDetail();
        };
      }
      dot();
      return;
    }
    var d = s.details || {};
    var st = BASE.stateUI(s.state || 'idle');
    var chips = '<span class="wear-chip" style="background:' + st.color + '">'
      + '<span class="wear-stdot" style="background:#fff"></span>'
      + esc(st.label) + '</span>'
      + (d.tool ? '<span class="wear-chip tool">' + esc(cap(d.tool, 18)) + '</span>' : '')
      + (s.lastActiveMs ? '<span class="wear-chip ago">' + ago(s.lastActiveMs) + ' ago</span>' : '');
    var msgEl = nowPage.querySelector('#wearMsg');
    var cls = 'wear-msgbox';
    if (s.state === 'requirePermission') cls += ' wait';
    else if (s.state === 'done') cls += ' alert';
    var text = d.message;
    if (!text && s.state === 'requirePermission') {
      text = 'Waiting for approval.';
    }
    if (!text && d.tool) text = d.tool + ' running…';
    msgEl.className = cls;
    msgEl.innerHTML = text
      ? esc(text)
      : '<span class="wear-empty-msg">Waiting for agent output…</span>';
    var fp = snapFp(s);
    if (fp !== lastFp) {
      lastFp = fp;
      var chipsEl = nowPage.querySelector('#wearChips');
      if (chipsEl) chipsEl.innerHTML = chips;
      var kvsEl = nowPage.querySelector('#wearKvs');
      if (kvsEl) kvsEl.innerHTML = kvsHtml(d);
      var evEl = root.querySelector('#wearEvt');
      if (evEl) {
        var evs = (d.events || []).slice().reverse();
        evEl.innerHTML = evs.length
          ? evs.map(function (ev) {
              return '<div class="wear-evt"><span class="wear-evt-t">'
                + esc(ev.kind || '?') + '</span>'
                + '<span class="wear-evt-x">' + esc(ev.text || '') + '</span></div>';
            }).join('')
          : '<div class="wear-empty">No events.</div>';
      }
    }
    var termBtn = nowPage.querySelector('#wearTermBtn');
    if (termBtn) termBtn.onclick = function () { rowJump(s); };
    var archBtn = nowPage.querySelector('#wearArchBtn');
    if (archBtn) {
      archBtn.onclick = function () {
        Agents.archive(s.agent, s.sessionId);
        location.href = 'home.html';
      };
    }
    dot();
  }

  function tick() {
    ensureDriver();
    if (!root) return;
    if (Driver) Driver.tick();
    dot();
    if (DETAIL) renderDetail();
    else renderHome();
  }

  var tries = 0;
  var iv = setInterval(function () {
    if (screenMode() === 'phone') {
      if (++tries > 60) clearInterval(iv);
      return;
    }
    clearInterval(iv);
    if (started) return;
    started = true;
    ensureDriver();
    try {
      var h = document.documentElement;
      if (h) {
        h.className = h.className.replace(/\bvm-boot\b/g, '')
          .replace(/\s+/g, ' ').trim();
      }
    } catch (e) {}
    if (DETAIL) buildShell('Agent', detailPages(), 2, true);
    else buildShell('Agents', [homePage()], 0, false);
    tick();
    setInterval(tick, 1000);
  }, 150);
})();
