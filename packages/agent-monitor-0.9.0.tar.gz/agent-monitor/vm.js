'use strict';

/* Agent Monitor - square/round renderer. State and data access live in
 * ../agent-base/base.js (Agents + Driver); this file renders list/detail/rename only. */

var BASE = (typeof WhipBase !== 'undefined') ? WhipBase : null;
var Driver = BASE ? BASE.Driver : null;
var Agents = BASE ? BASE.Agents : null;

var CARD_PATH = '/root/.whip/monitor/state/cards.json';
var LIVE_PATH = '/root/.whip/monitor/state/agent.ndjson';
var FEED_ID = 'agent-events-vm';

var detailSid = null;
var renameSid = null;
var lastFp = '';

function esc2(s) { return String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function cap2(s, n) {
  s = String(s == null ? '' : s);
  return s.length > n ? s.slice(0, n) + '…' : s;
}
function sidShort(sid) {
  sid = String(sid || '');
  return sid.length > 14 ? sid.slice(0, 14) + '…' : sid;
}
function fmtSince(ms) {
  if (!ms) return '';
  var s = Math.max(0, Math.floor((Date.now() - ms) / 1000));
  if (s < 60) return s + 's';
  if (s < 3600) return Math.floor(s / 60) + 'm';
  return Math.floor(s / 3600) + 'h';
}

function startDriver() {
  if (!Driver) return;
  Driver.start({
    cardsPath: CARD_PATH,
    livePath: LIVE_PATH,
    feedId: FEED_ID,
    backlog: 30,
    legacyArchKey: 'summ_archived_v1',
    monitorIds: ['agent-base', 'agent-monitor', 'agent-summarizer']
  });
}

function go(r) {
  if (!BASE || !r) return;
  BASE.act(BASE.actRow(r), BASE.shellHooks());
}

function rows() {
  return Driver ? Driver.rows() : [];
}

function arch(r) {
  Agents.archive(r.agent, r.sessionId);
  render();
  closeDetail();
}

function tagOf(st) { return BASE.stateUI(st || 'idle').tag; }
function colorOf(st) { return BASE.stateUI(st || 'idle').color; }

function rowFp(rs) {
  return JSON.stringify(rs.map(function (r) {
    var d = r.details || {};
    return [r.agent, r.sessionId, r.state, r.name, r.seq, r.lastActiveMs,
      r.isActive ? 1 : 0, d.tty, d.workspace, d.tool, d.action, d.result,
      d.message, d.status, d.liveState, d.rounds || 0, d.tools || 0,
      d.subs || 0, d.cardVersion || 0];
  }));
}

function render() {
  var list = document.getElementById('list');
  var dot = document.getElementById('dot');
  if (dot) dot.className = 'dot ' + (Driver.conn() ? 'on' : 'off');
  if (!Driver.conn()) {
    lastFp = '';
    list.innerHTML = '<div class="empty">No SSH.<br>Connect in Terminal first.</div>';
    if (detailSid) closeDetail();
    return;
  }
  var rs = rows();
  var fp = rowFp(rs);
  if (fp === lastFp) return;
  lastFp = fp;
  if (!rs.length) {
    list.innerHTML = '<div class="empty">No sessions yet.<br>'
      + 'Run claude / codex on a shell.</div>';
    return;
  }
  list.innerHTML = rs.map(function (r, i) {
    var d = r.details || {};
    var name = (r.name || r.agent || 'agent') + (r.isActive ? ' ●' : '');
    return '<div class="row' + (r.isActive ? ' live' : '') + '" data-i="' + i + '">'
      + '<span class="st" style="background:' + colorOf(r.state) + '"></span>'
      + '<span class="main"><span class="n">' + esc2(name) + '</span>'
      + '<div class="sub">' + esc2(sidShort(r.sessionId))
      + (r.lastActiveMs ? ' · ' + esc2(fmtSince(r.lastActiveMs)) : '')
      + (d.workspace ? ' · ' + esc2(cap2(d.workspace, 16)) : '')
      + (d.tty ? ' · ' + esc2(d.tty) : '') + '</div>'
      + ((d.tool || d.action)
          ? '<div class="subact">' + esc2(cap2((d.tool || '-')
            + (d.action ? ' · ' + d.action : ''), 46)) + '</div>' : '')
      + '</span>'
      + '<span class="state" style="background:' + colorOf(r.state) + '">'
      + esc2(tagOf(r.state)) + '</span>'
      + '<button class="go" type="button">Go</button>'
      + '<button class="arch" type="button">Arch</button>'
      + '</div>';
  }).join('');
  list.querySelectorAll('.row').forEach(function (rowEl) {
    var r = rs[Number(rowEl.getAttribute('data-i'))];
    var goEl = rowEl.querySelector('.go');
    var archEl = rowEl.querySelector('.arch');
    if (goEl) goEl.addEventListener('click', function (ev) {
      ev.stopPropagation(); go(r);
    });
    if (archEl) archEl.addEventListener('click', function (ev) {
      ev.stopPropagation(); arch(r);
    });
    rowEl.addEventListener('click', function (ev) {
      if (ev.target && ev.target.tagName === 'BUTTON') return;
      detailSid = r.sessionId;
      renderDetail();
    });
  });
}

function kvHtml(k, v) {
  return '<div class="dkv"><span>' + k + '</span><b>'
    + esc2(v == null || v === '' ? '—' : v) + '</b></div>';
}

function renderDetail() {
  var dl = document.getElementById('detail');
  var r = detailSid ? Agents.find('', detailSid) : null;
  if (!r || Agents.isArchived(r.agent, r.sessionId)) { closeDetail(); return; }
  var d = r.details || {};
  document.getElementById('dTitle').textContent =
    (r.name || r.agent || 'agent') + ' · ' + sidShort(r.sessionId);
  var html = '<span class="dchip" style="background:' + colorOf(r.state) + '">'
    + esc2(tagOf(r.state)) + '</span>'
    + (r.isActive ? '<span class="dchip" style="background:#00cc66">live</span>' : '')
    + (r.lastActiveMs ? '<span class="dchip" style="background:#333">'
      + esc2(fmtSince(r.lastActiveMs)) + '</span>' : '')
    + (d.message ? '<div class="dmsg">' + esc2(d.message) + '</div>' : '')
    + kvHtml('status', esc2((d.status || '') + (d.liveState
      ? (d.status ? ' · ' : '') + 'live ' + d.liveState : '')))
    + kvHtml('tool', d.tool)
    + kvHtml('action', cap2(d.action, 120))
    + kvHtml('workspace', d.workspace)
    + kvHtml('tty', d.tty)
    + kvHtml('result', cap2(d.result, 220))
    + kvHtml('r/t/s', (d.rounds || 0) + ' / ' + (d.tools || 0) + ' / '
      + (d.subs || 0))
    + kvHtml('card', d.cardVersion ? 'v' + d.cardVersion : '')
    + kvHtml('started', d.startedAt ? fmtSince(d.startedAt) : '');
  var steps = d.steps || [];
  if (steps.length) {
    html += '<div class="dsum"><div class="dsumhead">steps '
      + steps.length + '</div>'
      + steps.slice(-4).reverse().map(function (st) {
          return '<div class="dsumitem">' + (st.ok ? '✓' : '✗') + ' '
            + esc2(cap2(st.tool + (st.action ? ' ' + st.action : ''), 58))
            + '</div>';
        }).join('') + '</div>';
  }
  var evs = (d.events || []).slice().reverse().slice(0, 12);
  if (evs.length) {
    html += '<div class="dmsg" style="border-left-color:#2a2a40">'
      + evs.map(function (ev) {
          return '<div class="devt">' + esc2(ev.text || ev.kind || '') + '</div>';
        }).join('') + '</div>';
  }
  document.getElementById('dbody').innerHTML = html;
  document.getElementById('dGo').onclick = function () { go(r); };
  document.getElementById('dArch').onclick = function () { arch(r); };
  dl.classList.add('show');
}

function closeDetail() {
  detailSid = null;
  var dl = document.getElementById('detail');
  if (dl) dl.classList.remove('show');
}

function openRename() {
  var r = detailSid ? Agents.find('', detailSid) : null;
  if (!r) return;
  renameSid = r.sessionId;
  document.getElementById('rName').value = r.name || r.agent || '';
  document.getElementById('rename').classList.add('show');
}

function saveRename() {
  var r = renameSid ? Agents.find('', renameSid) : null;
  if (r) {
    Agents.rename(r.agent, r.sessionId,
      document.getElementById('rName').value);
  }
  renameSid = null;
  document.getElementById('rename').classList.remove('show');
  render();
  if (detailSid) renderDetail();
}

function tick() {
  if (!BASE) return;
  if (!Driver) { Driver = BASE.Driver; Agents = BASE.Agents; }
  Driver.tick();
  render();
}

if (BASE) {
  startDriver();
  document.getElementById('back').addEventListener('click', function () {
    history.back();
  });
  document.getElementById('dBack').addEventListener('click', closeDetail);
  document.getElementById('dRen').addEventListener('click', openRename);
  document.getElementById('rBack').addEventListener('click', function () {
    renameSid = null;
    document.getElementById('rename').classList.remove('show');
  });
  document.getElementById('rCancel').addEventListener('click', function () {
    renameSid = null;
    document.getElementById('rename').classList.remove('show');
  });
  document.getElementById('rSave').addEventListener('click', saveRename);
  render();
  tick();
  setInterval(tick, 1000);
  window.addEventListener('pagehide', function () { Driver.stop(); });
}
