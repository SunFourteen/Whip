'use strict';

/* Agent Monitor - phone list renderer. State and data access live in
 * ../agent-base/base.js (Agents + Driver); this file drives the Driver, renders the list
 * and turns user intent into base actions. */

var BASE = (typeof WhipBase !== 'undefined') ? WhipBase : null;
var HOST_PATHS = (BASE && BASE.paths) || {};
var Driver = BASE ? BASE.Driver : null;
var Agents = BASE ? BASE.Agents : null;

function $(id) { return document.getElementById(id); }
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function cap(s, n) {
  s = String(s == null ? '' : s);
  return s.length > n ? s.slice(0, n) + '…' : s;
}
function fmtSince(ms) {
  if (!ms) return '';
  var s = Math.max(0, Math.floor((Date.now() - ms) / 1000));
  if (s < 60) return s + 's ago';
  var m = Math.floor(s / 60);
  if (m < 60) return m + 'm ' + (s % 60) + 's ago';
  return Math.floor(m / 60) + 'h ' + (m % 60) + 'm ago';
}
function shortSid(sid) {
  sid = String(sid || '');
  return sid.length > 10 ? sid.slice(0, 10) + '…' : (sid || '-');
}

var CARD_PATH = HOST_PATHS.cardsPath || '';
var LIVE_PATH = HOST_PATHS.livePath || '';
var FEED_ID = 'agent-events-home';

var lastFp = '';
var statusText = '';

function startDriver() {
  if (!Driver) return;
  Driver.start({
    cardsPath: CARD_PATH,
    livePath: LIVE_PATH,
    feedId: FEED_ID,
    backlog: 30,
    legacyArchKey: 'summ_archived_v1',
    monitorIds: ['agent-base', 'agent-monitor', 'agent-summarizer'],
    onStatus: function (t) {
      statusText = t || '';
      updateFoot();
    }
  });
}

function updateFoot() {
  var f = $('foot');
  if (!f) return;
  if (!Agents) { f.textContent = ''; return; }
  var n = Agents.listArchived().length;
  var h = [];
  if (statusText) h.push('<span>' + esc(statusText) + '</span>');
  if (n > 0) {
    h.push(n + ' archived · '
      + '<a id="archClear" href="#">Clear</a>');
  }
  f.innerHTML = h.join(' · ');
  var clearEl = $('archClear');
  if (clearEl) {
    clearEl.onclick = function (e) {
      e.preventDefault();
      Driver.clearArchived();
      render();
    };
  }
}

function go(r) {
  if (!BASE || !r) return;
  BASE.act(BASE.actRow(r), BASE.shellHooks());
}

function rowFp(rs) {
  return JSON.stringify(rs.map(function (r) {
    var d = r.details || {};
    return [r.agent, r.sessionId, r.state, r.name, r.seq, r.lastActiveMs,
      r.isActive ? 1 : 0, d.workspace, d.tty, d.tool, d.action, d.result,
      d.message, d.status, d.liveState, d.rounds || 0, d.tools || 0,
      d.subs || 0, d.cardVersion || 0];
  }));
}

function render() {
  var list = $('list');
  if (!list) return;
  if (!Driver || !Driver.conn()) {
    lastFp = '';
    list.innerHTML = '<div class="empty">SSH not connected.</div>';
    updateFoot();
    return;
  }
  var rs = Driver.rows();
  var fp = rowFp(rs);
  if (fp === lastFp) return;
  lastFp = fp;
  try {
    console.log('[agent-monitor] rows=' + rs.length + ' '
      + rs.map(function (r) {
          return r.agent + ':' + String(r.sessionId).slice(0, 8)
            + ':' + (r.state || '?') + (r.isActive ? '+' : '');
        }).join(','));
  } catch (e) {}
  if (!rs.length) {
    list.innerHTML = '<div class="empty">No agent sessions.</div>';
    updateFoot();
    return;
  }
  list.innerHTML = '';
  rs.forEach(function (r) {
    var d = r.details || {};
    var st = r.state || 'idle';
    var ui = BASE.stateUI(st);
    var name = r.name || r.agent || 'agent';
    var live = !!r.isActive;
    var tty = d.tty || '';
    var canResume = !!(d.workspace || BASE.resumeCmd(r.agent, r.sessionId));
    var sh = null;
    try {
      var arr = JSON.parse(SshBridge.listShells() || '[]');
      if (Array.isArray(arr)) {
        for (var i = 0; i < arr.length; i++) {
          if (arr[i] && arr[i].tty && arr[i].tty === tty) { sh = arr[i]; break; }
        }
      }
    } catch (e) {}
    var act = '';
    if (sh && live) {
      act += '<button class="act" data-act="focus">›_ '
        + esc(sh.name || sh.id) + '</button>';
    }
    // A live session is never resumed: it is already running, and a second agent on the
    // same conversation is exactly the duplicate this rule exists to prevent.
    if (!live && canResume) {
      act += '<button class="act" data-act="resume">↗ Resume</button>';
    }
    act += '<button class="act" data-act="rename">Rename</button>';
    act += '<button class="act" data-act="archive">Archive</button>';
    var card = document.createElement('div');
    card.className = 'card' + (live ? ' live' : '');
    card.innerHTML =
      '<div class="id">'
      + '<div class="agent">' + esc(name)
      + (live ? '<span class="live-tag">live</span>' : '')
      + (sh && live ? '<span class="live-tag shell">shell</span>' : '')
      + '</div>'
      + '<div class="sid">session ' + esc(shortSid(r.sessionId)) + '</div>'
      + '<div class="meta">' + esc(fmtSince(r.lastActiveMs)) + ' · seq '
        + (r.seq || 0) + '</div>'
      + '</div>'
      + '<div class="right">'
      + '<span class="badge" style="background:' + ui.color + '">'
        + esc(ui.label) + '</span>'
      + (act ? '<div class="acts">' + act + '</div>' : '')
      + '</div>';
    card.onclick = function () {
      location.href = 'index.html?agent=' + encodeURIComponent(r.agent)
        + '&session=' + encodeURIComponent(r.sessionId);
    };
    card.querySelectorAll('.act').forEach(function (b) {
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        var kind = b.getAttribute('data-act');
        if (kind === 'archive') {
          Agents.archive(r.agent, r.sessionId);
          render();
        } else if (kind === 'rename') {
          location.href = 'index.html?agent=' + encodeURIComponent(r.agent)
            + '&session=' + encodeURIComponent(r.sessionId)
            + (r.key ? '&key=' + encodeURIComponent(r.key) : '')
            + '&rename=1';
        } else {
          go(r);
        }
      });
    });
    list.appendChild(card);
  });
  updateFoot();
}

function tick() {
  if (!BASE) return;
  if (!Driver) { Driver = BASE.Driver; Agents = BASE.Agents; }
  var cd = $('connDot');
  if (cd) cd.className = 'dot ' + (Driver.conn() ? 'on' : 'off');
  Driver.tick();
  render();
}

if (BASE) {
  startDriver();
  tick();
  setInterval(tick, 1000);
  window.addEventListener('pagehide', function () { Driver.stop(); });
}
