'use strict';

/* Agent Monitor - phone detail renderer.
 * State machine and data access live in ../agent-base/base.js (Agents + Driver):
 *  - ?agent=&session= pins a session, otherwise the most recent one is followed
 *  - sessions outside the event window pull their full card from cards/<key>.json
 *  - the raw feed stays a debug-only UI owned by this page */

var BASE = (typeof WhipBase !== 'undefined') ? WhipBase : null;
var HOST_PATHS = (BASE && BASE.paths) || {};
var Driver = BASE ? BASE.Driver : null;
var Agents = BASE ? BASE.Agents : null;

function $(id) { return document.getElementById(id); }
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
function cap(s, n) {
  s = String(s == null ? '' : s);
  return s.length > n ? s.slice(0, n) + '…' : s;
}
function fmtSince(ms) {
  if (!ms) return '';
  var s = Math.max(0, Math.floor((Date.now() - ms) / 1000));
  if (s < 60) return s + 's ago';
  var m = Math.floor(s / 60);
  if (m < 60) return m + 'm ' + (s % 60) + 's ago';
  var h = Math.floor(m / 60);
  return h + 'h ' + (m % 60) + 'm ago';
}
function shq(s) { return "'" + String(s).replace(/'/g, "'\\''") + "'"; }

var CARD_PATH = HOST_PATHS.cardsPath || '';
var LIVE_PATH = HOST_PATHS.livePath || '';
var FEED_ID = 'agent-events-detail';

var q = (function () {
  try {
    var u = new URLSearchParams(location.search);
    return {
      agent: u.get('agent') || '',
      session: u.get('session') || '',
      rename: u.get('rename') === '1'
    };
  } catch (e) { return { agent: '', session: '', rename: false }; }
})();

var lastFp = '';
var lastSid = '';

function matchedShell(tty) {
  if (!tty) return null;
  try {
    var arr = JSON.parse(SshBridge.listShells() || '[]');
    if (Array.isArray(arr)) {
      for (var i = 0; i < arr.length; i++) {
        if (arr[i] && arr[i].tty === tty) return arr[i];
      }
    }
  } catch (e) {}
  return null;
}

function current() {
  // Driver.rows() triggers resolve and refreshes isActive / lastActiveMs
  var rows = Driver.rows();
  if (!q.session) return rows[0] || null;
  // Merge the full card for the target session (even outside the event window);
  // archived sessions also load key/raw so undo clears the legacy archive too.
  if (Agents.isArchived(q.agent || '', q.session)) {
    return Driver.ensureFocus(true)
      || Agents.ensure(q.agent || '', q.session) || null;
  }
  return Driver.ensureFocus(true) || null;
}

/* ---------------- Monitoring surface ----------------
 * Agent Monitor owns all monitoring detail (the union of both sides);
 * LLM summaries belong to Agent Summarizer, so this page never reads d.summary. */

function fmtClock(ms) {
  if (!ms) return '';
  var d = new Date(Number(ms));
  var p = function (n) { return (n < 10 ? '0' : '') + n; };
  return p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' '
    + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
}

function fld(k, v) {
  return '<div class="fld"><span>' + esc(k) + '</span><b>'
    + (v === '' || v == null ? '<i>—</i>' : esc(v)) + '</b></div>';
}

function renderFields(s) {
  var el = $('fieldList');
  if (!el) return;
  if (!s || !s.sessionId) { el.innerHTML = '<div class="dim">(no session)</div>'; return; }
  var d = s.details || {};
  var sh = matchedShell(d.tty);
  var ts = function (ms) { return ms ? (fmtClock(ms) + ' · ' + fmtSince(ms)) : ''; };
  el.innerHTML = [
    fld('agent', s.agent),
    fld('session', s.sessionId),
    fld('key', s.key),
    fld('name', (s.name && s.name !== s.agent) ? s.name : ''),
    fld('state', s.state + (s.isActive ? ' · active' : '')),
    fld('status', d.status),
    fld('live.state', d.liveState),
    fld('shell', sh ? (sh.name || sh.id) : (d.tty ? '(no matching shell)' : '')),
    fld('tty', d.tty),
    fld('workspace', d.workspace),
    fld('rounds', String(d.rounds || 0)),
    fld('tools', String(d.tools || 0)),
    fld('subs', String(d.subs || 0)),
    fld('card ver', d.cardVersion ? 'v' + d.cardVersion : ''),
    fld('seq', String(s.seq || 0)),
    fld('started', ts(d.startedAt)),
    fld('updated', ts(s.lastActiveMs)),
    fld('lastActiveAt', d.lastActiveAt ? ts(d.lastActiveAt) : '')
  ].join('');
}

function renderSteps(d) {
  var el = $('stepList');
  var meta = $('stepsMeta');
  if (!el) return;
  var steps = (d && d.steps) || [];
  if (meta) meta.textContent = steps.length ? (steps.length + ' latest') : '';
  if (!steps.length) {
    el.innerHTML = '<div class="dim">(no steps in card)</div>';
    return;
  }
  el.innerHTML = steps.slice().reverse().map(function (st) {
    var dur = st.durationMs != null ? (st.durationMs + 'ms') : '';
    var cls = st.ok ? 'ok' : 'fail';
    return '<details class="step"><summary><span class="' + cls + '">'
      + (st.ok ? '✓' : '✗') + '</span><span>' + esc(st.tool || '?') + '</span>'
      + '<span class="dim">' + esc(cap(st.action, 70)) + '</span>'
      + '<span class="dim">' + esc(dur) + '</span></summary>'
      + (st.result ? '<div class="step-body">'
        + esc(cap(st.result, 1200)) + '</div>' : '')
      + '</details>';
  }).join('');
}

function renderJson(s) {
  var el = $('jsonBody');
  if (!el) return;
  var raw = s && s.raw;
  if (!raw) { el.innerHTML = '<div class="dim">(no card payload)</div>'; return; }
  var txt;
  try { txt = JSON.stringify(raw, null, 2); } catch (e) { txt = String(raw); }
  el.innerHTML = '<details class="step"><summary><span>card</span>'
    + '<span class="dim">' + (s.fullRaw ? 'full card' : 'index entry') + '</span>'
    + '</summary><div class="step-body json">' + esc(txt) + '</div></details>';
}

function renderState(s) {
  var st = (s && s.state) || 'idle';
  var ui = BASE.stateUI(st);
  if (s && Agents.isArchived(s.agent, s.sessionId)) {
    renderFields(s);
    renderSteps({});
    renderJson(s);
    $('stateBadge').textContent = 'archived';
    $('stateBadge').className = 'badge archived';
    $('stateBadge').style.background = '#555';
    $('since').textContent = '';
    $('fTool').textContent = '-';
    $('fAction').textContent = '-';
    $('fResult').textContent = '-';
    $('fMessage').textContent = 'Session archived.';
    $('rowWorkspace').style.display = 'none';
    $('detailActs').innerHTML =
      '<button class="act" id="actUnarch">Unarchive</button>';
    var u = $('actUnarch');
    if (u) u.onclick = function () {
      Driver.unarchive(s.agent, s.sessionId, s.key);
      if (Driver) Driver.loadCard(s.agent, s.sessionId, s.key);
      renderState(Agents.find(s.agent, s.sessionId) || current());
    };
    $('eventList').innerHTML = '<div class="dim">(archived)</div>';
    return;
  }
  if (!s || !s.sessionId) {
    renderFields(null);
    renderSteps({});
    renderJson(null);
    $('stateBadge').textContent = 'unknown';
    $('stateBadge').className = 'badge unknown';
    $('stateBadge').style.background = '#888888';
    $('since').textContent = '';
    $('fTool').textContent = '-';
    $('fAction').textContent = '-';
    $('fResult').textContent = '-';
    $('fMessage').textContent = 'Waiting for agent state…';
    $('rowWorkspace').style.display = 'none';
    $('detailActs').innerHTML = '';
    $('eventList').innerHTML = '<div class="dim">(no events yet)</div>';
    return;
  }
  var d = s.details || {};
  renderFields(s);
  renderSteps(d);
  renderJson(s);
  $('stateBadge').textContent = ui.label;
  $('stateBadge').className = 'badge ' + st;
  $('stateBadge').style.background = ui.color;
  var nm = (s.name && s.name !== s.agent) ? esc(s.name) + ' · ' : '';
  $('since').textContent = nm + fmtSince(s.lastActiveMs);
  $('fTool').textContent = d.tool || '-';
  $('fAction').textContent = d.action || '-';
  $('fResult').textContent = d.result || '-';
  $('fMessage').textContent = d.message || '-';

  var ws = d.workspace || '';
  $('rowWorkspace').style.display = ws ? '' : 'none';
  $('fWorkspace').textContent = ws || '-';

  var sh = matchedShell(d.tty);
  var live = !!s.isActive;
  var canResume = !!(ws || BASE.resumeCmd(s.agent, s.sessionId));
  var html = '';
  if (sh && live) {
    html += '<button class="act" id="actFocus">›_ Focus '
      + esc(sh.name || sh.id) + '</button>';
  }
  // A live session is never resumed: it is already running, and a second agent on the
  // same conversation is exactly the duplicate this rule exists to prevent.
  if (!live && canResume) {
    html += '<button class="act" id="actResume">↗ Resume</button>';
  }
  html += '<button class="act" id="actArchive">Archive</button>';
  html += '<button class="act" id="actRename">Rename</button>'
    + '<span id="rnWrap" style="display:none">'
    + '<input id="rnInput" type="text" style="width:180px;padding:4px 6px;'
    + 'background:#0F0F1A;color:#cfd;border:1px solid #2a5;border-radius:4px;'
    + 'font:11px monospace">'
    + '<button class="act" id="rnSave">Save</button>'
    + '<button class="act" id="rnCancel">Cancel</button></span>';
  $('detailActs').innerHTML = html;
  var focusBtn = $('actFocus');
  if (focusBtn) {
    focusBtn.onclick = function () {
      BASE.shellHooks().focusShell(sh.id);
    };
  }
  var resumeBtn = $('actResume');
  if (resumeBtn) {
    resumeBtn.onclick = function () {
      BASE.shellHooks().openShellWith(ws, BASE.resumeCmd(s.agent, s.sessionId));
    };
  }
  var archBtn = $('actArchive');
  if (archBtn) {
    archBtn.onclick = function () {
      Agents.archive(s.agent, s.sessionId);
      if (history.length > 1) history.back(); else location.href = 'home.html';
    };
  }
  var renBtn = $('actRename');
  var rnWrap = $('rnWrap');
  if (renBtn && rnWrap) {
    renBtn.onclick = function () {
      $('rnInput').value = s.name || s.agent || '';
      rnWrap.style.display = 'inline';
      $('rnInput').focus();
    };
    $('rnSave').onclick = function () {
      Agents.rename(s.agent, s.sessionId, $('rnInput').value);
      rnWrap.style.display = 'none';
      lastFp = '';
      renderState(current());
    };
    $('rnCancel').onclick = function () {
      rnWrap.style.display = 'none';
    };
    // Rename entry from the list page: ?rename=1 opens the input directly
    if (q.rename) {
      q.rename = false;
      renBtn.onclick();
    }
  }
  var evs = d.events || [];
  $('eventList').innerHTML = evs.slice().reverse().map(function (e) {
    return '<div class="ev"><span class="ev-t">' + esc(e.kind || '?') + '</span>'
      + '<span class="ev-x">' + esc(e.text || '') + '</span></div>';
  }).join('') || '<div class="dim">(no events yet)</div>';
}

function fpOf(s) {
  if (!s) return '';
  return JSON.stringify([s.agent, s.sessionId, s.state, s.seq,
    s.lastActiveMs, s.isActive ? 1 : 0, s.details]);
}

function tick() {
  if (!BASE || !Driver) return;
  var cd = $('connDot');
  if (cd) cd.className = 'dot ' + (Driver.conn() ? 'on' : 'off');
  Driver.tick();
  var s = current();
  var sid = (s && s.sessionId) || (q.session || '');
  var fp = fpOf(s);
  if (fp !== lastFp || sid !== lastSid) {
    lastFp = fp;
    lastSid = sid;
    renderState(s);
  }
}

/* ---------------- raw feed (debug UI) ---------------- */
var feedVersion = -1;
var feedOnRaw = false;
var feedTimer = null;

function toggleFeed() {
  feedOnRaw = !feedOnRaw;
  var btn = $('btnFeed');
  if (!feedOnRaw) {
    btn.textContent = 'Watch';
    stopFeedRaw();
    return;
  }
  var path = $('feedPath').value.trim();
  if (!path) { feedOnRaw = false; return; }
  try { localStorage.setItem('agent_feed_path', path); } catch (e) {}
  var r;
  try {
    r = JSON.parse(SshBridge.createFeed('agent-raw',
      JSON.stringify({ type: 'file-lines', path: path, framing: 'json-line' })));
  } catch (e) {
    r = { ok: false, error: 'bridge' };
  }
  if (!r.ok) {
    $('feedList').innerHTML = '<div class="dim">feed error: '
      + esc(r.error) + '</div>';
    feedOnRaw = false;
    btn.textContent = 'Watch';
    return;
  }
  btn.textContent = 'Stop';
  feedVersion = -1;
  $('feedList').innerHTML = '<div class="dim">watching…</div>';
  if (feedTimer) clearInterval(feedTimer);
  feedTimer = setInterval(feedPoll, 1500);
  feedPoll();
}

function stopFeedRaw() {
  if (feedTimer) { clearInterval(feedTimer); feedTimer = null; }
  try { SshBridge.removeFeed('agent-raw'); } catch (e) {}
}

function feedPoll() {
  var v = SshBridge.feedVersion('agent-raw');
  if (v < 0) return;
  var from = feedVersion < 0 ? Math.max(0, v - 30) : feedVersion;
  var r;
  try {
    r = JSON.parse(SshBridge.feedRead('agent-raw', from));
  } catch (e) {
    return;
  }
  feedVersion = r.nextVersion;
  var recs = r.records || [];
  if (!recs.length) return;
  $('feedList').innerHTML = recs.map(function (rec) {
    var pretty = rec;
    try { pretty = JSON.stringify(JSON.parse(rec)); } catch (e) {}
    return '<div class="ev raw"><span class="ev-x">' + esc(pretty) + '</span></div>';
  }).join('');
}

function startDriver() {
  if (!Driver) return;
  Driver.start({
    cardsPath: CARD_PATH,
    livePath: LIVE_PATH,
    feedId: FEED_ID,
    backlog: 30,
    legacyArchKey: 'summ_archived_v1',
    focus: q.session
      ? { agent: q.agent, sessionId: q.session, requireRaw: true } : null,
    monitorIds: ['agent-base', 'agent-monitor', 'agent-summarizer']
  });
}

function init() {
  try {
    var p = localStorage.getItem('agent_feed_path');
    if (p) $('feedPath').value = p;
  } catch (e) {}
  startDriver();
  tick();
  setInterval(tick, 1000);
  window.addEventListener('pagehide', function () {
    Driver.stop();
    stopFeedRaw();
  });
}

init();
