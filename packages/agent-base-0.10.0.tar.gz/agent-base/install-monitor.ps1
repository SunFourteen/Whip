<#
  Agent Monitor self-check / self-install for Windows hosts.

  Run from the plugin directory: the app runs it as `& .\install-monitor.ps1` with the
  PowerShell working directory already set to the plugin's folder.

    - check whether %USERPROFILE%\.whip\monitor is installed at the bundled VERSION;
    - if missing or older, install from this plugin's monitor-bundle\ and merge the
      minimal .claude/.codex hook entries (monitor-bundle\merge-hooks.js, shared with the
      POSIX installer);
    - make sure the summarizer daemon is running (node, hidden window);
    - print MONITOR_STATUS / MONITOR_VERSION / MONITOR_DEST for the plugin page.

  Exit code 0 only when the runtime is actually in place, so the installer can report a
  failed setup instead of caching a broken state.
#>
$ErrorActionPreference = 'Stop'

function Resolve-Node {
  $c = Get-Command node.exe -ErrorAction SilentlyContinue
  if ($c) { return $c.Source }
  # A non-interactive ssh session does not always inherit the user's PATH; look where
  # Node is normally installed before giving up.
  foreach ($p in @(
      (Join-Path $env:ProgramFiles 'nodejs\node.exe'),
      (Join-Path ${env:ProgramFiles(x86)} 'nodejs\node.exe'),
      (Join-Path $env:LOCALAPPDATA 'Programs\nodejs\node.exe'))) {
    if ($p -and (Test-Path -LiteralPath $p)) { return $p }
  }
  return $null
}

$src = Join-Path $PSScriptRoot 'monitor-bundle'
$dest = if ($env:WHIP_MONITOR_DIR) { $env:WHIP_MONITOR_DIR } else { Join-Path $env:USERPROFILE '.whip\monitor' }
$stateDir = Join-Path $dest 'state'
$claudeSettings = Join-Path $env:USERPROFILE '.claude\settings.json'
$codexHooks = Join-Path $env:USERPROFILE '.codex\hooks.json'

if (-not (Test-Path -LiteralPath $src)) {
  Write-Output 'MONITOR_STATUS=missing-src'
  Write-Output "MONITOR_DEST=$dest"
  exit 0
}

New-Item -ItemType Directory -Force -Path $dest | Out-Null

# Re-entrancy guard: two plugins may install at the same time
$lock = Join-Path $dest '.install.lock'
$locked = $false
for ($i = 0; $i -lt 60; $i++) {
  try {
    New-Item -ItemType Directory -Path $lock -ErrorAction Stop | Out-Null
    $locked = $true
    break
  } catch {
    Start-Sleep -Seconds 1
  }
}

try {
  $srcVersion = (Get-Content -LiteralPath (Join-Path $src 'VERSION') -Raw -ErrorAction SilentlyContinue)
  $srcVersion = if ($srcVersion) { $srcVersion.Trim() } else { '' }
  $dstVersion = ''
  $dstVersionFile = Join-Path $dest 'VERSION'
  if (Test-Path -LiteralPath $dstVersionFile) {
    $dstVersion = (Get-Content -LiteralPath $dstVersionFile -Raw).Trim()
  }

  $status = 'ok'
  if (-not $dstVersion) { $status = 'installed' }
  elseif ($dstVersion -ne $srcVersion) { $status = 'upgraded' }

  if ($status -ne 'ok') {
    $hooksDest = Join-Path $dest 'hooks'
    if (Test-Path -LiteralPath $hooksDest) { Remove-Item -LiteralPath $hooksDest -Recurse -Force }
    Copy-Item -LiteralPath (Join-Path $src 'hooks') -Destination $hooksDest -Recurse -Force
    Copy-Item -LiteralPath (Join-Path $src 'summarizer.js') -Destination $dest -Force
    Copy-Item -LiteralPath (Join-Path $src 'merge-hooks.js') -Destination $dest -Force
    Copy-Item -LiteralPath (Join-Path $src 'VERSION') -Destination $dest -Force
    New-Item -ItemType Directory -Force -Path $stateDir | Out-Null

    # Restart the daemon after a version change so the new code takes effect
    Get-CimInstance Win32_Process |
      Where-Object { $_.CommandLine -and $_.CommandLine -like "*$dest*summarizer.js*" } |
      ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    # Wait for it to actually disappear: the keep-alive check below would otherwise see a
    # dying process and skip starting the new one, leaving no daemon at all.
    for ($i = 0; $i -lt 20; $i++) {
      $still = Get-CimInstance Win32_Process |
        Where-Object { $_.CommandLine -and $_.CommandLine -like "*$dest*summarizer.js*" }
      if (-not $still) { break }
      Start-Sleep -Milliseconds 500
    }
  }

  # Backfill hook entries on every run: the agent config may have been reset or moved, or
  # the monitor VERSION may be unchanged while our settings entry is missing.
  $node = Resolve-Node
  $merge = Join-Path $src 'merge-hooks.js'
  if ($node -and (Test-Path -LiteralPath $merge)) {
    # No `2>&1 | ...` here: with $ErrorActionPreference='Stop' PowerShell 5.1 turns a native
    # command's redirected stderr into a terminating error and would abort the install.
    & $node $merge $dest (Join-Path $src 'config') $claudeSettings $codexHooks
    if ($LASTEXITCODE -ne 0) { Write-Output 'MONITOR_HOOKS=error' }
  } else {
    Write-Output 'MONITOR_NODE=no'
  }

  # Diagnostics: the plugin page parses STATUS/VERSION only. The check is JSON-aware —
  # a raw text match cannot work, because JSON escapes every backslash ("\\monitor\\").
  $needle = (Join-Path $dest 'hooks') -replace '\\', '/'
  function Test-HookRegistered($path) {
    if (-not (Test-Path -LiteralPath $path)) { return $false }
    try {
      $cfg = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
    } catch {
      return $false
    }
    if (-not $cfg.hooks) { return $false }
    foreach ($event in $cfg.hooks.PSObject.Properties) {
      foreach ($group in @($event.Value)) {
        foreach ($hook in @($group.hooks)) {
          if ($hook -and $hook.command -and
              (([string]$hook.command) -replace '\\', '/').Contains($needle)) {
            return $true
          }
        }
      }
    }
    return $false
  }
  $claudeHookOk = Test-HookRegistered $claudeSettings
  Write-Output ("MONITOR_CLAUDE_HOOK=" + $(if ($claudeHookOk) { 'yes' } else { 'no' }))
  $codexHookOk = Test-HookRegistered $codexHooks
  Write-Output ("MONITOR_CODEX_HOOK=" + $(if ($codexHookOk) { 'yes' } else { 'no' }))

  # Keep the daemon alive (restart it when the version matches but the process is gone)
  $running = Get-CimInstance Win32_Process |
    Where-Object { $_.CommandLine -and $_.CommandLine -like "*$dest*summarizer.js*" }
  if (-not $running -and $node) {
    # Start it through WMI, not as a child of this script: OpenSSH runs each command in a
    # job object, and a child started from here is killed the moment the command returns —
    # which is why the daemon used to vanish right after a successful install.
    $log = Join-Path $dest 'summarizer.log'
    $errLog = Join-Path $dest 'summarizer.err.log'
    $line = 'cmd.exe /c ""{0}" "{1}" >> "{2}" 2>> "{3}""' -f `
      $node, (Join-Path $dest 'summarizer.js'), $log, $errLog
    $created = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{
      CommandLine = $line
      CurrentDirectory = $dest
    }
    if (-not $created -or -not $created.ProcessId) {
      Write-Output 'MONITOR_DAEMON=error'
    }
    Start-Sleep -Seconds 2
  } elseif (-not $node) {
    Write-Output 'MONITOR_NODE=no'
  }

  Write-Output "MONITOR_STATUS=$status"
  Write-Output "MONITOR_VERSION=$srcVersion"
  Write-Output "MONITOR_DEST=$dest"

  $summarizer = Join-Path $dest 'summarizer.js'
  if (-not (Test-Path -LiteralPath $summarizer) -or -not (Test-Path -LiteralPath (Join-Path $dest 'VERSION'))) {
    Write-Output 'MONITOR_STATUS=error'
    [Console]::Error.WriteLine("setup failed: monitor files missing in $dest")
    exit 1
  }
  if (-not $claudeHookOk) {
    Write-Output 'MONITOR_STATUS=error'
    [Console]::Error.WriteLine("setup failed: claude hooks not registered in $claudeSettings")
    exit 1
  }
  exit 0
} finally {
  if ($locked) { Remove-Item -LiteralPath $lock -Recurse -Force -ErrorAction SilentlyContinue }
}
