/* Whip host platform: POSIX (Linux, macOS, containers, WSL).
 *
 * One file per platform, both shipped in the package; base.js picks the one that matches
 * the host it is talking to (SshBridge.env()). Everything host-shaped lives here: where the
 * monitor keeps its state, how a file is read, how the agent processes are listed and how
 * a process is killed. The rest of the plugin is platform-neutral.
 */
window.WhipPlatformPosix = (function () {
  'use strict';

  var env = {};
  try { env = JSON.parse(SshBridge.env() || '{}') || {}; } catch (e) {}
  var HOME = env.home || '/root';

  function join(a, b) {
    if (!a) return b || '';
    if (!b) return a;
    return a.replace(/\/+$/, '') + '/' + String(b).replace(/^\/+/, '');
  }
  function dirOf(path) {
    var i = String(path || '').lastIndexOf('/');
    return i > 0 ? String(path).slice(0, i) : '';
  }
  function q(s) { return "'" + String(s == null ? '' : s).replace(/'/g, "'\\''") + "'"; }

  var monitorDir = join(HOME, '.whip/monitor');
  var stateDir = join(monitorDir, 'state');

  return {
    id: 'posix',
    label: env.label || 'Linux/macOS',
    home: HOME,
    join: join,
    dirOf: dirOf,
    quotePath: q,

    monitorDir: monitorDir,
    stateDir: stateDir,
    cardsPath: join(stateDir, 'cards.json'),
    cardsDir: join(stateDir, 'cards'),
    livePath: join(stateDir, 'agent.ndjson'),
    streamPath: join(stateDir, 'cards.ndjson'),

    /**
     * A session is a workspace session only when it runs on a real terminal. "?" (no tty)
     * is what a background or CI run looks like, and it must not become a live card.
     */
    isWorkspaceTty: function (tty) {
      return /^(pts\/|tty)/.test(String(tty == null ? '' : tty).trim());
    },

    /** Command that prints a file's bytes (empty output when it does not exist). */
    readCmd: function (path) { return 'cat ' + q(path) + ' 2>/dev/null'; },

    /** Command that prints the last n lines of a file. */
    tailCmd: function (path, n) {
      return 'tail -n ' + Number(n || 50) + ' -- ' + q(path) + ' 2>/dev/null';
    },

    /**
     * Command that lists running agent processes as "<tty> <command line>" per line — the
     * shape the shared parser expects.
     */
    agentScanCmd: function () { return 'ps -eo tty=,args='; },

    /** Kill a process by pid; a failed kill must fail the command. */
    killCmd: function (pid) { return 'kill -9 ' + Number(pid) + ' 2>&1'; },

    /** Shell line that resumes an agent session. */
    resumeCmd: function (agent, sid) {
      var id = q(String(sid == null ? '' : sid));
      if (agent === 'claude') return 'claude --resume ' + id;
      if (agent === 'codex') return 'codex resume ' + id;
      return '';
    }
  };
})();
