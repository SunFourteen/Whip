#!/usr/bin/env node
'use strict';
/**
 * Register the monitor's hook entries in the agent config files.
 *
 * Usage: node merge-hooks.js <monitorDir> <configDir> <claudeSettingsPath> <codexHooksPath>
 *
 * Shared by install-monitor.sh and install-monitor.ps1: the JSON merge, the stale-entry
 * pruning and the path handling are identical on both platforms, so they live in one file.
 * Hook commands are written as `node "<abs path>"`, which both sh and cmd accept, and the
 * `@MONITOR@` placeholder in config/*.json is replaced with the real monitor directory so
 * no home directory is ever hardcoded.
 */
const fs = require('fs');
const path = require('path');

const [monitorDir, configDir, claudePath, codexPath] = process.argv.slice(2);
if (!monitorDir || !configDir || !claudePath || !codexPath) {
  process.stderr.write('merge-hooks: missing arguments\n');
  process.exit(2);
}

function load(p) {
  try {
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch (e) {
    return {};
  }
}

function subst(value) {
  if (Array.isArray(value)) return value.map(subst);
  if (value && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value)) out[k] = subst(value[k]);
    return out;
  }
  if (typeof value === 'string') {
    // Rewrite the whole quoted path so the separators match the platform: a Windows hook
    // command should read C:\Users\x\.whip\monitor\hooks\..., not a mix of both.
    return value.replace(/"@MONITOR@[^"]*"/g, (quoted) => {
      const inner = quoted.slice(1, -1).replace('@MONITOR@', monitorDir);
      const absolute = inner.indexOf('/') === 0 ? '/' : '';
      return '"' + absolute + path.join(...inner.split('/').filter(Boolean)) + '"';
    }).replace(/@MONITOR@/g, monitorDir);
  }
  return value;
}

function entryHooks(group) {
  return (group && group.hooks) || [];
}

const ourHooksDir = path.join(monitorDir, 'hooks');

/** Does this hook's command point at one of our hook scripts? */
function isOurs(hook, dir) {
  const cmd = String((hook && hook.command) || '').replace(/"/g, '').replace(/\\/g, '/');
  return cmd.indexOf(dir.replace(/\\/g, '/')) >= 0;
}

/** True when the command mentions some monitor hooks dir (any location, not just ours). */
function mentionsAnyMonitorHooks(hook) {
  return String((hook && hook.command) || '').indexOf('/monitor/hooks/') >= 0
    || String((hook && hook.command) || '').indexOf('\\monitor\\hooks\\') >= 0;
}

function merge(target, sourceHooks) {
  const cfg = load(target);
  const hooks = (cfg.hooks = cfg.hooks || {});
  for (const event of Object.keys(sourceHooks || {})) {
    const arr = (hooks[event] = hooks[event] || []);
    // Drop our entries left at an older monitor location: they point at files that no
    // longer exist and would silently swallow events. Other hooks are never touched.
    const kept = arr.filter(group => (entryHooks(group) || []).every(hook =>
      !mentionsAnyMonitorHooks(hook) || isOurs(hook, ourHooksDir)));
    arr.length = 0;
    arr.push(...kept);
    // Install the current-path entries when they are missing.
    if (!arr.some(group => (entryHooks(group) || []).some(hook => isOurs(hook, ourHooksDir)))) {
      for (const g of sourceHooks[event] || []) {
        if (g && typeof g === 'object') arr.push(g);
      }
    }
  }
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, JSON.stringify(cfg, null, 2) + '\n', 'utf8');
}

const claudeSrc = subst(load(path.join(configDir, 'claude-hooks.json')));
const codexSrc = subst(load(path.join(configDir, 'codex-hooks.json')));
merge(claudePath, claudeSrc.hooks);
merge(codexPath, codexSrc.hooks);

process.stdout.write('hooks merged: ' + path.dirname(claudePath) + ', ' + path.dirname(codexPath) + '\n');
