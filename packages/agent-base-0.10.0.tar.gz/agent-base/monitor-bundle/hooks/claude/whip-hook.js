#!/usr/bin/env node
'use strict';
/**
 * Claude Code hook adapter: reads raw hook event JSON on stdin, canonicalizes it and
 * appends one canonical event line to the event stream.
 *
 * Protocol: ../AGENT-EVENTS.md
 * Deployment: ../README.md (container path /root/.whip/monitor/hooks/...)
 */
const path = require('path');
const {
  appendEvent,
  cap,
  isSummarizerSelf,
  contextOf,
} = require(path.join(__dirname, '..', 'lib', 'canonical.js'));
const { canonicalize } = require(path.join(__dirname, 'canonicalize.js'));

let raw = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (d) => { raw += d; });
process.stdin.on('end', () => {
  try {
    let payload;
    try {
      payload = JSON.parse(raw);
    } catch (e) {
      // Keep a record of unparseable input so malformed hook payloads stay diagnosable
      appendEvent({
        v: 1,
        agent: 'claude',
        ts: Date.now(),
        kind: 'other',
        message: 'unparseable hook input: ' + cap(raw, 200),
      });
      return;
    }
    // Summarizer self-calls are never persisted, avoiding recursive writes
    if (isSummarizerSelf(payload)) return;
    const ev = canonicalize(payload, Date.now());
    appendEvent(Object.assign({}, contextOf(ev.sessionId), ev));
  } catch (e) {
    process.stderr.write('whip-hook error: ' + (e && e.message) + '\n');
  }
});
