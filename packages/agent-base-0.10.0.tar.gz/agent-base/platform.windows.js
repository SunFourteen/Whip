/* Whip host platform: Windows (OpenSSH for Windows, cmd/PowerShell login shell).
 *
 * The app runs plugin commands through PowerShell on a Windows host, so everything here is
 * PowerShell. Two differences from POSIX shape the design:
 *   - there is no /dev/tty and no per-shell pts: a shell is identified by the pid its marker
 *     publishes, and an agent counts as "in" a shell only when that pid is one of its
 *     ancestors;
 *   - paths are Windows paths, which must be quoted with PowerShell rules ('' for a quote).
 */
window.WhipPlatformWindows = (function () {
  'use strict';

  var env = {};
  try { env = JSON.parse(SshBridge.env() || '{}') || {}; } catch (e) {}
  var HOME = env.home || '';
  // The shell the app types a shell startup line into (env.shell): OpenSSH on Windows
  // usually hands out cmd.exe. Plugin commands the app runs itself go through PowerShell,
  // but a resume line is typed into this shell, and each shell quotes differently.
  var LOGIN_SHELL = String(env.shell || 'cmd').toLowerCase();
  var CMD_LOGIN = LOGIN_SHELL.indexOf('cmd') >= 0;

  function join(a, b) {
    if (!a) return b || '';
    if (!b) return a;
    return String(a).replace(/[\\/]+$/, '') + '\\' + String(b).replace(/^[\\/]+/, '').replace(/\//g, '\\');
  }
  function dirOf(path) {
    var s = String(path || '');
    var i = s.lastIndexOf('\\');
    var j = s.lastIndexOf('/');
    var k = Math.max(i, j);
    return k > 0 ? s.slice(0, k) : '';
  }
  /** PowerShell single-quoted literal: everything is literal, '' escapes a quote. */
  function q(s) { return "'" + String(s == null ? '' : s).replace(/'/g, "''") + "'"; }

  /**
   * One argument for the login shell the app types into.
   *
   * cmd.exe has no single-quote syntax: it passes the quotes straight through, so
   * `codex resume '01a0…'` reaches codex as a name with quotes and it answers
   * "No saved session found with ID '01a0…'" — even though the session is there. cmd's own
   * quoting is a double-quoted word; a plain uuid or path needs no quotes at all.
   */
  function shellArg(s) {
    s = String(s == null ? '' : s);
    if (!CMD_LOGIN) return q(s);
    if (s === '') return '""';
    if (/^[A-Za-z0-9._:\\\/-]+$/.test(s)) return s;
    return '"' + s.replace(/"/g, '\\"') + '"';
  }

  var monitorDir = join(HOME, '.whip\\monitor');
  var stateDir = join(monitorDir, 'state');

  return {
    id: 'windows',
    label: env.label || 'Windows',
    /**
     * How often the plugin may re-scan the process table. Every scan is a fresh PowerShell
     * plus a CIM listing, so Windows asks less often than a /proc host does.
     */
    procRefreshMs: 6000,
    home: HOME,
    join: join,
    dirOf: dirOf,
    quotePath: q,

    monitorDir: monitorDir,
    stateDir: stateDir,
    cardsPath: join(stateDir, 'cards.json'),
    cardsDir: join(stateDir, 'cards'),
    livePath: join(stateDir, 'agent.ndjson'),
    streamPath: join(stateDir, 'cards.ndjson'),

    readCmd: function (path) {
      // -Encoding UTF8 is not optional: Get-Content guesses the ANSI code page for a BOM-less
      // file, which mangles every non-ASCII character in cards.json (measured 26049 chars
      // read as 27983) and even turns some byte pairs into raw control characters, so
      // JSON.parse fails and the page silently falls back to the live tail — old sessions
      // never showed up.
      return 'Get-Content -LiteralPath ' + q(path)
        + ' -Raw -Encoding UTF8 -ErrorAction SilentlyContinue';
    },

    tailCmd: function (path, n) {
      return 'Get-Content -LiteralPath ' + q(path) + ' -Tail ' + Number(n || 50)
        + ' -Encoding UTF8 -ErrorAction SilentlyContinue';
    },

    /**
     * Same output shape as the POSIX scan ("<tty> <command line>"), but the first field is
     * the id of the shell the agent actually runs in.
     *
     * Windows has no pts, so "which shell is this agent in" is answered by walking the
     * process ancestry up to a process the app named in ~/.whip/shells (the shells publish
     * their own pid). An agent that belongs to no app shell — an editor extension, a service,
     * another terminal — reports "none" and the page shows no shell for it, instead of
     * pointing at whichever shell happens to be newest.
     */
    agentScanCmd: function () {
      var home = HOME.replace(/'/g, "''");
      return [
        "$shellDir = Join-Path '" + home + "' '.whip\\shells'",
        "$shellPids = @{}",
        "if (Test-Path -LiteralPath $shellDir) {",
        "  Get-ChildItem -LiteralPath $shellDir -File -ErrorAction SilentlyContinue | ForEach-Object {",
        "    $p = (Get-Content -LiteralPath $_.FullName -Raw -ErrorAction SilentlyContinue) -split '\\s+'",
        "    if ($p.Count -ge 2 -and $p[1] -match '^\\d+$') { $shellPids[[int]$p[1]] = $true }",
        "  }",
        "}",
        "$all = @{}",
        // One listing feeds both the parent map and the agent filter: enumerating the
        // process table twice was the single most expensive part of a monitor tick.
        "$procs = Get-CimInstance Win32_Process",
        "foreach ($p in $procs) { $all[[int]$p.ProcessId] = $p }",
        "foreach ($p in $procs) {",
        "  if (-not $p.CommandLine) { continue }",
        "  if ($p.CommandLine -notmatch 'claude|codex') { continue }",
        "  $cur = $p",
        "  $owner = 'none'",
        "  for ($i = 0; $i -lt 12 -and $cur; $i++) {",
        "    if ($shellPids.ContainsKey([int]$cur.ProcessId)) { $owner = [string]$cur.ProcessId; break }",
        "    $next = $null",
        "    if ($all.ContainsKey([int]$cur.ParentProcessId)) { $next = $all[[int]$cur.ParentProcessId] }",
        "    $cur = $next",
        "  }",
        "  Write-Output ($owner + ' ' + $p.ProcessId + ' ' + $p.CommandLine)",
        "}"
      ].join('\n');
    },

    /** On Windows a shell's identity is its pid (see shellMarkerCommand). */
    isWorkspaceTty: function (tty) {
      return /^\d+$/.test(String(tty == null ? '' : tty).trim());
    },

    /** Parse one agentScanCmd line into {tty, pid, args}; tty '' means "no app shell". */
    parseProcLine: function (line) {
      var m = /^(\S+)\s+(\d+)\s+([\s\S]*)$/.exec(String(line == null ? '' : line).trim());
      if (!m) return null;
      return {
        tty: m[1] === 'none' ? '' : m[1],
        pid: Number(m[2]) || 0,
        args: m[3]
      };
    },

    killCmd: function (pid) {
      return '$ErrorActionPreference=\'Stop\'; Stop-Process -Id ' + Number(pid) + ' -Force';
    },

    resumeCmd: function (agent, sid) {
      var id = shellArg(sid);
      if (agent === 'claude') return 'claude --resume ' + id;
      if (agent === 'codex') return 'codex resume ' + id;
      return '';
    }
  };
})();
