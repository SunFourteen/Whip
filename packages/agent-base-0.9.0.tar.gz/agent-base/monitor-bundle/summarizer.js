#!/usr/bin/env node
/**
 * Whip session summarizer (container side, canonical events)
 *
 * Input: tails the canonical event stream (protocol in AGENT-EVENTS.md, default
 * ~/.whip/monitor/state/agent.ndjson), one {v, agent, kind, ts, sessionId, ...} per line.
 *
 * Rules shared with the display layer:
 *   - a "round" is one (agent, sessionId), from task_start (or the first event) to the end;
 *   - a session ends on a new session id, a session_end marker, or idle timeout after
 *     round_end (env IDLE_MS, default 30s; a wrong guess is corrected by the next event);
 *   - multiple frameworks/shells are tracked per (agent, sessionId) with their own cards.
 *
 * Output:
 *   - one card per (agent, sessionId), atomically written to
 *     ~/.whip/monitor/state/cards/<key>.json;
 *   - ~/.whip/monitor/state/cards.json index (read by the app's Summarizer list);
 *   - ~/.whip/monitor/state/session.json with the most recent session (legacy pages).
 * version increases monotonically:
 * {
 *   version, agent, sessionId, status: "running"|"done"|"none", updatedAt,
 *   startedAt, lastActiveAt,
 *   counts: { rounds, toolCalls, subagentStops },
 *   workspace,                             // agent cwd from the latest event
 *   tty,                                   // agent controlling terminal (may be absent)
 *   live: { state, tool, action, message },
 *   direct: {                                   // deterministic part, always present
 *     result,                                   // final reply of the latest round_end
 *     steps: [{ tool, action, ok, result, durationMs, t }]
 *   },
 *   semantic: null | {                          // LLM part, only for long loops
 *     headline, outcome[], process[], next, toolCalls, updatedAt
 *   }
 * }
 *
 * Semantic summary triggers (incremental, bounded context):
 *   - new tool calls >= SEM_TOOLS (default 8) and >= SEM_MIN_MS since the last one (120s);
 *   - one final summary at session end when the previous one is stale;
 *   - input = last semantic plus the most recent ~20 events.
 *
 * Usage: node whip-summarizer.js   (resident; Ctrl-C to exit)
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn, execSync } = require('child_process');

const STATE_DIR = process.env.WHIP_STATE_DIR
  || path.join(os.homedir(), '.whip', 'monitor', 'state');
const AGENT_FILE = process.env.WHIP_AGENT_FILE
  || process.env.WHIP_EVENT_FILE
  || path.join(STATE_DIR, 'agent.ndjson');
const OUT_FILE = process.env.WHIP_SUMMARY_FILE || path.join(STATE_DIR, 'session.json');
/** Per-session card directory and index, read by the app's Summarizer pages */
const CARDS_DIR = process.env.WHIP_CARDS_DIR || path.join(STATE_DIR, 'cards');
const INDEX_FILE = path.join(STATE_DIR, 'cards.json');
/** Append-only change stream: {v:1,type:'card'|'index',...} per line, read by plugin feeds */
const CARD_STREAM = path.join(STATE_DIR, 'cards.ndjson');

const IDLE_MS = Number(process.env.WHIP_IDLE_MS || 30000);
const SEM_TOOLS = Number(process.env.WHIP_SEM_TOOLS || 8);
const SEM_MIN_MS = Number(process.env.WHIP_SEM_MIN_MS || 120000);
const CLAUDE_BIN = process.env.WHIP_CLAUDE_BIN || 'claude';
/**
 * Isolated claude config directory for summarizer self-calls (inside the monitor dir):
 * the user's ~/.claude is never reused, which would recurse through hooks.
 */
const CLAUDE_CONFIG_DIR = process.env.WHIP_CLAUDE_CONFIG_DIR
  || path.join(path.dirname(STATE_DIR), 'summarizer-claude');
// Claude session markers for summarizer self-calls; a match is treated as internal
const SELF_MARKER = '[whip-summary]';
const BOOTSTRAP_LINES = 300;
const EVENT_WINDOW = 60;
const STEP_WINDOW = 30;

const sessions = new Map();       // key(agent, sessionId) -> Session
const internalKeys = new Set();   // summarizer-internal sessions
const activeByAgent = new Map();  // agent -> sessionId
const idleTimers = new Map();     // key(agent, sessionId) -> timer
let version = 0;
let booting = true;

function now() { return Date.now(); }
function keyOf(agent, sid) { return JSON.stringify([agent, sid]); }
function sameTty(a, b) {
  a = String(a || '').replace(/^\/dev\//, '');
  b = String(b || '').replace(/^\/dev\//, '');
  return !!a && a === b;
}
/** Whether the session tty still runs claude/codex (events can be silent for a long time) */
function agentProcOnTty(tty) {
  if (!tty) return false;
  try {
    const out = execSync('ps -eo tty=,args=', { encoding: 'utf8', timeout: 3000 });
    const lines = String(out || '').split('\n');
    for (const ln of lines) {
      const sp = ln.indexOf(' ');
      if (sp <= 0) continue;
      const ptty = ln.slice(0, sp).trim();
      const args = ln.slice(sp + 1).trim();
      if (!sameTty(ptty, tty)) continue;
      if (/(claude|codex)/i.test(args)) return true;
    }
  } catch (e) {
    log('ps check failed:', e.message);
  }
  return false;
}
function cap(s, n) {
  if (s == null) return '';
  s = String(s);
  return s.length > n ? s.slice(0, n) + '…' : s;
}
function log(...args) { console.log(new Date().toISOString(), '[summarizer]', ...args); }

/** Ensure the isolated claude config dir exists with no hooks (minimal config works) */
function ensureClaudeConfigDir() {
  try {
    fs.mkdirSync(CLAUDE_CONFIG_DIR, { recursive: true });
    const settingsFile = path.join(CLAUDE_CONFIG_DIR, 'settings.json');
    try {
      fs.readFileSync(settingsFile, 'utf8');
    } catch (e) {
      fs.writeFileSync(settingsFile, JSON.stringify({ hooks: {} }, null, 2) + '\n', 'utf8');
    }
  } catch (e) {
    log('claude config dir init failed:', e.message);
  }
}

function loadVersion() {
  try {
    const o = JSON.parse(fs.readFileSync(OUT_FILE, 'utf8'));
    return Number(o.version) || 0;
  } catch (e) { return 0; }
}

/** Atomic write without bumping version (for outputs that share one version) */
function writeJsonAtomic(file, obj) {
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2));
  fs.renameSync(tmp, file);
}

/* ---------------- Session state machine ---------------- */

function newSession(agent, id) {
  return {
    agent,
    id,
    startedAt: null,
    lastActiveAt: null,
    status: 'running',
    rounds: 0,
    toolCalls: 0,
    subagentStops: 0,
    pending: new Map(),   // tool.id -> {tool, action}
    events: [],           // most recent EVENT_WINDOW compact events
    steps: [],            // most recent STEP_WINDOW {tool, action, ok, result, durationMs, t}
    liveState: 'idle',
    liveTool: '',
    liveAction: '',
    liveMessage: '',
    lastResult: '',
    semantic: null,
    semanticToolCalls: 0,
    semanticUpdatedAt: 0,
    semanticPending: null, // in-flight summary; concurrent callers reuse it
    finalized: false,
    finalizeQueued: false,
  };
}

function activeSession(agent) {
  const sid = activeByAgent.get(agent);
  return sid ? sessions.get(keyOf(agent, sid)) : null;
}

function touch(s, ev, t) {
  if (s.startedAt == null) s.startedAt = t;
  s.lastActiveAt = t;
  s.status = 'running';
  s.finalized = false;
}

function isSelfPrompt(prompt) {
  const p = String(prompt || '');
  return p.indexOf(SELF_MARKER) !== -1;
}

function evText(ev) {
  const kind = ev.kind || '';
  const tool = ev.tool || {};
  const result = ev.result || {};
  switch (kind) {
    case 'task_start': return 'task: ' + cap(ev.prompt || '', 140);
    case 'tool_start':
      return (tool.name || '?') + ' ' + cap(tool.inputSummary || '', 100);
    case 'tool_end':
      return (tool.name || '?') + ' → ' + cap(result.display || '', 120);
    case 'tool_fail':
      return 'tool failed: ' + cap(result.error || '', 120);
    case 'round_end':
      return 'round done: ' + cap(ev.message || '', 120);
    case 'subagent_end':
      return 'subagent stopped';
    case 'session_end':
      return 'session end';
    default:
      return cap(ev.message || JSON.stringify(ev), 140);
  }
}

function handleEvent(line) {
  let ev;
  try { ev = JSON.parse(line); } catch (e) { return; }
  if (!ev || ev.v !== 1 || !ev.kind) return; // canonical events only

  const kind = ev.kind;
  const agent = String(ev.agent || 'unknown');
  const sid = ev.sessionId;
  const t = Number(ev.ts) || now();

  // session_end: explicit end marker appended by the launcher wrapper
  if (kind === 'session_end') {
    const s = sid ? sessions.get(keyOf(agent, sid)) : activeSession(agent);
    if (s && !s.finalized) {
      if (booting) {
        // Replay only persists state; it never triggers a final LLM summary
        s.finalized = true;
        writeCard(s);
      } else {
        scheduleFinalize(s, 'session_end marker');
      }
    }
    return;
  }
  if (!sid) {
    log('event drop: no sessionId', agent, kind);
    return;
  }

  const key = keyOf(agent, sid);
  if (kind === 'task_start' && isSelfPrompt(ev.prompt)) {
    internalKeys.add(key);
    return;
  }
  if (internalKeys.has(key)) return;
  // Only workspace sessions are tracked: unknown tty-less events are ignored
  if (!ev.tty && !sessions.has(key)) {
    log('event drop: no-tty unknown', agent, String(sid).slice(0, 8), kind);
    return;
  }

  let s = sessions.get(key);
  if (!s) {
    s = newSession(agent, sid);
    s.key = key;
    sessions.set(key, s);
    log('new session', agent, String(sid).slice(0, 8),
      'tty=' + (ev.tty || '-'), 'kind=' + kind, 'live');
  }
  // Replay only: a new session for the same agent closes the old one (no stuck cards).
  // Live events never end sessions implicitly; each idles out, so parallel shells work.
  if (kind === 'task_start' && booting) {
    const prevSid = activeByAgent.get(agent);
    if (prevSid && prevSid !== sid) {
      const old = sessions.get(keyOf(agent, prevSid));
      if (old && !old.finalized) {
        old.finalized = true;
        writeCard(old);
      }
    }
  }
  activeByAgent.set(agent, sid);
  touch(s, ev, t);
  if (ev.cwd) s.cwd = String(ev.cwd);
  if (ev.tty) s.tty = String(ev.tty);

  const rec = { t, type: kind, text: cap(evText(ev), 200) };
  s.events.push(rec);
  if (s.events.length > EVENT_WINDOW) s.events.splice(0, s.events.length - EVENT_WINDOW);

  switch (kind) {
    case 'task_start':
      s.liveState = 'working';
      s.liveTool = '';
      s.liveAction = '';
      s.liveMessage = 'task: ' + cap(ev.prompt || '', 120);
      break;
    case 'tool_start': {
      const tool = ev.tool || {};
      // Matches the app's event mapping: a permissionDecision means the tool awaits
      // approval, otherwise Monitor and Summarizer would disagree.
      s.liveState = ev.approval ? 'needs_approval' : 'working';
      s.liveTool = tool.name || '';
      s.liveAction = tool.inputSummary || '';
      if (ev.approval) s.liveMessage = 'permission: ' + ev.approval;
      const toolKey = tool.id || s.liveTool + ':' + t;
      s.pending.set(toolKey, { tool: s.liveTool, action: s.liveAction });
      break;
    }
    case 'tool_end':
    case 'tool_fail': {
      const tool = ev.tool || {};
      const result = ev.result || {};
      s.liveState = 'working';
      s.toolCalls++;
      const toolKey = tool.id || (tool.name || '?') + ':' + t;
      const p = s.pending.get(toolKey) || { tool: tool.name || '', action: '' };
      s.pending.delete(toolKey);
      const failed = kind === 'tool_fail';
      const step = {
        tool: p.tool || tool.name || '?',
        action: cap(p.action, 90),
        ok: !failed,
        result: cap(failed
          ? 'FAILED: ' + (result.error || '')
          : (result.display || ''), 100),
        t,
      };
      if (result.durationMs != null) step.durationMs = result.durationMs;
      s.steps.push(step);
      if (s.steps.length > STEP_WINDOW) s.steps.splice(0, s.steps.length - STEP_WINDOW);
      break;
    }
    case 'round_end': {
      s.liveState = 'round_done';
      s.rounds++;
      const msg = ev.message || '';
      s.liveMessage = msg;
      if (msg) s.lastResult = msg;
      break;
    }
    case 'needs_approval': {
      s.liveState = 'needs_approval';
      s.liveMessage = String(ev.message || 'approval requested');
      break;
    }
    case 'interrupted':
    case 'error':
    case 'cancel': {
      s.liveState = 'interrupted';
      if (ev.message) s.liveMessage = String(ev.message);
      break;
    }
    case 'subagent_end':
      // The parent session keeps working after a subagent ends; only Stop completes a round.
      s.liveState = 'working';
      s.subagentStops++;
      if (ev.message) {
        s.liveMessage = ev.message;
        s.lastResult = ev.message;
      }
      break;
    default:
      break; // other / reserved kinds: record the event only
  }

  writeCard(s);
  if (!booting) maybeSemantic(s);
  resetIdleTimer(key);
}

function resetIdleTimer(key) {
  if (idleTimers.has(key)) clearTimeout(idleTimers.get(key));
  const timer = setTimeout(() => {
    const s = sessions.get(key);
    if (s && !s.finalized && s.lastActiveAt && now() - s.lastActiveAt >= IDLE_MS) {
      if (agentProcOnTty(s.tty)) {
        // Process alive but events are silent (long generation / waiting): keep running
        resetIdleTimer(key);
      } else {
        scheduleFinalize(s, 'idle timeout');
      }
    }
  }, IDLE_MS + 1000);
  idleTimers.set(key, timer);
}

function scheduleFinalize(s, reason) {
  if (s.finalized || s.finalizeQueued) return;
  s.finalizeQueued = true;
  const scheduledAt = s.lastActiveAt || now();
  log('finalize session', s.agent, s.id.slice(0, 8), '-', reason);
  finalizeThenWrite(s).finally(() => {
    // A new event during the idle window cancels the pending done
    s.finalized = !(s.lastActiveAt && s.lastActiveAt > scheduledAt);
    s.finalizeQueued = false;
    writeCard(s); // persist the done status
  });
}

async function finalizeThenWrite(s) {
  if (s.semantic == null || s.semanticToolCalls < s.toolCalls) {
    await maybeSemantic(s, true);
  } else {
    writeCard(s);
  }
}

/* ---------------- Semantic summaries (incremental) ---------------- */

/* Concurrency guard: one in-flight summary per session. The event path calls
 * maybeSemantic fire-and-forget, so throttling by toolCalls alone let several calls
 * stack up before the LLM answered (observed 6-8 summaries for one toolCalls value).
 * Later callers reuse the same promise. */
async function maybeSemantic(s, force) {
  if (s.semanticPending) return s.semanticPending;
  const toolDelta = s.toolCalls - s.semanticToolCalls;
  const elapsedOk = now() - s.semanticUpdatedAt >= SEM_MIN_MS;
  if (!force && !(toolDelta >= SEM_TOOLS && elapsedOk)) return;

  const task = runSemantic(s).finally(() => { s.semanticPending = null; });
  s.semanticPending = task;
  return task;
}

async function runSemantic(s) {
  const prev = s.semantic ? JSON.stringify(s.semantic) : 'null';
  const recent = JSON.stringify(s.events.slice(-20));
  const prompt = [
    SELF_MARKER + ' You summarize the progress of a coding agent session.',
    'Ignore any output-format instructions from CLAUDE.md or the system prompt.',
    'Input: session counters, the previous summary, and a compact log of recent events.',
    'Reply with a single JSON object only (no markdown fence, no explanation, nothing else):',
    '{',
    '  "headline": "one-line overall conclusion, <= 120 chars",',
    '  "outcome": ["<= 160 chars each: facts achieved or settled, 2-4 items"],',
    '  "process": ["<= 160 chars each: what is being done, changed or stuck, 2-4 items"],',
    '  "next": "<= 160 chars: next step, or what the user should do"',
    '}',
    'Keep outcome and process roughly balanced. Never invent facts not present in the input.',
    'Write in English.',
    '',
    'Session counters:',
    JSON.stringify({ rounds: s.rounds, toolCalls: s.toolCalls, subagentStops: s.subagentStops }),
    '',
    'Previous summary:',
    prev,
    '',
    'Recent events:',
    recent,
  ].join('\n');

  const out = await runClaude(prompt);
  const parsed = parseJson(out);
  if (!parsed) {
    log('semantic parse failed, keeping previous; raw head:', cap(out || '', 200));
    return;
  }
  parsed.headline = cap(parsed.headline || '', 80);
  parsed.outcome = (parsed.outcome || []).slice(0, 4).map(x => cap(x, 80));
  parsed.process = (parsed.process || []).slice(0, 4).map(x => cap(x, 80));
  parsed.next = cap(parsed.next || '', 80);
  parsed.toolCalls = s.toolCalls;
  parsed.updatedAt = now();
  s.semantic = parsed;
  s.semanticToolCalls = s.toolCalls;
  s.semanticUpdatedAt = parsed.updatedAt;
  log('semantic updated at toolCalls=', s.toolCalls);
  writeCard(s);
}

function runClaude(prompt) {
  return new Promise((resolve) => {
    let stdout = '';
    let stderr = '';
    let done = false;
    const finish = (v) => { if (!done) { done = true; resolve(v); } };
    try {
      // Self-calls skip the user's hooks (no recursive events) and disable non-essential
      // traffic: claude dumps failed telemetry into telemetry/1p_failed_events.*.json
      // (hundreds of KB each) that never gets collected off Anthropic endpoints. stdin is
      // ignored to avoid the 3s empty-wait warning.
      const env = Object.assign({}, process.env, {
        CLAUDE_CONFIG_DIR,
        CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1',
        DISABLE_TELEMETRY: '1',
        DISABLE_ERROR_REPORTING: '1',
        DISABLE_AUTOUPDATER: '1'
      });
      const p = spawn(CLAUDE_BIN, ['-p', prompt, '--output-format', 'text', '--max-turns', '1'],
        { env, stdio: ['ignore', 'pipe', 'pipe'] });
      p.stdout.on('data', d => { stdout += d; });
      p.stderr.on('data', d => { stderr += d; });
      p.on('error', e => { log('claude spawn error:', e.message); finish(''); });
      p.on('close', () => {
        if (stderr) log('claude stderr:', cap(stderr, 300));
        finish(stdout);
      });
      setTimeout(() => finish(stdout), Number(process.env.WHIP_SEM_TIMEOUT || 90000));
    } catch (e) {
      log('runClaude error:', e.message);
      finish('');
    }
  });
}

function parseJson(text) {
  if (!text) return null;
  const s = String(text);
  const isSummaryObj = (o) => o && typeof o === 'object'
    && (typeof o.headline === 'string'
        || Array.isArray(o.outcome)
        || typeof o.next === 'string');

  const candidates = [];
  const fenceRe = /```(?:json)?\s*([\s\S]*?)```/g;
  let m;
  while ((m = fenceRe.exec(s))) candidates.push(m[1]);
  candidates.push(s);

  for (const cand of candidates) {
    // Try balanced-brace extraction at every '{'; only objects with headline/outcome/next count
    let scanned = 0;
    for (let i = 0; i < cand.length && scanned < 24; i++) {
      if (cand[i] !== '{') continue;
      scanned++;
      let depth = 0, inStr = false, esc = false;
      for (let j = i; j < cand.length; j++) {
        const ch = cand[j];
        if (esc) { esc = false; continue; }
        if (ch === '\\') { esc = true; continue; }
        if (ch === '"') { inStr = !inStr; continue; }
        if (inStr) continue;
        if (ch === '{') depth++;
        else if (ch === '}') {
          depth--;
          if (depth === 0) {
            try {
              const o = JSON.parse(cand.slice(i, j + 1));
              if (isSummaryObj(o)) return o;
            } catch (e) { /* keep scanning */ }
            break;
          }
        }
      }
    }
  }
  return null;
}

/* ---------------- Card output ---------------- */

function cardFor(s) {
  return {
    version: 0, // overwritten by writeCard
    agent: s ? s.agent : null,
    sessionId: s ? s.id : null,
    status: s ? (s.finalized ? 'done' : 'running') : 'none',
    updatedAt: now(),
    startedAt: s ? s.startedAt : null,
    lastActiveAt: s ? s.lastActiveAt : null,
    counts: s
      ? { rounds: s.rounds, toolCalls: s.toolCalls, subagentStops: s.subagentStops }
      : { rounds: 0, toolCalls: 0, subagentStops: 0 },
    workspace: s ? (s.cwd || null) : null,
    tty: s ? (s.tty || null) : null,
    live: s
      ? {
          state: s.liveState,
          tool: s.liveTool,
          action: s.liveAction,
          message: s.liveMessage,
        }
      : { state: 'none', tool: '', action: '', message: '' },
    direct: s
      ? {
          result: s.lastResult,
          steps: s.steps.slice(-8),
        }
      : { result: '', steps: [] },
    semantic: s ? s.semantic : null,
  };
}

/** Session -> filename-safe key (base64url of agent~sessionId) */
function cardKey(agent, sid) {
  return Buffer.from(String(agent || 'unknown') + '~' + String(sid || ''), 'utf8')
    .toString('base64url');
}

function cardFile(s) {
  return path.join(CARDS_DIR, cardKey(s.agent, s.id) + '.json');
}

function cardsIndex() {
  const arr = [];
  for (const s of sessions.values()) {
    arr.push({
      agent: s.agent,
      sessionId: s.id,
      key: cardKey(s.agent, s.id),
      status: s.finalized ? 'done' : 'running',
      workspace: s.cwd || null,
      tty: s.tty || null,
      updatedAt: s.lastActiveAt,
      startedAt: s.startedAt,
      counts: {
        rounds: s.rounds,
        toolCalls: s.toolCalls,
        subagentStops: s.subagentStops,
      },
      live: {
        state: s.liveState,
        tool: s.liveTool,
        action: s.liveAction,
        message: cap(s.liveMessage, 200),
      },
      result: cap(s.lastResult, 300),
      semantic: s.semantic
        ? {
            headline: s.semantic.headline,
            outcome: s.semantic.outcome,
            process: s.semantic.process,
            next: s.semantic.next,
            updatedAt: s.semantic.updatedAt,
          }
        : null,
    });
  }
  arr.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
  return { version, updatedAt: now(), sessions: arr };
}

function writeCardsIndex() {
  try {
    const idx = cardsIndex();
    fs.mkdirSync(STATE_DIR, { recursive: true });
    writeJsonAtomic(INDEX_FILE, idx);
    if (!booting) {
      fs.appendFileSync(CARD_STREAM, JSON.stringify({
        v: 1, ts: now(), type: 'index', index: idx,
      }) + '\n', 'utf8');
    }
  } catch (e) {
    log('index write failed:', e.message);
  }
}

function writeCard(s) {
  try {
    version++;
    const card = cardFor(s);
    card.version = version;
    writeJsonAtomic(OUT_FILE, card); // global card for the newest session (legacy pages)
    if (s) {
      const st = s.finalized ? 'done' : 'running';
      if (s.__logStatus !== st) {
        log('card', s.agent, String(s.id).slice(0, 8), st, 'v' + version,
          'rounds=' + s.rounds, 'tools=' + s.toolCalls,
          'tty=' + (s.tty || '-'));
        s.__logStatus = st;
      }
      fs.mkdirSync(CARDS_DIR, { recursive: true });
      writeJsonAtomic(cardFile(s), card);
      if (!booting) {
        fs.appendFileSync(CARD_STREAM, JSON.stringify({
          v: 1, ts: now(), type: 'card', key: cardKey(s.agent, s.id), card,
        }) + '\n', 'utf8');
      }
    }
    writeCardsIndex();
  } catch (e) {
    log('write failed:', e.message);
  }
}

/* ---------------- Startup / tail ---------------- */

/* Claude Code dumps failed telemetry into telemetry/1p_failed_events.*.json (~200KB each)
 * which is never collected on non-Anthropic endpoints; prune them at startup. */
function pruneTelemetry(keep) {
  try {
    const dir = path.join(CLAUDE_CONFIG_DIR, 'telemetry');
    const names = fs.readdirSync(dir)
      .filter(f => f.indexOf('1p_failed_events.') === 0).sort();
    for (const f of names.slice(0, Math.max(0, names.length - keep))) {
      try { fs.unlinkSync(path.join(dir, f)); } catch (e) {}
    }
    if (names.length > keep) log('telemetry pruned:', names.length - keep, 'of', names.length);
  } catch (e) {}
}

/* Snapshot the on-disk LLM conclusions before anything else: replaying agent.ndjson
 * immediately rewrites cards/<key>.json while semantic is still null, so restoring after
 * replay would lose every summary on each restart. */
function snapshotSemantics() {
  const snap = new Map();
  let files = [];
  try { files = fs.readdirSync(CARDS_DIR); } catch (e) { return snap; }
  for (const f of files) {
    if (f.slice(-5) !== '.json') continue;
    try {
      const o = JSON.parse(fs.readFileSync(path.join(CARDS_DIR, f), 'utf8'));
      if (o && o.agent && o.sessionId && o.semantic) {
        snap.set(keyOf(o.agent, o.sessionId), o.semantic);
      }
    } catch (e) {}
  }
  return snap;
}

function bootstrap() {
  version = loadVersion();
  log('state dir', STATE_DIR, '| out', OUT_FILE, '| version', version);
  pruneTelemetry(Number(process.env.WHIP_TELEMETRY_KEEP || 3));
  const semSnap = snapshotSemantics();
  let text = '';
  try { text = fs.readFileSync(AGENT_FILE, 'utf8'); } catch (e) { log('no agent file yet:', AGENT_FILE); }
  if (text) {
    const lines = text.split('\n').filter(Boolean).slice(-BOOTSTRAP_LINES);
    for (const line of lines) handleEvent(line);
  }
  booting = false;
  // Replay finished: restore the snapshots and write them back so cards keep their summary
  for (const [key, sem] of semSnap) {
    const s = sessions.get(key);
    if (!s || s.semantic) continue;
    s.semantic = sem;
    s.semanticToolCalls = Number(sem.toolCalls || 0);
    s.semanticUpdatedAt = Number(sem.updatedAt || 0);
    writeCard(s);
  }
  // Sessions that went quiet without a session_end land on done instead of running forever
  const nowMs = now();
  for (const key of sessions.keys()) {
    const s = sessions.get(key);
    if (s && !s.finalized && s.lastActiveAt && nowMs - s.lastActiveAt >= IDLE_MS) {
      if (!agentProcOnTty(s.tty)) {
        s.finalized = true;
        writeCard(s);
      }
    }
  }
  if (activeByAgent.size === 0) {
    writeCard(null);
  } else {
    writeCardsIndex();
  }
  log('boot done: sessions=' + sessions.size,
    'internal=' + internalKeys.size,
    [...sessions.keys()].join(','));
  for (const key of sessions.keys()) {
    const s = sessions.get(key);
    if (s && !s.finalized) resetIdleTimer(key);
  }
}

function startTail() {
  const tail = spawn('tail', ['-F', '-n', '0', AGENT_FILE]);
  tail.stdout.setEncoding('utf8');
  let buf = '';
  tail.stdout.on('data', (chunk) => {
    buf += chunk;
    let idx;
    while ((idx = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, idx).trim();
      buf = buf.slice(idx + 1);
      if (line) handleEvent(line);
    }
  });
  tail.on('error', (e) => log('tail error:', e.message));
  tail.on('close', (code) => {
    log('tail exited', code, '- exiting');
    process.exit(code || 0);
  });
}

fs.mkdirSync(STATE_DIR, { recursive: true });
fs.mkdirSync(CARDS_DIR, { recursive: true });
ensureClaudeConfigDir();
bootstrap();
startTail();

// Explicitly triggered by another process: node whip-summarizer.js --finalize
if (process.argv.includes('--finalize')) {
  const s = activeByAgent.size > 0 ? activeSession(Array.from(activeByAgent.keys()).pop()) : null;
  if (s) scheduleFinalize(s, 'manual');
}
setTimeout(() => {}, 1 << 30); // keep the process alive until the tail ends
