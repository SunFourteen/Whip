'use strict';
/**
 * Claude Code hook event -> canonical agent event (protocol: ../AGENT-EVENTS.md).
 * Pure function, no I/O; ts is supplied by the caller (the hook passes Date.now()).
 */
const { cap } = require('../lib/canonical.js');

const KIND_BY_HOOK = {
  UserPromptSubmit: 'task_start',
  PreToolUse: 'tool_start',
  PostToolUse: 'tool_end',
  PostToolUseFailure: 'tool_fail',
  Stop: 'round_end',
  SubagentStop: 'subagent_end',
  SessionEnd: 'session_end',
};

/** Compress tool input into one line (display only, <=240 chars) */
function summarizeInput(input) {
  if (!input || typeof input !== 'object') return '';
  if (typeof input.file_path === 'string') return cap(input.file_path, 200);
  if (typeof input.command === 'string') return cap(input.command, 200);
  if (typeof input.query === 'string') return cap(input.query, 160);
  if (typeof input.url === 'string') return cap(input.url, 160);
  if (typeof input.pattern === 'string') return cap(input.pattern, 160);
  return cap(JSON.stringify(input), 240);
}

/** Compress the tool response into one line (display only, <=240 chars) */
function summarizeResponse(resp) {
  if (!resp || typeof resp !== 'object') return '';
  const file = resp.file;
  if (file && typeof file === 'object') {
    const fp = file.filePath || file.path || '';
    const lines = file.totalLines != null ? file.totalLines : file.numLines;
    if (fp) return 'read ' + fp + (lines != null ? ' · ' + lines + ' lines' : '');
  }
  if (typeof resp.content === 'string') {
    return cap(resp.content.replace(/\s+/g, ' ').trim(), 240);
  }
  if (resp.content && typeof resp.content === 'object') {
    return cap(JSON.stringify(resp.content), 240);
  }
  return cap(JSON.stringify(resp), 240);
}

function base(payload, ts, kind) {
  const o = {
    v: 1,
    agent: 'claude',
    ts,
    kind,
    // Same fallback as the codex adapter: newer hook payloads use camelCase
    sessionId: payload.session_id || payload.sessionId || '',
  };
  const rawName = payload.hook_event_name;
  if (rawName && rawName !== kind) o.rawName = rawName;
  return o;
}

/** Raw Claude hook payload -> canonical event object */
function canonicalize(payload, ts) {
  if (!payload || typeof payload !== 'object') {
    return {
      v: 1,
      agent: 'claude',
      ts,
      kind: 'other',
      message: cap(payload, 200),
    };
  }
  const name = String(payload.hook_event_name || '');
  const kind = KIND_BY_HOOK[name] || 'other';
  const ev = base(payload, ts, kind);

  switch (kind) {
    case 'task_start':
      ev.prompt = payload.prompt || '';
      break;
    case 'tool_start': {
      const tool = { name: String(payload.tool_name || '?') };
      if (payload.tool_use_id) tool.id = payload.tool_use_id;
      tool.inputSummary = summarizeInput(payload.tool_input);
      ev.tool = tool;
      if (payload.permissionDecision) {
        ev.approval = String(payload.permissionDecision);
      }
      break;
    }
    case 'tool_end':
    case 'tool_fail': {
      const tool = { name: String(payload.tool_name || '?') };
      if (payload.tool_use_id) tool.id = payload.tool_use_id;
      ev.tool = tool;
      const result = { ok: kind === 'tool_end' };
      if (kind === 'tool_end') {
        result.display = summarizeResponse(payload.tool_response);
      } else {
        result.error = cap(payload.error || 'tool failed', 240);
      }
      if (payload.duration_ms != null) result.durationMs = payload.duration_ms;
      ev.result = result;
      break;
    }
    case 'round_end':
      ev.message = String(payload.last_assistant_message || '');
      break;
    case 'subagent_end':
      if (payload.last_assistant_message) {
        ev.message = String(payload.last_assistant_message);
      }
      if (payload.subagent_type) {
        ev.other = { subagentType: payload.subagent_type };
      }
      break;
    case 'session_end':
      break;
    default:
      ev.message = cap(payload, 300);
      break;
  }
  return ev;
}

module.exports = { canonicalize, KIND_BY_HOOK, summarizeInput, summarizeResponse };
