#!/usr/bin/env node
'use strict';
/**
 * Codex CLI hook adapter: reads raw hook event JSON on stdin, canonicalizes it and
 * appends one canonical event line to the event stream.
 *
 * Protocol: ../AGENT-EVENTS.md
 * Deployment: ~/.codex/hooks.json (matcher-group format), e.g.
 * {
 *   "hooks": {
 *     "UserPromptSubmit": [{ "hooks": [{
 *       "type": "command",
 *       "command": "node /root/.whip/monitor/hooks/codex/codex-hook.js"
 *     }] }]
 *   }
 * }
 */
const path = require('path');
const {
  appendEvent,
  cap,
  isSummarizerSelf,
  contextOf,
} = require(path.join(__dirname, '..', 'lib', 'canonical.js'));
const { canonicalize } = require(path.join(__dirname, 'canonicalize.js'));

let raw = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (d) => { raw += d; });
process.stdin.on('end', () => {
  try {
    let payload;
    try {
      payload = JSON.parse(raw);
    } catch (e) {
      appendEvent({
        v: 1,
        agent: 'codex',
        ts: Date.now(),
        kind: 'other',
        message: 'unparseable hook input: ' + cap(raw, 200),
      });
      return;
    }
    // Summarizer self-calls are never persisted, avoiding recursive writes
    if (isSummarizerSelf(payload)) return;
    const ev = canonicalize(payload, Date.now());
    if (ev) appendEvent(Object.assign({}, contextOf(), ev));
  } catch (e) {
    process.stderr.write('codex-hook error: ' + (e && e.message) + '\n');
  }
});
