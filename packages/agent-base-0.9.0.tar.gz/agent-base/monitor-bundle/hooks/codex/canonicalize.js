'use strict';
/**
 * Codex CLI hook event -> canonical agent event (protocol: ../AGENT-EVENTS.md).
 * Pure function, no I/O; ts is supplied by the caller (the hook passes Date.now()).
 *
 * Event set and payloads follow codex-cli 0.153.2 (config.toml / hooks.json
 * matcher-group config); the schema is also embedded in the binary.
 */
const { cap } = require('../lib/canonical.js');

const KIND_BY_EVENT = {
  UserPromptSubmit: 'task_start',
  PreToolUse: 'tool_start',
  PostToolUse: 'tool_end',
  Stop: 'round_end',
  SessionEnd: 'session_end',
  PermissionRequest: 'needs_approval',
  SubagentStop: 'subagent_end',
};

// These events carry no extra monitoring information (task_start comes from
// UserPromptSubmit), so they are ignored to keep the stream small.
const SKIP_EVENTS = new Set(['SessionStart', 'SubagentStart']);

/** Compress tool input into one line (display only, <=240 chars) */
function summarizeInput(input) {
  if (input == null) return '';
  if (typeof input === 'string') return cap(input, 240);
  if (typeof input !== 'object') return cap(String(input), 240);
  if (typeof input.command === 'string') return cap(input.command, 200);
  if (typeof input.file_path === 'string') return cap(input.file_path, 200);
  if (typeof input.pattern === 'string') return cap(input.pattern, 160);
  if (typeof input.description === 'string') {
    return 'apply_patch: ' + cap(input.description, 180);
  }
  return cap(JSON.stringify(input), 240);
}

/** Compress the tool response into one line (display only, <=240 chars) */
function summarizeResponse(resp) {
  if (resp == null) return '';
  if (typeof resp === 'string') {
    return cap(resp.replace(/\s+/g, ' ').trim(), 240);
  }
  if (typeof resp !== 'object') return cap(String(resp), 240);
  if (typeof resp.content === 'string') {
    return cap(resp.content.replace(/\s+/g, ' ').trim(), 240);
  }
  return cap(JSON.stringify(resp), 240);
}

function base(payload, ts, kind) {
  const o = {
    v: 1,
    agent: 'codex',
    ts,
    kind,
    sessionId: payload.session_id || payload.sessionId || '',
  };
  const rawName = payload.hook_event_name;
  if (rawName && rawName !== kind) o.rawName = rawName;
  return o;
}

/**
 * Raw Codex hook payload -> canonical event object.
 * Returns null for hooks that must not be persisted (SessionStart / SubagentStart).
 */
function canonicalize(payload, ts) {
  if (!payload || typeof payload !== 'object') {
    return {
      v: 1,
      agent: 'codex',
      ts,
      kind: 'other',
      message: cap(payload, 200),
    };
  }
  const name = String(payload.hook_event_name || '');
  if (SKIP_EVENTS.has(name)) return null;
  const kind = KIND_BY_EVENT[name] || 'other';
  const ev = base(payload, ts, kind);

  switch (kind) {
    case 'task_start':
      ev.prompt = String(payload.prompt || '');
      break;
    case 'tool_start':
    case 'needs_approval': {
      const tool = { name: String(payload.tool_name || '?') };
      if (payload.tool_use_id) tool.id = payload.tool_use_id;
      tool.inputSummary = summarizeInput(payload.tool_input);
      ev.tool = tool;
      if (kind === 'needs_approval') {
        ev.message = 'codex approval requested';
      }
      break;
    }
    case 'tool_end': {
      const tool = { name: String(payload.tool_name || '?') };
      if (payload.tool_use_id) tool.id = payload.tool_use_id;
      ev.tool = tool;
      ev.result = { ok: true, display: summarizeResponse(payload.tool_response) };
      break;
    }
    case 'round_end':
      ev.message = String(payload.last_assistant_message || '');
      break;
    case 'session_end':
      break;
    case 'subagent_end':
      if (payload.last_assistant_message) {
        ev.message = String(payload.last_assistant_message);
      }
      if (payload.agent_type) ev.other = { agentType: payload.agent_type };
      break;
    default:
      ev.message = cap(payload, 300);
      break;
  }
  return ev;
}

module.exports = {
  canonicalize,
  KIND_BY_EVENT,
  SKIP_EVENTS,
  summarizeInput,
  summarizeResponse,
};
