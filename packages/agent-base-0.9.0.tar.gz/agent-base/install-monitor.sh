#!/usr/bin/env bash
# Agent Monitor self-check / self-install script shipped with the base plugin.
#
# Usage: bash install-monitor.sh
#   - check whether ~/.whip/monitor is installed at the bundled VERSION;
#   - if missing or older, install from this plugin's monitor-bundle/ and merge the
#     minimal .claude/.codex hook entries;
#   - make sure the summarizer daemon is running;
#   - print MONITOR_STATUS / MONITOR_VERSION for the plugin page.
set -u

SRC="$(cd "$(dirname "$0")" && pwd)/monitor-bundle"
DEST="${WHIP_MONITOR_DIR:-$HOME/.whip/monitor}"

if [ ! -d "$SRC" ]; then
  echo "MONITOR_STATUS=missing-src"
  echo "MONITOR_DEST=$DEST"
  exit 0
fi

# Re-entrancy guard: two plugins (or two shapes) may install at the same time
mkdir -p "$DEST"
LOCK="$DEST/.install.lock"
i=0
while ! mkdir "$LOCK" 2>/dev/null; do
  i=$((i + 1))
  [ "$i" -gt 60 ] && break
  sleep 1
done
trap 'rmdir "$LOCK" 2>/dev/null || true' EXIT

SRC_V="$(tr -d '[:space:]' < "$SRC/VERSION" 2>/dev/null)"
DST_V=""
[ -f "$DEST/VERSION" ] && DST_V="$(tr -d '[:space:]' < "$DEST/VERSION")"

STATUS=ok
if [ -z "$DST_V" ]; then
  STATUS=installed
elif [ "$DST_V" != "$SRC_V" ]; then
  STATUS=upgraded
fi

if [ "$STATUS" != "ok" ]; then
  mkdir -p "$DEST"
  rm -rf "$DEST/hooks"
  cp -R "$SRC/hooks" "$DEST/hooks"
  cp "$SRC/summarizer.js" "$DEST/summarizer.js"
  cp "$SRC/VERSION" "$DEST/VERSION"
  mkdir -p "$DEST/state"

  # Restart the daemon after a version change so the new code takes effect
  pkill -f "$DEST/summarizer.js" 2>/dev/null || true
  sleep 1
fi

# Backfill hook entries on every run: the claude config may have been reset or moved,
# or the monitor VERSION may be unchanged while our settings entry is missing.
# Entries pointing at an older monitor location are pruned, so moving the monitor
# (e.g. after a rename) never leaves dead hooks behind that silently swallow events.
# When CLAUDE_CONFIG_DIR points elsewhere (e.g. ds_claude.sh), merge there instead of ~/.claude.
if [ -f "$HOME/workspace/ds_claude.sh" ]; then
  . "$HOME/workspace/ds_claude.sh" 2>/dev/null || true
fi
CLAUDE_SETTINGS="${CLAUDE_CONFIG_DIR:-$HOME/.claude}/settings.json"
CODE_HOOKS="$HOME/.codex/hooks.json"
mkdir -p "$(dirname "$CLAUDE_SETTINGS")" "$(dirname "$CODE_HOOKS")"
if [ -d "$SRC/hooks" ]; then
  python3 - "$DEST" "$SRC/config" "$CLAUDE_SETTINGS" "$CODE_HOOKS" <<'PY'
import json, sys

dest, cfgdir, claude_path, codex_path = sys.argv[1:]

def load(p):
    try:
        with open(p, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}

def entry_hooks(g):
    return (g.get('hooks') or []) if isinstance(g, dict) else []

def refs(hs, needle):
    return any(isinstance(h, dict) and needle in str(h.get('command', ''))
               for h in hs)

def merge(target, src_hooks):
    cfg = load(target)
    hooks = cfg.setdefault('hooks', {})
    for ev, groups in (src_hooks or {}).items():
        arr = hooks.setdefault(ev, [])
        # Drop our entries left at an older monitor location (e.g. before the monitor
        # was moved): they point at files that no longer exist and would silently
        # swallow events. Other hooks are never touched.
        arr[:] = [g for g in arr
                  if not (refs(entry_hooks(g), '/monitor/hooks/')
                          and not refs(entry_hooks(g), dest + '/hooks/'))]
        # Install the current-path entries when they are missing.
        if not any(refs(entry_hooks(g), dest + '/hooks/') for g in arr):
            for g in groups:
                if isinstance(g, dict):
                    arr.append(g)
    with open(target, 'w', encoding='utf-8') as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
        f.write('\n')

claude_src = load(cfgdir + '/claude-hooks.json')
codex_src = load(cfgdir + '/codex-hooks.json')
merge(claude_path, claude_src.get('hooks'))
merge(codex_path, codex_src.get('hooks'))
PY
fi

# Diagnostics: the plugin page parses STATUS/VERSION only; extra lines are for debugging
if grep -q '/monitor/hooks/claude/' "$CLAUDE_SETTINGS" 2>/dev/null; then
  echo "MONITOR_CLAUDE_HOOK=yes"
else
  echo "MONITOR_CLAUDE_HOOK=no"
fi
if grep -q '/monitor/hooks/codex/' "$CODE_HOOKS" 2>/dev/null; then
  echo "MONITOR_CODEX_HOOK=yes"
else
  echo "MONITOR_CODEX_HOOK=no"
fi

# Keep the daemon alive (restart it when the version matches but the process is gone)
if ! pgrep -f "$DEST/summarizer.js" >/dev/null 2>&1; then
  [ -f "$HOME/workspace/ds_claude.sh" ] && . "$HOME/workspace/ds_claude.sh" 2>/dev/null || true
  setsid env WHIP_STATE_DIR="$DEST/state" \
    node "$DEST/summarizer.js" >> "$DEST/summarizer.log" 2>&1 < /dev/null &
  sleep 1
fi

echo "MONITOR_STATUS=$STATUS"
echo "MONITOR_VERSION=$SRC_V"
echo "MONITOR_DEST=$DEST"

# Setup contract: exit 0 only when the host runtime is actually in place, so the
# installer can report a failed setup instead of caching a broken state.
if [ ! -f "$DEST/summarizer.js" ] || [ ! -f "$DEST/VERSION" ]; then
  echo "MONITOR_STATUS=error"
  echo "setup failed: monitor files missing in $DEST" >&2
  exit 1
fi
if ! grep -q '/monitor/hooks/claude/' "$CLAUDE_SETTINGS" 2>/dev/null; then
  echo "MONITOR_STATUS=error"
  echo "setup failed: claude hooks not registered in $CLAUDE_SETTINGS" >&2
  exit 1
fi
exit 0
