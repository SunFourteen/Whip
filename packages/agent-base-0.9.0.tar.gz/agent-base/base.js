/* Whip Base - headless shared core (third plugin).
 * Both agent plugins load this file via <script src="../agent-base/base.js">. It provides
 * ps liveness, shell-to-tty matching, action decisions, naming, resume markers and the
 * shared state appearance (STATE_UI: label/tag/color). Single source of truth. */
(function () {
  'use strict';

  var NAME_PREFIX = 'whip_name_v1_';
  var LIVE_KEY = 'whip_live_v1';
  var LAST_KEY = 'whip_last_v1';
  var ARCH_KEY = 'whip_archived_v1';
  var MARK_MS = 20000;
  var procMap = {};
  var procTty = {};
  var procTs = 0;

  function esc2(s) { return String(s == null ? '' : s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
  function shq2(s) { return "'" + String(s == null ? '' : s).replace(/'/g, "'\\''") + "'"; }
  function dbg() {
    try {
      console.log.apply(console,
        ['[base]'].concat(Array.prototype.slice.call(arguments)));
    } catch (e) {}
  }

  function nameKey(row) {
    return NAME_PREFIX + String(row && row.agent || '') + '_'
      + String(row && row.sessionId || '');
  }
  function nameOf(row) {
    try {
      var v = SshBridge.prefsGet(nameKey(row));
      if (v && String(v).trim()) return String(v).trim();
    } catch (e) {}
    return (row && row.agent) || 'agent';
  }
  function setName(row, value) {
    try {
      SshBridge.prefsSet(nameKey(row), value == null ? '' : String(value).trim());
    } catch (e) {}
  }

  function mark(row, kind) {
    if (!row || !row.sessionId) return;
    try {
      var m = {};
      try { m = JSON.parse(SshBridge.prefsGet(LIVE_KEY) || '{}') || {}; } catch (e) {}
      m[row.sessionId] = { agent: row.agent, ts: Date.now(), kind: kind || 'resume' };
      SshBridge.prefsSet(LIVE_KEY, JSON.stringify(m));
    } catch (e) {}
  }
  function marked(row) {
    if (!row || !row.sessionId) return null;
    try {
      var m = JSON.parse(SshBridge.prefsGet(LIVE_KEY) || '{}') || {};
      var e = m[row.sessionId];
      if (e && e.agent === row.agent && Date.now() - e.ts < MARK_MS) return e;
    } catch (e) {}
    return null;
  }
  function markedAll() {
    var out = {};
    try {
      var m = JSON.parse(SshBridge.prefsGet(LIVE_KEY) || '{}') || {};
      Object.keys(m).forEach(function (sid) {
        var e = m[sid];
        if (e && Date.now() - e.ts < MARK_MS) out[sid] = e;
      });
    } catch (e) {}
    return out;
  }

  function lastMap() {
    try {
      var m = JSON.parse(SshBridge.prefsGet(LAST_KEY) || '{}') || {};
      return m;
    } catch (e) { return {}; }
  }
  function archKey2(agent, sid) {
    return String(agent == null ? 'unknown' : agent) + '\u0001' + String(sid == null ? '' : sid);
  }
  function archList() {
    try { return JSON.parse(SshBridge.prefsGet(ARCH_KEY) || '[]') || []; }
    catch (e) { return []; }
  }
  function archSave(list) {
    try { SshBridge.prefsSet(ARCH_KEY, JSON.stringify(list)); } catch (e) {}
  }
  function archAdd2(agent, sid) {
    var a = archList();
    var k = archKey2(agent, sid);
    if (a.indexOf(k) < 0) { a.push(k); archSave(a); }
  }
  function archRemove2(agent, sid) {
    var k = archKey2(agent, sid);
    archSave(archList().filter(function (x) { return x !== k; }));
  }
  function archClear2() { archSave([]); }
  function touchLast(agent, sid, ts) {
    try {
      var m = lastMap();
      var k = sid;
      var old = m[k] || {};
      if (!old.agent || old.agent === agent || (old.ts || 0) < (ts || Date.now())) {
        m[k] = { agent: agent, ts: ts || Date.now() };
        SshBridge.prefsSet(LAST_KEY, JSON.stringify(m));
      }
    } catch (e) {}
  }

  /* ── Full session state machine shared by the agent plugins ──
   * Per session: sessionId / name (editable) / lastActiveMs / isActive /
   * currentShell / state(working|done|interrupted|requirePermission)
   * + details(tool/action/result/message/workspace/tty/events)。
   * The only terminal state is done: round_end and session_end both land there. idle was
   * dropped because two terminal states only made Monitor and Summarizer disagree. */
  var STATES = {
    working: 'working',
    done: 'done',
    interrupted: 'interrupted',
    requirePermission: 'requirePermission'
  };
  /* Shared state appearance: both plugins and all their modes (phone / square / round /
   * wearable fallback) read label/tag/color here instead of keeping their own maps. */
  var STATE_UI = {
    working:          { label: 'working', tag: 'work', color: '#d4aa00' },
    done:             { label: 'done', tag: 'done', color: '#00D4AA' },
    interrupted:      { label: 'interrupted', tag: 'int', color: '#888888' },
    requirePermission: { label: 'requirePermission', tag: 'wait',
      color: '#d4004a' }
  };
  function stateUI(st) {
    var key = (st === 'idle') ? 'done' : st; // legacy idle maps to done
    return STATE_UI[key] || {
      label: String(st == null ? 'unknown' : st),
      tag: '?', color: '#888888'
    };
  }
  var EV_STATE = {
    task_start: 'working',
    tool_start: 'working',
    tool_end: 'working',
    tool_fail: 'working',
    subagent_end: 'working',
    round_end: 'done',
    session_end: 'done',
    needs_approval: 'requirePermission',
    interrupted: 'interrupted',
    interrupt: 'interrupted',
    error: 'interrupted',
    cancel: 'interrupted'
  };
  /* Card live.state -> session state, matching the event mapping. Summarizer only reads
   * the card stream, so without this mapping it would show working where Monitor shows
   * requirePermission. */
  var LIVE_STATE = {
    round_done: 'done',
    needs_approval: 'requirePermission',
    interrupted: 'interrupted'
  };
  function stateOfLive(liveState) {
    return LIVE_STATE[liveState] || STATES.working;
  }

  function newRec(agent, sid) {
    return {
      sessionId: sid,
      agent: agent,
      name: nameOf({ agent: agent, sessionId: sid }),
      lastActiveMs: 0,
      isActive: false,
      shellId: '',
      key: '',
      raw: null,
      fullRaw: false,
      // No status information yet: default to the terminal state done
      state: STATES.done,
      details: {
        tool: '', action: '', result: '', message: '', summary: null,
        workspace: '', tty: '', events: [],
        // Agent Monitor renders every available field; Agent Summarizer reads summary only
        status: '', liveState: '', startedAt: 0, lastActiveAt: 0,
        cardVersion: 0, steps: []
      },
      seq: 0
    };
  }

  var Sessions = {
    recs: {},
    ensure: function (agent, sid) {
      if (agent == null || sid == null) return null;
      var k = String(sid);
      var r = this.recs[k];
      if (!r) {
        r = newRec(String(agent), k);
        this.recs[k] = r;
      }
      return r;
    },
    ingestEvent: function (line, live) {
      var ev = line;
      if (typeof line === 'string') {
        try { ev = JSON.parse(line); } catch (e) { return null; }
      }
      if (!ev || !ev.sessionId) {
        dbg('event drop: no sessionId', ev && ev.kind, ev && ev.agent);
        return null;
      }
      // Only workspace sessions are tracked: a new session needs a shell tty; events
      // without a tty may still update a known session (never overwriting its tty).
      var evKey = String(ev.sessionId);
      if (!ev.tty && !this.recs[evKey]) {
        dbg('event drop: no-tty unknown session', ev.agent, ev.sessionId,
          ev.kind, 'live=' + (live ? 1 : 0));
        return null;
      }
      // Same as the container summarizer: session_end only marks an end and never creates
      // a record for an unknown session.
      if (ev.kind === 'session_end' && !this.recs[evKey]) {
        dbg('event drop: session_end without known session', ev.agent,
          ev.sessionId);
        return null;
      }
      var isNew = !this.recs[evKey];
      var r = this.ensure(ev.agent || 'unknown', ev.sessionId);
      if (isNew) {
        dbg('event new session', r.agent, r.sessionId, 'tty=' + (ev.tty || '-'),
          'kind=' + ev.kind, 'live=' + (live ? 1 : 0));
      }
      var st = EV_STATE[ev.kind];
      if (ev.kind === 'tool_start' && ev.approval) st = STATES.requirePermission;
      if (st) r.state = st;
      var d = r.details;
      if (ev.cwd) d.workspace = String(ev.cwd);
      if (ev.tty) d.tty = String(ev.tty);
      if (ev.ts) r.lastActiveMs = Number(ev.ts);
      else if (live) r.lastActiveMs = Date.now();
      if (live) touchLast(r.agent, r.sessionId, r.lastActiveMs);
      var tool = ev.tool || {};
      var result = ev.result || {};
      var toolName = tool.name || '';
      if (ev.kind === 'task_start') {
        d.tool = ''; d.action = ''; d.result = '';
        d.message = 'task: ' + String(ev.prompt || '');
      } else if (ev.kind === 'tool_start') {
        d.tool = toolName; d.action = tool.inputSummary || '';
        d.result = '';
        if (ev.approval) d.message = 'approval: ' + String(ev.approval);
      } else if (ev.kind === 'tool_end') {
        d.tool = toolName;
        d.result = result.display || '';
        if (result.durationMs != null) d.result += ' (' + result.durationMs + 'ms)';
      } else if (ev.kind === 'tool_fail') {
        d.tool = toolName;
        d.result = 'FAILED: ' + String(result.error || '');
      } else if (ev.kind === 'round_end') {
        d.message = String(ev.message || '');
      } else if (ev.kind === 'session_end') {
        d.tool = ''; d.action = ''; d.result = '';
        d.message = ev.message ? String(ev.message) : 'session ended';
      } else if (ev.message && (ev.kind === 'interrupted' || ev.kind === 'error'
          || ev.kind === 'needs_approval')) {
        d.message = String(ev.message);
      }
      d.events.push({ t: Date.now(), kind: ev.kind,
        text: String(ev.message || ev.kind) });
      if (d.events.length > 24) d.events.shift();
      r.seq++;
      return r;
    },
    mergeCard: function (card, full) {
      if (!card || !card.sessionId) return null;
      // Same as events: unknown cards without a tty never enter the state machine
      var cardKey = String(card.sessionId);
      if (!card.tty && !this.recs[cardKey]) {
        dbg('card drop: no-tty unknown session', card.agent, card.sessionId,
          'status=' + card.status, 'full=' + (full ? 1 : 0));
        return null;
      }
      var isNew = !this.recs[cardKey];
      var r = this.ensure(card.agent || 'unknown', card.sessionId);
      if (isNew) {
        dbg('card new session', r.agent, r.sessionId, 'tty=' + (card.tty || '-'),
          'status=' + card.status, 'full=' + (full ? 1 : 0));
      }
      var running = card.status === 'running';
      var liveState = (card.live && card.live.state) || '';
      // Same mapping as events: round_done -> done (waiting for the user, not autonomous),
      // needs_approval -> requirePermission, interrupted -> interrupted; everything else
      // is done.
      r.state = running ? stateOfLive(liveState) : STATES.done;
      var d = r.details;
      if (card.workspace) d.workspace = String(card.workspace);
      if (card.tty) d.tty = String(card.tty);
      if (card.updatedAt) {
        r.lastActiveMs = Math.max(r.lastActiveMs || 0, Number(card.updatedAt) || 0);
        touchLast(r.agent, r.sessionId, r.lastActiveMs);
      }
      // The LLM summary is stored separately: d.message keeps the live text, the summary
      // goes to d.summary, so one never overwrites the other.
      if (card.semantic && (card.semantic.headline || card.semantic.next
          || (card.semantic.outcome || []).length
          || (card.semantic.process || []).length)) {
        var sm = card.semantic;
        d.summary = {
          headline: String(sm.headline || ''),
          outcome: (sm.outcome || []).slice(0, 4).map(String),
          process: (sm.process || []).slice(0, 4).map(String),
          next: String(sm.next || ''),
          toolCalls: Number(sm.toolCalls || 0),
          updatedAt: Number(sm.updatedAt || 0)
        };
      }
      if (card.live && card.live.message) d.message = String(card.live.message);
      if (card.result) d.result = String(card.result);
      if (card.live) {
        var lv = card.live;
        if (lv.tool) d.tool = String(lv.tool);
        if (lv.action) d.action = String(lv.action);
      }
      if (card.direct && card.direct.result) d.result = String(card.direct.result);
      if (card.counts) {
        d.rounds = (card.counts.rounds || 0);
        d.tools = (card.counts.toolCalls || 0);
        d.subs = (card.counts.subagentStops || 0);
      }
      // Mirror every available card field into details so Monitor renders it directly
      // instead of relying on the partial index entry in raw.
      if (card.status) d.status = String(card.status);
      if (card.live && card.live.state) d.liveState = String(card.live.state);
      if (card.startedAt) d.startedAt = Number(card.startedAt);
      if (card.lastActiveAt) d.lastActiveAt = Number(card.lastActiveAt);
      if (card.version) d.cardVersion = Number(card.version);
      if (full && card.direct && card.direct.steps && card.direct.steps.length) {
        d.steps = card.direct.steps.slice(-12).map(function (st) {
          return {
            tool: String(st.tool || ''),
            action: String(st.action || ''),
            ok: st.ok !== false,
            result: String(st.result || ''),
            durationMs: st.durationMs == null ? null : Number(st.durationMs),
            t: Number(st.t || 0)
          };
        });
      }
      if (card.key) r.key = String(card.key);
      // full=true means a complete card from cards/<key>.json / cards.ndjson; a partial
      // index entry is only used as a placeholder raw when no full card exists.
      if (full) { r.raw = card; r.fullRaw = true; }
      else if (!r.raw) { r.raw = card; r.fullRaw = false; }
      return r;
    },
    rename: function (agent, sid, value) {
      setName({ agent: agent, sessionId: sid }, value);
      var r = this.recs[String(sid)];
      if (r) r.name = nameOf({ agent: agent, sessionId: sid });
    },
    setShell: function (agent, sid, shellId) {
      var r = this.ensure(agent, sid);
      r.shellId = shellId || '';
      if (shellId) r.lastActiveMs = Date.now();
      return r;
    },
    /* The single liveness entry point: ps collection, real tty write-back, shell matching
     * and isActive are computed here and only triggered by rows()/list(). Even a detail
     * page must call Driver.rows() every tick, otherwise isActive/tty never refresh and a
     * restored session cannot find its new shell. */
    resolve: function () {
      refreshProcs(false);
      var shells = shellMap();
      var marks = markedAll();
      var last = lastMap();
      var agentTtys = {};
      Object.keys(procTty).forEach(function (pt) {
        var a = procTty[pt];
        (agentTtys[a] = agentTtys[a] || []).push(pt);
      });
      // Several sessions may share one (agent, tty); the tty fallback revives only the
      // newest one so old history is not misattributed.
      var newestOnTty = {};
      var out = [];
      var self = this;
      Object.keys(this.recs).forEach(function (k) {
        var r = self.recs[k];
        var ps = procMap[k] || null;
        var d = r.details || {};
        var tt = (ps && ps.tty) || d.tty || '';
        // Records without a tty join the "newest session" decision through a candidate
        // tty when the agent has exactly one; old entries never steal a new process.
        if (!tt && !ps) {
          var at0 = agentTtys[String(r.agent || '')] || [];
          if (at0.length === 1) tt = at0[0];
        }
        if (!tt) return;
        if (!ps && procTty[tt] !== String(r.agent || '')) return;
        var gk = String(r.agent || 'unknown') + '\u0001' + tt;
        var cur = newestOnTty[gk];
        if (!cur || (r.lastActiveMs || 0) > (cur.lastActiveMs || 0)
            || ((r.lastActiveMs || 0) === (cur.lastActiveMs || 0)
              && (r.seq || 0) > (cur.seq || 0))) {
          newestOnTty[gk] = r;
        }
      });
      Object.keys(this.recs).forEach(function (k) {
        var r = self.recs[k];
        var ps = procMap[k] || null;
        var mark = marks[k] || null;
        var d = r.details || {};
        var baseTty = d.tty || '';
        var tty = (ps && ps.tty) || baseTty || '';
        var psLive = !!ps;
        if (!ps) {
          // A resident process without a sid (starting, thinking, waiting at the prompt):
          //  - the recorded tty already has this agent -> use it;
          //  - otherwise, when the agent has exactly one tty-level process, adopt the
          //    process's real tty.
          // Only the newest session on that (agent, tty) may be revived this way.
          var cands = agentTtys[String(r.agent || '')] || [];
          var owner = cands.indexOf(baseTty) >= 0;
          var single = cands.length === 1 && (!baseTty || !shells[baseTty]);
          if (owner || single) {
            var tt = owner ? baseTty : cands[0];
            var gk2 = String(r.agent || 'unknown') + '\u0001' + tt;
            if (newestOnTty[gk2] === r) {
              tty = tt;
              psLive = true;
            }
          }
        }
        // A live process means the session is focusable/resumable (isActive), not that it
        // is working: after round_end it stays done until the user replies.
        var stateLive = r.state === STATES.working
          || r.state === STATES.requirePermission;
        var sh = tty ? shells[tty] : null;
        var lastE = last[k] || {};
        var lastTs = Math.max(r.lastActiveMs || 0, Number(lastE.ts) || 0);
        if (lastTs) r.lastActiveMs = lastTs;
        r.isActive = psLive || !!mark
          || (stateLive && Date.now() - (r.lastActiveMs || 0) < 90000);
        // Write back the real tty so renderers match the shell instead of stale pts
        if (tty && (d.tty || '') !== tty) d.tty = tty;
        r.shellId = sh ? sh.id : (r.shellId || (psLive ? '' : ''));
        if (sh) r.shellId = sh.id;
        out.push(r);
      });
      out.sort(function (a, b) { return (b.lastActiveMs || 0) - (a.lastActiveMs || 0); });
      return out;
    },
    list: function () { return this.resolve(); },
    find: function (agent, sid) {
      var k = String(sid);
      return this.recs[k] || null;
    },
    reset: function () { this.recs = {}; }
    ,
    remove: function (agent, sid) {
      var r = this.recs[String(sid)];
      if (r && (agent == null || r.agent === String(agent))) {
        delete this.recs[String(sid)];
      }
    },
    isArchived: function (agent, sid) {
      return archList().indexOf(archKey2(agent, sid)) >= 0;
    },
    archive: function (agent, sid) {
      archAdd2(agent, sid);
      this.remove(agent, sid);
      dbg('archive', agent, sid);
    },
    unarchive: function (agent, sid) {
      archRemove2(agent, sid);
      dbg('unarchive', agent, sid);
      return this.ensure(agent, sid);
    },
    clearArchived: function () { archClear2(); },
    listArchived: function () {
      return archList().map(function (k) {
        var i = k.indexOf('\u0001');
        var agent = i < 0 ? 'unknown' : k.slice(0, i);
        var sid = i < 0 ? k : k.slice(i + 1);
        return { agent: agent, sessionId: sid, name: nameOf({ agent: agent, sessionId: sid }) };
      });
    }
  };

  function refreshProcs(force) {
    if (!force && Date.now() - procTs < 2000) return;
    procTs = Date.now();
    var r = null;
    try {
      r = JSON.parse(SshBridge.run('ps -eo tty=,args=',
        JSON.stringify({ timeoutMs: 3000 })));
    } catch (e) { return; }
    var m = {};
    var t = {};
    String(r && r.stdout || '').split('\n').forEach(function (ln) {
      ln = String(ln || '').trim();
      if (!ln) return;
      var sp = ln.indexOf(' ');
      if (sp <= 0) return;
      var tty = ln.slice(0, sp).trim();
      var args = ln.slice(sp + 1).trim();
      if (!/(codex|claude)/i.test(args)) return;
      var agent = /claude/i.test(args) ? 'claude' : 'codex';
      // Resident processes without a sid are also recorded by tty so resolve() can treat
      // the agent session on that shell as active.
      if (tty) t[tty] = t[tty] || agent;
      var sidM = /(?:^|\s)(?:--resume|resume)\s+([0-9a-fA-F-]{8,})/.exec(args)
        || /(?:--session|sessionId|session)[=:\s]+([0-9a-fA-F-]{8,})/.exec(args);
      if (!sidM) return;
      m[sidM[1]] = { agent: agent, tty: tty };
    });
    procMap = m;
    procTty = t;
  }

  function shellMap() {
    var m = {};
    try {
      var arr = JSON.parse(SshBridge.listShells() || '[]');
      (Array.isArray(arr) ? arr : []).forEach(function (sh) {
        if (sh && sh.tty) m[sh.tty] = sh;
      });
    } catch (e) {}
    return m;
  }

  function resolve(row) {
    var ps = procMap[row && row.sessionId] || null;
    var baseTty = (row && row.tty) || '';
    var tty = (ps && ps.tty) || baseTty || '';
    var stateLive = row && (row.state === STATES.working
      || row.state === STATES.requirePermission);
    var ttyLive = false;
    if (!ps && row && stateLive) {
      var cands = [];
      Object.keys(procTty).forEach(function (pt) {
        if (procTty[pt] === String(row.agent)) cands.push(pt);
      });
      if (cands.indexOf(baseTty) >= 0) { tty = baseTty; ttyLive = true; }
      else if (cands.length === 1 && !baseTty) { tty = cands[0]; ttyLive = true; }
    }
    var live = !!(row && (row.live === true || ps || ttyLive));
    var shells = shellMap();
    return {
      live: live, ps: ps, tty: tty, shells: shells,
      sh: tty ? shells[tty] : null,
      anyShell: Object.keys(shells).length > 0
    };
  }

  function act(row, hooks) {
    if (!row || !hooks) return 'none';
    refreshProcs(true);
    var r = resolve(row);
    var cmd = hooks.resumeCmd ? hooks.resumeCmd(row) : '';
    if (hooks.log) {
      hooks.log('[base-session] ' + row.agent + ' live=' + r.live
        + ' tty=' + (r.tty || '-') + ' shell=' + (r.sh ? r.sh.id : '-'));
    }
    if (r.sh && r.live) {
      mark(row, 'focus');
      if (hooks.focusShell) hooks.focusShell(r.sh.id);
      return 'focus';
    }
    if (row.workspace || cmd) {
      mark(row, 'resume');
      if (hooks.openShellWith) hooks.openShellWith(row.workspace || '', cmd);
      return 'resume';
    }
    if (r.anyShell) {
      mark(row, 'latest');
      if (hooks.focusLatest) hooks.focusLatest();
      return 'latest';
    }
    return 'none';
  }

  /* ================= Shared data driver =================
   * Shared by all modes (phone home/index, square, round):
   *  - cards.json index baseline (same for both plugins)
   *  - agent.ndjson live event feed (agent plugin)
   *  - cards.ndjson index/card stream (agent-summarizer plugin)
   *  - monitor self-check/install and ps liveness
   * Pages only render and forward intent; state lives in Sessions(Agents). */

  var DEFAULT_MONITOR_IDS = ['agent-base', 'agent-monitor', 'agent-summarizer'];

  function _runCmd(cmd, timeoutMs) {
    try {
      var r = JSON.parse(SshBridge.run(cmd,
        JSON.stringify({ timeoutMs: timeoutMs || 15000 })) || '{}');
      return r && r.ok ? (r.stdout || '') : '';
    } catch (e) { return ''; }
  }
  function _connNow() {
    try { return !!SshBridge.isConnected(); } catch (e) { return false; }
  }
  function resumeCmdOf(agent, sid) {
    agent = String(agent == null ? '' : agent);
    sid = String(sid == null ? '' : sid);
    if (agent === 'claude') return 'claude --resume ' + shq2(sid);
    if (agent === 'codex') return 'codex resume ' + shq2(sid);
    return '';
  }
  function _prefGet(key) {
    try { return SshBridge.prefsGet(key) || ''; } catch (e) { return ''; }
  }
  function _legacyArchList(key) {
    var raw = _prefGet(key);
    try {
      var ls = localStorage.getItem(key);
      if (ls && (!raw || ls.length > raw.length)) raw = ls;
    } catch (e) {}
    if (!raw) return [];
    try { var p = JSON.parse(raw); return Array.isArray(p) ? p : []; }
    catch (e) { return []; }
  }
  function _legacyB64urlEncode(str) {
    try {
      return btoa(unescape(encodeURIComponent(String(str))))
        .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    } catch (e) { return ''; }
  }
  function _legacyB64urlDecode(s) {
    try {
      return decodeURIComponent(escape(atob(String(s).replace(/-/g, '+').replace(/_/g, '/'))));
    } catch (e) { return ''; }
  }
  function _legacyRemoveFor(agent, sid) {
    var key = 'summ_archived_v1';
    var needle = String(agent == null ? 'unknown' : agent) + '~'
      + String(sid == null ? '' : sid);
    var next = _legacyArchList(key).filter(function (x) {
      if (x === needle) return false;
      var dec = _legacyB64urlDecode(x);
      return dec !== needle;
    });
    try { SshBridge.prefsSet(key, JSON.stringify(next)); } catch (e) {}
    try { localStorage.setItem(key, JSON.stringify(next)); } catch (e) {}
  }
  function _legacyArchRemove(key, val) {
    var a = _legacyArchList(key).filter(function (x) { return x !== val; });
    try {
      SshBridge.prefsSet(key, JSON.stringify(a));
    } catch (e) {}
    try { localStorage.setItem(key, JSON.stringify(a)); } catch (e) {}
  }
  function _dirOf(path) {
    if (!path) return '';
    var i = path.lastIndexOf('/');
    return i > 0 ? path.slice(0, i) : '';
  }

  var Driver = {
    cfg: null,
    booted: false,
    booting: false,
    feedOn: false,
    feedVer: -1,
    lastConn: null,
    lastIndexFp: '',
    monitorDone: false,
    monitorText: '',
    focusAt: 0,

    start: function (cfg) {
      this.stop();
      this.cfg = cfg || {};
      dbg('driver start', JSON.stringify({
        cardsPath: cfg && cfg.cardsPath,
        livePath: cfg && cfg.livePath,
        streamPath: cfg && cfg.streamPath,
        feedId: cfg && cfg.feedId,
        backlog: cfg && cfg.backlog,
        focus: cfg && cfg.focus,
        legacyArchKey: cfg && cfg.legacyArchKey
      }));
      this.booted = false;
      this.booting = false;
      this.feedOn = false;
      this.feedVer = -1;
      this.lastIndexFp = '';
      this.monitorDone = false;
      this.monitorText = '';
      this.focusAt = 0;
      this.lastConn = _connNow();
      Sessions.reset();
      this._status('');
    },
    stop: function () {
      if (this.feedOn && this.cfg && this.cfg.feedId) {
        try { SshBridge.removeFeed(this.cfg.feedId); } catch (e) {}
      }
      this.feedOn = false;
      this.feedVer = -1;
      this.booted = false;
      this.booting = false;
    },
    conn: function () { return _connNow(); },
    _status: function (msg) {
      this.monitorText = String(msg == null ? '' : msg);
      if (this.cfg && this.cfg.onStatus) {
        try { this.cfg.onStatus(this.monitorText); } catch (e) {}
      }
    },

    tick: function () {
      if (!this.cfg) return;
      var on = _connNow();
      if (on !== this.lastConn) {
        this.lastConn = on;
        if (!on) {
          this.stop();
          Sessions.reset();
          this._status('');
          return;
        }
      }
      if (!on) return;
      if (!this.booted) { this._boot(); return; }
      if (this.cfg.livePath || this.cfg.streamPath) {
        this._ensureFeed();
        if (this.feedOn) this._poll();
      }
    },

    _boot: function () {
      if (this.booting) return;
      this.booting = true;
      Sessions.reset();
      this._loadIndex();
      if (this.cfg.livePath) this._tailLive();
      this.feedOn = false;
      this.feedVer = -1;
      this.lastIndexFp = '';
      if (this.cfg.livePath || this.cfg.streamPath) this._ensureFeed();
      if (!this.monitorDone && this.cfg.monitorIds) {
        var self = this;
        setTimeout(function () { self._checkMonitor(); }, 1200);
      }
      this.booting = false;
      this.booted = true;
    },

    _loadIndex: function () {
      if (!this.cfg.cardsPath) return;
      var out = _runCmd('cat ' + shq2(this.cfg.cardsPath)
        + ' 2>/dev/null || echo "{}"', 15000);
      var idx = null;
      try { idx = JSON.parse(out || '{}'); } catch (e) { return; }
      this._ingestIndex(idx);
    },

    _ingestIndex: function (idx) {
      if (!idx) return;
      var arr = (idx && idx.sessions) || [];
      dbg('index baseline: sessions=' + arr.length,
        'agent=' + (idx.agent || '-'), 'status=' + (idx.status || '-'));
      var self = this;
      arr.forEach(function (c) { self._mergeAny(c, false); });
    },

    _mergeAny: function (c, full) {
      if (!c || !c.sessionId) return;
      if (this.cfg.legacyArchKey && c.key) {
        if (_legacyArchList(this.cfg.legacyArchKey).indexOf(c.key) >= 0
            && !Sessions.isArchived(c.agent, c.sessionId)) {
          dbg('legacy archive migrate', c.agent, c.sessionId, c.key);
          Sessions.archive(c.agent, c.sessionId);
          return;
        }
      }
      Sessions.mergeCard(c, full === true);
    },

    _tailLive: function () {
      if (!this.cfg.livePath) return;
      var out = _runCmd('tail -n 50 -- ' + shq2(this.cfg.livePath)
        + ' 2>/dev/null', 15000);
      var n = 0;
      String(out || '').split('\n').forEach(function (l) {
        l = String(l || '').trim();
        if (l) { n++; Sessions.ingestEvent(l, false); }
      });
      if (n > 0) dbg('boot tail live: lines=' + n);
    },

    _ensureFeed: function () {
      if (this.feedOn) return;
      var path = this.cfg.livePath || this.cfg.streamPath;
      if (!path || !this.cfg.feedId) return;
      try {
        if (SshBridge.feedVersion(this.cfg.feedId) >= 0) {
          SshBridge.removeFeed(this.cfg.feedId);
        }
      } catch (e) {}
      var r = null;
      try {
        r = JSON.parse(SshBridge.createFeed(this.cfg.feedId, JSON.stringify({
          type: 'file-lines', path: path, framing: 'json-line'
        })));
      } catch (e) { r = { ok: false, error: 'bridge' }; }
      if (!r || !r.ok) {
        dbg('feed create error', this.cfg.feedId, path,
          r && r.error ? r.error : 'unknown');
        this._status('feed error: ' + ((r && r.error) || 'unknown'));
        return;
      }
      this.feedOn = true;
      this.feedVer = -1;
      dbg('feed created', this.cfg.feedId, path);
      this._status('');
    },

    _poll: function () {
      if (!this.cfg.feedId) return;
      var v = -1;
      try { v = SshBridge.feedVersion(this.cfg.feedId); } catch (e) { return; }
      if (v < 0) { this.feedOn = false; return; }
      var from = this.feedVer < 0
        ? Math.max(0, v - (this.cfg.backlog || 30)) : this.feedVer;
      var rr = null;
      try { rr = JSON.parse(SshBridge.feedRead(this.cfg.feedId, from)); }
      catch (e) { return; }
      this.feedVer = rr.nextVersion;
      if ((rr.records || []).length > 0) {
        dbg('feed read', this.cfg.feedId, 'from=' + from,
          'next=' + rr.nextVersion, 'records=' + (rr.records || []).length);
      }
      var self = this;
      (rr.records || []).forEach(function (rec) { self._onRecord(rec); });
    },

    _onRecord: function (rec) {
      var text = String(rec == null ? '' : rec);
      if (!text) return;
      if (this.cfg.livePath) {
        var ev = null;
        try { ev = JSON.parse(text.trim()); } catch (e) { return; }
        if (ev) Sessions.ingestEvent(ev, true);
        return;
      }
      if (!this.cfg.streamPath) return;
      var env = null;
      try { env = JSON.parse(text); } catch (e) { return; }
      if (!env) return;
      if (env.type === 'index') {
        var idx = env.index || {};
        var fp = JSON.stringify(idx);
        if (fp === this.lastIndexFp) return;
        this.lastIndexFp = fp;
        this._ingestIndex(idx);
      } else if (env.type === 'card' && env.card && env.key) {
        var f = this.cfg.focus;
        if (!f || !f.requireRaw) return;
        if ((!f.agent || String(f.agent) === String(env.card.agent || ''))
            && String(f.sessionId) === String(env.card.sessionId || '')) {
          this._mergeAny(env.card, true);
        }
      }
    },

    /* Detail page: merge the target session's full card (cards/<key>.json) */
    loadCard: function (agent, sid, key) {
      if (!this.cfg.cardsPath) return null;
      var dir = _dirOf(this.cfg.cardsPath);
      var out = _runCmd('cat ' + shq2(this.cfg.cardsPath)
        + ' 2>/dev/null || echo "{}"', 15000);
      var idx = null;
      try { idx = JSON.parse(out || '{}'); } catch (e) {}
      var hit = null;
      var arr = (idx && idx.sessions) || [];
      for (var i = 0; i < arr.length; i++) {
        var it = arr[i];
        if (!it) continue;
        if (key && it.key === key) { hit = it; break; }
        if (!key && String(it.agent || '') === String(agent || '')
            && String(it.sessionId || '') === String(sid || '')) { hit = it; break; }
      }
      if (!hit || !hit.key) return Sessions.find(agent, sid) || null;
      var full = _runCmd('cat ' + shq2(dir + '/cards/' + hit.key + '.json')
        + ' 2>/dev/null || echo "{}"', 15000);
      var card = null;
      try { card = JSON.parse(full || '{}'); } catch (e) { return null; }
      if (!card || !card.sessionId) return Sessions.find(agent, sid) || null;
      this._mergeAny(card, true);
      return Sessions.find(card.agent || hit.agent, card.sessionId || hit.sessionId) || null;
    },

    /* Resolve the target session for a detail page; requireRaw also merges the full card */
    ensureFocus: function (requireRaw) {
      var f = this.cfg.focus;
      if (!f) return null;
      var r = Sessions.find(f.agent, f.sessionId);
      var need = requireRaw === true || f.requireRaw === true;
      if (r && !need) return r;
      if (r && r.fullRaw) return r;
      var now = Date.now();
      if (now - this.focusAt < 2000) return r || null;
      this.focusAt = now;
      var rr = this.loadCard(f.agent, f.sessionId, f.key);
      return rr || r || null;
    },

    rows: function () {
      var out = Sessions.list();
      var self = this;
      var vis = out.filter(function (r) {
        return !Sessions.isArchived(r.agent, r.sessionId);
      });
      var arch = 0;
      Object.keys(Sessions.recs).forEach(function (k) {
        var r = Sessions.recs[k];
        if (Sessions.isArchived(r.agent, r.sessionId)) arch++;
      });
      var fpLog = vis.length + '/' + out.length + '/' + arch;
      if (fpLog !== this._rowLogFp) {
        this._rowLogFp = fpLog;
        dbg('rows visible/total/archived=' + fpLog,
          vis.map(function (r) {
            return r.agent + ':' + String(r.sessionId).slice(0, 8)
              + ':' + (r.state || '?') + (r.isActive ? '+' : '');
          }).join(','));
      }
      return vis;
    },

    unarchive: function (agent, sid, key) {
      var r = Sessions.unarchive(agent, sid);
      if (this.cfg.legacyArchKey && key) {
        _legacyArchRemove(this.cfg.legacyArchKey, key);
      }
      // Undoing from either plugin also clears the legacy summarizer keyed archive
      _legacyRemoveFor(agent, sid);
      return r;
    },

    clearArchived: function () {
      Sessions.clearArchived();
      try { SshBridge.prefsSet('summ_archived_v1', '[]'); } catch (e) {}
      try { localStorage.setItem('summ_archived_v1', '[]'); } catch (e) {}
    },

    _checkMonitor: function () {
      if (this.monitorDone || !this.cfg || !this.cfg.monitorIds) return;
      this.monitorDone = true;
      var ids = this.cfg.monitorIds || DEFAULT_MONITOR_IDS;
      dbg('monitor check: ids=', ids);
      // The installer owns host-side setup (manifest "setup"); the page only asks for
      // it and renders the outcome, so no plugin has to know install paths or scripts.
      var out = null;
      for (var i = 0; i < ids.length; i++) {
        var st = null;
        try { st = JSON.parse(SshBridge.pluginSetup(ids[i]) || '{}'); } catch (e) { st = null; }
        if (st && st.ok) { out = st; break; }
        if (st && st.state === 'none') { out = st; break; }
      }
      if (!out) { this._status('monitor setup failed'); return; }
      if (out.state === 'ok') this._status('monitor v' + out.version + ' ok');
      else this._status('monitor: ' + (out.message || out.state));
    }
  };

  function actRow(rec) {
    if (!rec) return null;
    return {
      agent: rec.agent,
      sessionId: rec.sessionId,
      state: rec.state,
      workspace: (rec.details && rec.details.workspace) || '',
      tty: (rec.details && rec.details.tty) || '',
      live: !!rec.isActive
    };
  }
  function shellHooks() {
    return {
      resumeCmd: function (row) {
        return resumeCmdOf(row && row.agent, row && row.sessionId);
      },
      focusShell: function (id) {
        try { SshBridge.openTerminalShell(id); } catch (e) {}
      },
      focusLatest: function () {
        try { SshBridge.openTerminalShell(''); } catch (e) {}
      },
      openShellWith: function (c, cmd) {
        try { SshBridge.openShellWith(c || '', cmd || ''); } catch (e) {}
      },
      log: function (msg) { try { console.log(msg); } catch (e) {} }
    };
  }

  var VmSessionCore = {
    refreshProcs: refreshProcs,
    resolve: resolve,
    act: act,
    actRow: actRow,
    shellHooks: shellHooks,
    map: function () { return procMap; },
    shellMap: shellMap,
    nameOf: nameOf,
    setName: setName,
    mark: mark,
    marked: marked,
    markedAll: markedAll,
    Agents: Sessions,
    STATES: STATES,
    STATE_UI: STATE_UI,
    stateUI: stateUI,
    touchLast: touchLast,
    resumeCmd: resumeCmdOf,
    Driver: Driver,
    shq: shq2,
    esc: esc2
  };
  window.VmSessionCore = VmSessionCore;
  window.WhipBase = VmSessionCore;
})();
