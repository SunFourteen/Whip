'use strict';

/* Agent Summarizer - phone detail renderer. ?key= opens that full card
 * (cards/<key>.json), ?agent=&session= also works; the card is merged into base Agents
 * (raw included) and then updated live from the cards.ndjson card stream. */

var BASE = (typeof WhipBase !== 'undefined') ? WhipBase : null;
var Driver = BASE ? BASE.Driver : null;
var Agents = BASE ? BASE.Agents : null;

function $(id) { return document.getElementById(id); }
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
function cap(s, n) {
  s = String(s == null ? '' : s);
  return s.length > n ? s.slice(0, n) + '…' : s;
}
function fmtAgo(ms) {
  if (!ms) return '';
  var s = Math.max(0, Math.floor((Date.now() - ms) / 1000));
  if (s < 60) return s + 's ago';
  var m = Math.floor(s / 60);
  if (m < 60) return m + 'm ' + (s % 60) + 's ago';
  return Math.floor(m / 60) + 'h ' + (m % 60) + 'm ago';
}
function fmtId(sid) {
  sid = String(sid || '');
  return sid.length > 14 ? sid.slice(0, 14) + '…' : sid;
}

var CARD_PATH = '/root/.whip/monitor/state/cards.json';
var STREAM_PATH = '/root/.whip/monitor/state/cards.ndjson';
var FEED_ID = 'summ-detail-stream';

var q = (function () {
  try {
    var u = new URLSearchParams(location.search);
    return {
      key: u.get('key') || '',
      agent: u.get('agent') || '',
      session: u.get('session') || '',
      rename: u.get('rename') === '1'
    };
  } catch (e) { return { key: '', agent: '', session: '', rename: false }; }
})();

var known = { agent: q.agent || '', sid: q.session || '' };
var lastFp = '';
var statusText = '';

function startDriver() {
  if (!Driver) return;
  var focus = null;
  // Same as monitor: locate by agent+sessionId, key is only a fallback
  if (known.sid) {
    focus = { agent: known.agent, sessionId: known.sid,
      key: q.key || '', requireRaw: true };
  } else if (q.key) {
    focus = { key: q.key, requireRaw: true };
  }
  Driver.start({
    cardsPath: CARD_PATH,
    streamPath: STREAM_PATH,
    feedId: FEED_ID,
    backlog: 10,
    focus: focus,
    legacyArchKey: 'summ_archived_v1',
    monitorIds: ['agent-base', 'agent-monitor', 'agent-summarizer'],
    onStatus: function (t) {
      statusText = t || '';
      var f = $('foot');
      if (f) f.textContent = statusText;
    }
  });
}

function current() {
  if (!Driver || !Agents) return null;
  // Same as monitor: Driver.rows() triggers resolve, refreshing isActive / real tty /
  // shell match. Without it a restored session cannot find its new shell.
  var rows = Driver.rows();
  // 1) With ?key=, merge the full card first to learn agent/sessionId
  if (q.key && !known.sid) {
    var r0 = Driver.loadCard(null, null, q.key);
    if (r0 && r0.sessionId) {
      known.agent = r0.agent || '';
      known.sid = r0.sessionId;
      Driver.cfg.focus = {
        agent: known.agent, sessionId: known.sid,
        key: q.key, requireRaw: true
      };
    }
    return r0 || null;
  }
  // 2) Located: make sure the full card is in the state machine
  if (known.sid) {
    return Driver.ensureFocus(true) || null;
  }
  // 3) No parameters: follow the most recent session
  return rows[0] || null;
}

function matchedShell(tty) {
  if (!tty) return null;
  try {
    var arr = JSON.parse(SshBridge.listShells() || '[]');
    if (Array.isArray(arr)) {
      for (var i = 0; i < arr.length; i++) {
        if (arr[i] && arr[i].tty === tty) return arr[i];
      }
    }
  } catch (e) {}
  return null;
}

function renderArchived(c) {
  $('acts').innerHTML = '';
  $('body').innerHTML = '<div class="msg">Session archived.</div>'
    + '<button class="act" id="actUnarch">Unarchive</button>';
  var u = $('actUnarch');
  if (u) {
    u.onclick = function () {
      Driver.unarchive(c.agent, c.sessionId, c.key);
      Driver.loadCard(c.agent, c.sessionId, c.key);
      render();
    };
  }
}

function renderCard(c) {
  var live = !!c.isActive;
  var d = c.details || {};
  var raw = c.raw || null;
  var ws = d.workspace || (raw && raw.workspace) || '';
  var tty = d.tty || (raw && raw.tty) || '';
  // Summarizer shows the LLM summary only; state, tools, raw text, steps, counts and
  // workspace/tty all live in Agent Monitor.
  var sem = d.summary || (raw && raw.semantic) || null;
  var hasSem = !!(sem && (sem.headline || sem.next
    || (sem.outcome || []).length || (sem.process || []).length));

  var chips = [];
  chips.push((c.name && c.name !== c.agent)
    ? (esc(c.name) + ' · ' + esc(c.agent || 'agent'))
    : esc(c.agent || 'agent'));
  chips.push(esc(fmtId(c.sessionId)));
  if (sem && sem.updatedAt) {
    chips.push('summarized ' + esc(fmtAgo(sem.updatedAt)));
  }
  if (sem && sem.toolCalls) chips.push(sem.toolCalls + ' tool calls');
  // State and activity badges come from base.STATE_UI, same as monitor
  var ui = BASE.stateUI(c.state || 'idle');
  $('metaChip').innerHTML =
    '<span class="badge" style="background:' + ui.color + '">'
    + esc(ui.label) + '</span>'
    + (live ? '<span class="chip">live</span>' : '')
    + '<span class="chip">' + chips.join(' · ') + '</span>';

  var h = '';
  if (hasSem) {
    if (sem.headline) h += '<div class="msg hl">' + esc(sem.headline) + '</div>';
    if ((sem.outcome || []).length) {
      h += '<div class="grp g-outcome"><div class="grp-title">outcome</div>';
      sem.outcome.forEach(function (x) {
        h += '<div class="item"><span class="tag ok">✓</span><span>'
          + esc(x) + '</span></div>';
      });
      h += '</div>';
    }
    if ((sem.process || []).length) {
      h += '<div class="grp g-process"><div class="grp-title">process</div>';
      sem.process.forEach(function (x) {
        h += '<div class="item"><span class="tag warn">→</span><span>'
          + esc(x) + '</span></div>';
      });
      h += '</div>';
    }
    if (sem.next) {
      h += '<div class="grp g-next"><div class="grp-title">next</div>'
        + '<div class="item"><span class="tag ok">»</span><span>'
        + esc(sem.next) + '</span></div></div>';
    }
  } else {
    h += '<div class="dim">No summary yet.</div>';
  }
  $('body').innerHTML = h;

  var sh = matchedShell(tty);
  var canResume = !!(ws || BASE.resumeCmd(c.agent, c.sessionId));
  var act = '';
  if (sh && live) {
    act += '<button class="act" id="actFocus">›_ Focus '
      + esc(sh.name || sh.id) + '</button>';
  }
  if ((!sh || !live) && canResume) {
    act += '<button class="act" id="actResume">↗ Resume</button>';
  }
  if (q.key || c.key) {
    act += '<button class="act" id="actArchive">Archive</button>';
  }
  act += '<button class="act" id="actRename">Rename</button>'
    + '<span id="rnWrap" style="display:none">'
    + '<input id="rnInput" type="text" style="width:180px;padding:4px 6px;'
    + 'background:#0F0F1A;color:#cfd;border:1px solid #2a5;border-radius:4px;'
    + 'font:11px monospace">'
    + '<button class="act" id="rnSave">Save</button>'
    + '<button class="act" id="rnCancel">Cancel</button></span>';
  $('acts').innerHTML = act;
  var focusBtn = $('actFocus');
  if (focusBtn) {
    focusBtn.onclick = function () { BASE.shellHooks().focusShell(sh.id); };
  }
  var resumeBtn = $('actResume');
  if (resumeBtn) {
    resumeBtn.onclick = function () {
      BASE.shellHooks().openShellWith(ws, BASE.resumeCmd(c.agent, c.sessionId));
    };
  }
  var archBtn = $('actArchive');
  if (archBtn) {
    archBtn.onclick = function () {
      Agents.archive(c.agent, c.sessionId);
      if (history.length > 1) history.back(); else location.href = 'home.html';
    };
  }
  var renBtn = $('actRename');
  var rnWrap = $('rnWrap');
  if (renBtn && rnWrap) {
    renBtn.onclick = function () {
      $('rnInput').value = c.name || c.agent || '';
      rnWrap.style.display = 'inline';
      $('rnInput').focus();
    };
    $('rnSave').onclick = function () {
      Agents.rename(c.agent, c.sessionId, $('rnInput').value);
      rnWrap.style.display = 'none';
      lastFp = '';
      render();
    };
    $('rnCancel').onclick = function () {
      rnWrap.style.display = 'none';
    };
    // Rename entry from the list page: ?rename=1 opens the input directly
    if (q.rename) {
      q.rename = false;
      renBtn.onclick();
    }
  }
}

function fpOf(c) {
  if (!c) return '';
  var d = c.details || {};
  return JSON.stringify([c.agent, c.sessionId, c.state, c.seq, c.lastActiveMs,
    c.isActive ? 1 : 0, d, c.raw]);
}

function render() {
  var cd = $('connDot');
  if (cd) cd.className = 'dot ' + (Driver.conn() ? 'on' : 'off');
  var f = $('foot');
  if (f) f.textContent = statusText;
  if (!Driver.conn()) {
    $('body').innerHTML = '<div class="dim">SSH not connected</div>';
    $('metaChip').innerHTML = '';
    $('acts').innerHTML = '';
    lastFp = '';
    return;
  }
  var c = current();
  var fp = fpOf(c);
  if (fp === lastFp) return;
  lastFp = fp;
  if (!c) {
    $('metaChip').innerHTML = '';
    $('acts').innerHTML = '';
    $('body').innerHTML = '<div class="dim">Waiting for session cards…</div>';
    return;
  }
  if (Agents.isArchived(c.agent, c.sessionId)) {
    $('metaChip').innerHTML = '<span class="chip">archived</span>';
    renderArchived(c);
  } else {
    renderCard(c);
  }
}

function tick() {
  if (!BASE || !Driver) return;
  Driver.tick();
  render();
}

if (BASE) {
  startDriver();
  tick();
  setInterval(tick, 1000);
  window.addEventListener('pagehide', function () { Driver.stop(); });
}
