'use strict';

/* Agent Summarizer - phone list renderer. State and data access live in
 * ../agent-base/base.js (Agents + Driver): cards.json baseline plus the cards.ndjson index
 * stream; the legacy summ_archived_v1 key is migrated once. */

var BASE = (typeof WhipBase !== 'undefined') ? WhipBase : null;
var Driver = BASE ? BASE.Driver : null;
var Agents = BASE ? BASE.Agents : null;

function $(id) { return document.getElementById(id); }
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function cap(s, n) {
  s = String(s == null ? '' : s);
  return s.length > n ? s.slice(0, n) + '…' : s;
}
function fmtSince(ms) {
  if (!ms) return '';
  var s = Math.max(0, Math.floor((Date.now() - ms) / 1000));
  if (s < 60) return s + 's ago';
  var m = Math.floor(s / 60);
  if (m < 60) return m + 'm ' + (s % 60) + 's ago';
  return Math.floor(m / 60) + 'h ' + (m % 60) + 'm ago';
}
function shortSid(sid) {
  sid = String(sid || '');
  return sid.length > 10 ? sid.slice(0, 10) + '…' : (sid || '-');
}

var CARD_PATH = '/root/.whip/monitor/state/cards.json';
var STREAM_PATH = '/root/.whip/monitor/state/cards.ndjson';
var FEED_ID = 'summ-stream';

var lastFp = '';
var statusText = '';

function startDriver() {
  if (!Driver) return;
  Driver.start({
    cardsPath: CARD_PATH,
    streamPath: STREAM_PATH,
    feedId: FEED_ID,
    backlog: 10,
    legacyArchKey: 'summ_archived_v1',
    monitorIds: ['agent-base', 'agent-monitor', 'agent-summarizer'],
    onStatus: function (t) {
      statusText = t || '';
      updateFoot();
    }
  });
}

function updateFoot() {
  var f = $('foot');
  if (!f) return;
  if (!Agents) { f.textContent = ''; return; }
  var n = Agents.listArchived().length;
  var h = [];
  if (statusText) h.push('<span>' + esc(statusText) + '</span>');
  if (n > 0) {
    h.push(n + ' archived · '
      + '<a id="archClear" href="#">Clear</a>');
  }
  f.innerHTML = h.join(' · ');
  var clearEl = $('archClear');
  if (clearEl) {
    clearEl.onclick = function (e) {
      e.preventDefault();
      Driver.clearArchived();
      render();
    };
  }
}

function summaryOf(r) {
  var d = r.details || {};
  // Summarizer only carries the LLM summary; without one it shows "no summary yet"
  // instead of falling back to live text/result (those belong to Agent Monitor).
  return (d.summary && d.summary.headline) || '';
}

/* Actions match monitor exactly: focus an existing shell or resume a session
 * (BASE.act handles ps liveness, markers and openShellWith); this is just the entry. */
function go(r) {
  if (!BASE || !r) return;
  BASE.act(BASE.actRow(r), BASE.shellHooks());
}

function rowFp(rs) {
  return JSON.stringify(rs.map(function (r) {
    var d = r.details || {};
    var sm = d.summary || null;
    return [r.agent, r.sessionId, r.name, r.key, r.lastActiveMs,
      r.isActive ? 1 : 0, r.state, d.tty,
      sm ? [sm.headline, sm.next, (sm.outcome || []).join('|'),
        sm.updatedAt, sm.toolCalls].join('\u0001') : ''];
  }));
}

function render() {
  var list = $('list');
  if (!list) return;
  if (!Driver || !Driver.conn()) {
    lastFp = '';
    list.innerHTML = '<div class="empty">SSH not connected.</div>';
    updateFoot();
    return;
  }
  var rs = Driver.rows();
  var fp = rowFp(rs);
  if (fp === lastFp) return;
  lastFp = fp;
  try {
    console.log('[agent-summarizer] rows=' + rs.length + ' '
      + rs.map(function (r) {
          return r.agent + ':' + String(r.sessionId).slice(0, 8)
            + ':' + (r.state || '?') + (r.isActive ? '+' : '');
        }).join(','));
  } catch (e) {}
  if (!rs.length) {
    list.innerHTML = '<div class="empty">No summaries.</div>';
    updateFoot();
    return;
  }
  list.innerHTML = '';
  rs.forEach(function (r) {
    var d = r.details || {};
    var name = r.name || r.agent || 'agent';
    var live = !!r.isActive;
    var tty = d.tty || '';
    var canResume = !!(d.workspace || BASE.resumeCmd(r.agent, r.sessionId));
    var sh = null;
    try {
      var arr = JSON.parse(SshBridge.listShells() || '[]');
      if (Array.isArray(arr)) {
        for (var i = 0; i < arr.length; i++) {
          if (arr[i] && arr[i].tty && arr[i].tty === tty) { sh = arr[i]; break; }
        }
      }
    } catch (e) {}
    var act = '';
    if (sh && live) {
      act += '<button class="act" data-act="focus">›_ '
        + esc(sh.name || sh.id) + '</button>';
    }
    if ((!sh || !live) && canResume) {
      act += '<button class="act" data-act="resume">↗ Resume</button>';
    }
    act += '<button class="act" data-act="rename">Rename</button>';
    act += '<button class="act" data-act="archive">Archive</button>';
    var sem = d.summary || null;
    // Summarizer card face = the summary only (headline / outcome / next).
    var sumHtml = '';
    if (sem && (sem.headline || sem.next || (sem.outcome || []).length)) {
      if (sem.headline) {
        sumHtml += '<div class="sum-head">' + esc(cap(sem.headline, 140))
          + '</div>';
      }
      var outs = (sem.outcome || []).slice(0, 2);
      if (outs.length) {
        sumHtml += '<div class="sum-line"><span class="sum-k">outcome</span>'
          + esc(cap(outs.join('；'), 160)) + '</div>';
      }
      if (sem.next) {
        sumHtml += '<div class="sum-line next"><span class="sum-k">next</span>'
          + esc(cap(sem.next, 120)) + '</div>';
      }
    } else {
      sumHtml = '<div class="sum-none">(no summary)</div>';
    }
    var meta = [];
    if (sem && sem.updatedAt) {
      meta.push('summarized ' + fmtSince(sem.updatedAt));
    } else if (r.lastActiveMs) {
      meta.push(fmtSince(r.lastActiveMs));
    }
    if (sem && sem.toolCalls) meta.push('tools ' + sem.toolCalls);
    var card = document.createElement('div');
    var ui = BASE.stateUI(r.state || 'idle');
    card.className = 'card' + (live ? ' live' : '');
    card.innerHTML =
      '<div class="id">'
      + '<div class="agent">' + esc(name)
      + (live ? '<span class="live-tag">live</span>' : '')
      + (sh && live ? '<span class="live-tag shell">shell</span>' : '')
      + '</div>'
      + '<div class="sid">session ' + esc(shortSid(r.sessionId)) + '</div>'
      + '<div class="meta">' + esc(meta.join(' · ')) + '</div>'
      + '</div>'
      + '<div class="right">'
      + '<span class="badge" style="background:' + ui.color + '">'
        + esc(ui.label) + '</span>'
      + (act ? '<div class="acts">' + act + '</div>' : '')
      + '</div>'
      + '<div class="summary">' + sumHtml + '</div>';
    card.onclick = function () {
      location.href = 'index.html?agent=' + encodeURIComponent(r.agent)
        + '&session=' + encodeURIComponent(r.sessionId)
        + (r.key ? '&key=' + encodeURIComponent(r.key) : '');
    };
    card.querySelectorAll('.act').forEach(function (b) {
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        var kind = b.getAttribute('data-act');
        if (kind === 'archive') {
          Agents.archive(r.agent, r.sessionId);
          render();
        } else if (kind === 'rename') {
          location.href = 'index.html?agent=' + encodeURIComponent(r.agent)
            + '&session=' + encodeURIComponent(r.sessionId)
            + (r.key ? '&key=' + encodeURIComponent(r.key) : '')
            + '&rename=1';
        } else {
          go(r);
        }
      });
    });
    list.appendChild(card);
  });
  updateFoot();
}

function tick() {
  if (!BASE) return;
  if (!Driver) { Driver = BASE.Driver; Agents = BASE.Agents; }
  var cd = $('connDot');
  if (cd) cd.className = 'dot ' + (Driver.conn() ? 'on' : 'off');
  Driver.tick();
  render();
}

if (BASE) {
  startDriver();
  tick();
  setInterval(tick, 1000);
  window.addEventListener('pagehide', function () { Driver.stop(); });
}
