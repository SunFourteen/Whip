/* System Info - core: read-only collectors and data source, no DOM.
 * Layout-agnostic: square/round renderers subscribe and draw. */
(function () {
  'use strict';

  var prev = null;
  var data = null;
  var host = '';
  var subs = [];

  /* Host commands come from the platform files (platform.posix.js / platform.windows.js),
   * so this collector is the same code on both hosts. */
  var PLATFORM = (function () {
    var env = {};
    try { env = JSON.parse(SshBridge.env() || '{}') || {}; } catch (e) {}
    if (env.id === 'windows' && window.SysinfoPlatformWindows) return window.SysinfoPlatformWindows;
    return window.SysinfoPlatformPosix || window.SysinfoPlatformWindows || null;
  })();
  function splitSections(raw) {
    var out = {};
    // CRLF on Windows, LF elsewhere: the parsers see one shape either way.
    var parts = String(raw).replace(/\r\n/g, '\n').split(/==SEC:([a-zA-Z]+)==\n?/);
    for (var i = 1; i + 1 < parts.length; i += 2) {
      if (!(parts[i] in out)) out[parts[i]] = parts[i + 1];
    }
    return out;
  }

  function ssh(cmd) {
    var r = JSON.parse(SshBridge.run(cmd, JSON.stringify({ timeoutMs: 20000 })) || '{}');
    if (!r || !r.ok) throw new Error((r && r.error) || 'ssh');
    return r.stdout || '';
  }
  function fmtBytes(n) {
    if (n == null || isNaN(n)) return '-';
    if (n < 1024) return n + ' B';
    var u = ['KB','MB','GB','TB'], i = -1;
    do { n /= 1024; i++; } while (n >= 1024 && i < u.length - 1);
    return n.toFixed(n >= 100 ? 0 : 1) + ' ' + u[i];
  }
  function pct(v) { return isNaN(v) ? '-' : Math.round(v) + '%'; }
  function warn(v) { return v >= 85 ? 'crit' : v >= 60 ? 'warn' : ''; }

  function parseStat(t) {
    var out = { total: 0, idle: 0, user: 0, sys: 0, io: 0 };
    var first = true;
    t.split('\n').forEach(function (l) {
      if (!first) return;
      first = false;
      var p = String(l).trim().split(/\s+/);
      if (p[0] !== 'cpu') return;
      out = {
        total: 0, idle: +p[4] + +(p[5] || 0),
        user: +p[1] || 0, sys: +p[3] || 0, io: +p[5] || 0
      };
      for (var i = 1; i < p.length; i++) out.total += +p[i] || 0;
    });
    return out;
  }
  function parseMem(t) {
    var total = 0, avail = 0;
    t.split('\n').forEach(function (l) {
      var m = /^MemTotal:\s+(\d+)/.exec(l);
      if (m) total = +m[1] * 1024;
      m = /^MemAvailable:\s+(\d+)/.exec(l);
      if (m) avail = +m[1] * 1024;
    });
    return { total: total, avail: avail, used: Math.max(0, total - avail) };
  }
  function parseNet(t) {
    var rx = 0, tx = 0;
    t.split('\n').forEach(function (l) {
      // /proc/net/dev has exactly seven counters between rx_bytes and tx_bytes
      var m = /^\s*([^:\s]+):\s*(\d+)\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+(\d+)/.exec(l);
      if (!m || m[1] === 'lo') return;
      rx += +m[2]; tx += +m[3];
    });
    return { rx: rx, tx: tx };
  }
  function parseDisk(t) {
    var lines = t.trim().split('\n');
    if (!lines.length) return null;
    var p = lines[lines.length - 1].trim().split(/\s+/);
    if (p.length < 6) return null;
    return {
      fs: p[0], type: p[1], size: +p[2], used: +p[3],
      avail: +p[4], pct: parseInt(p[5], 10) || 0, mount: p[6] || '/'
    };
  }
  function sample() {
    if (PLATFORM) {
      // One round trip for the whole sample: the same sectioned command the phone page uses
      var sec = splitSections(ssh(PLATFORM.tickCmd({ disk: true })));
      return {
        stat: parseStat(sec.stat || ''),
        net: parseNet(sec.net || ''),
        mem: parseMem(sec.mem || ''),
        disk: parseDisk(sec.disk || ''),
        ts: Date.now()
      };
    }
    return {
      stat: parseStat(ssh('cat /proc/stat | head -1')),
      net: parseNet(ssh('cat /proc/net/dev')),
      mem: parseMem(ssh('grep -E "MemTotal|MemAvailable" /proc/meminfo')),
      disk: parseDisk(ssh('df -P -B1 -T / 2>/dev/null')),
      ts: Date.now()
    };
  }

  function notify(err) {
    subs.forEach(function (f) { try { f(data, !!err); } catch (e) {} });
  }
  function collect() {
    try {
      var cur = sample();
      if (!prev) {
        prev = cur;
        notify();
        return;
      }
      var dt = (cur.ts - prev.ts) / 1000;
      var dTot = Math.max(1, cur.stat.total - prev.stat.total);
      var cpu = dt > 0 ? 100 * (1 - (cur.stat.idle - prev.stat.idle) / dTot) : 0;
      var memPct = cur.mem.total ? cur.mem.used / cur.mem.total * 100 : 0;
      data = {
        host: host,
        cpu: Math.max(0, Math.min(100, cpu)),
        cpuU: 100 * (cur.stat.user - prev.stat.user) / dTot,
        cpuS: 100 * (cur.stat.sys - prev.stat.sys) / dTot,
        cpuIo: 100 * (cur.stat.io - prev.stat.io) / dTot,
        mem: memPct,
        memUsed: cur.mem.used, memAvail: cur.mem.avail,
        diskPct: cur.disk ? cur.disk.pct : 0,
        diskUsed: cur.disk ? cur.disk.used : 0,
        diskAvail: cur.disk ? cur.disk.avail : 0,
        diskMount: cur.disk ? cur.disk.mount : '',
        rx: dt > 0 ? (cur.net.rx - prev.net.rx) / dt : 0,
        tx: dt > 0 ? (cur.net.tx - prev.net.tx) / dt : 0
      };
      prev = cur;
      notify();
    } catch (e) {
      prev = null;
      notify(true);
    }
  }

  window.VmSysCore = {
    start: function (h) {
      host = h || '';
      // The platform decides the cadence: a Windows sample is a fresh PowerShell.
      var interval = (PLATFORM && PLATFORM.tickIntervalMs) || 2000;
      collect();
      setInterval(collect, interval);
    },
    getData: function () { return data; },
    subscribe: function (f) { if (f) subs.push(f); },
    fmtBytes: fmtBytes,
    pct: pct,
    warn: warn
  };
})();
