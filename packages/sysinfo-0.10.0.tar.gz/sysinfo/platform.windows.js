/* System Monitor - host platform: Windows.
 *
 * The app runs plugin commands through PowerShell here, so one script collects every
 * section the POSIX collector produces. Counters are the *raw* ones (cumulative), because
 * the shared parser derives usage from deltas the same way it does with /proc/stat.
 */
window.SysinfoPlatformWindows = (function () {
  'use strict';

  function tick(want) {
    var lines = [];
    lines.push("$ErrorActionPreference='SilentlyContinue'");
    // Progress bars and module autoload chatter cost more than the work itself in a
    // non-interactive session.
    lines.push('$ProgressPreference = \'SilentlyContinue\'');
    lines.push("$os = Get-CimInstance Win32_OperatingSystem");

    // CPU + memory are the only sections every tick needs; they come from two CIM calls.
    lines.push("Write-Output '==SEC:stat=='");
    lines.push('foreach ($c in Get-CimInstance Win32_PerfRawData_PerfOS_Processor) {');
    lines.push("  $n = if ($c.Name -eq '_Total') { 'cpu' } else { 'cpu' + $c.Name }");
    lines.push('  Write-Output ("{0} {1} 0 0 {2} 0 0 0 0 0" -f $n, ' +
      '[uint64]$c.PercentProcessorTime, [uint64]$c.PercentIdleTime)');
    lines.push('}');

    lines.push("Write-Output '==SEC:mem=='");
    lines.push('Write-Output ("MemTotal: {0} kB" -f $os.TotalVisibleMemorySize)');
    lines.push('Write-Output ("MemAvailable: {0} kB" -f $os.FreePhysicalMemory)');
    lines.push('Write-Output ("SwapTotal: {0} kB" -f $os.TotalVirtualMemorySize)');
    lines.push('Write-Output ("SwapFree: {0} kB" -f $os.FreeVirtualMemory)');
    lines.push("Write-Output 'Buffers: 0 kB'");
    lines.push("Write-Output 'Cached: 0 kB'");

    // The parser skips the first two lines, exactly like /proc/net/dev's header
    lines.push("Write-Output '==SEC:net=='");
    lines.push("Write-Output 'Inter-|   Receive                                                |  Transmit'");
    lines.push("Write-Output ' face |bytes    packets errs drop fifo frame compressed multicast|bytes    packets errs drop fifo colls carrier compressed'");
    lines.push('Get-NetAdapterStatistics | ForEach-Object {');
    lines.push("  $n = ($_.Name -replace '[^\\w]', '_')");
    lines.push('  Write-Output ("{0}: {1} 0 0 0 0 0 0 0 {2} 0 0 0 0 0 0 0" -f ' +
      '$n, [uint64]$_.ReceivedBytes, [uint64]$_.SentBytes)');
    lines.push('}');

    // Windows has no load average: report the processor queue length instead. The process
    // count that /proc/loadavg carries comes from the process section when it runs, so a
    // plain tick does not have to enumerate the process table at all.
    lines.push("Write-Output '==SEC:load=='");
    lines.push('$queue = [int](Get-CimInstance Win32_PerfFormattedData_SystemProcessorQueueLength).ProcessorQueueLength');
    lines.push('Write-Output ("{0} {0} {0} 0/0 0" -f $queue)');

    lines.push("Write-Output '==SEC:uptime=='");
    lines.push('$up = ((Get-Date) - $os.LastBootUpTime).TotalSeconds');
    lines.push('Write-Output ("{0} 0.0" -f [int]$up)');

    // Static identity is expensive (Win32_ComputerSystem / Win32_Processor are slow CIM
    // classes) and never changes, so it is only collected when the caller asks for it.
    if (want.static) {
      lines.push("Write-Output '==SEC:host=='");
      lines.push("Write-Output $env:COMPUTERNAME");
      lines.push("Write-Output '==SEC:kernel=='");
      lines.push('Write-Output ([Environment]::OSVersion.VersionString)');
      lines.push("Write-Output '==SEC:cores=='");
      lines.push('Write-Output (Get-CimInstance Win32_ComputerSystem).NumberOfLogicalProcessors');
      lines.push("Write-Output '==SEC:cpuModel=='");
      lines.push('Write-Output ((Get-CimInstance Win32_Processor | Select-Object -First 1).Name)');
      lines.push("Write-Output '==SEC:os=='");
      lines.push('Write-Output $os.Caption');
    }

    if (want.disk) {
      lines.push("Write-Output '==SEC:disk=='");
      lines.push("Write-Output 'Filesystem Type 1B-blocks Used Available Capacity Mounted'");
      lines.push("Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object {");
      lines.push('  $size = [uint64]$_.Size; $free = [uint64]$_.FreeSpace; $used = $size - $free');
      lines.push('  $pct = if ($size -gt 0) { [int](100 * $used / $size) } else { 0 }');
      lines.push('  Write-Output ("{0} {1} {2} {3} {4} {5}% {0}\\" -f ' +
        '$_.DeviceID, $_.FileSystem, $size, $used, $free, $pct)');
      lines.push('}');
    }

    if (want.net) {
      lines.push("Write-Output '==SEC:ips=='");
      lines.push('$i = 0');
      lines.push('Get-NetIPAddress -AddressFamily IPv4 | ForEach-Object {');
      lines.push('  $i++');
      lines.push("  $n = ($_.InterfaceAlias -replace '[^\\w]', '_')");
      lines.push('  Write-Output ("{0}: {1}    inet {2}/{3} scope global" -f ' +
        '$i, $n, $_.IPAddress, $_.PrefixLength)');
      lines.push('}');
      // One process listing for every listening socket: a Get-Process per connection
      // costs more than the whole rest of the tick.
      lines.push('$nameOf = @{}');
      lines.push('foreach ($p in Get-CimInstance Win32_Process) { $nameOf[[int]$p.ProcessId] = $p.Name }');
      lines.push("Write-Output '==SEC:ports=='");
      lines.push('Get-NetTCPConnection -State Listen | ForEach-Object {');
      lines.push('  $procName = $nameOf[[int]$_.OwningProcess]');
      lines.push('  Write-Output ("tcp LISTEN 0 0 {0}:{1} 0.0.0.0:* {2}/{3}" -f ' +
        '$_.LocalAddress, $_.LocalPort, $procName, $_.OwningProcess)');
      lines.push('}');
      lines.push('Get-NetUDPEndpoint | ForEach-Object {');
      lines.push('  $procName = $nameOf[[int]$_.OwningProcess]');
      lines.push('  Write-Output ("udp UNCONN 0 0 {0}:{1} 0.0.0.0:* {2}/{3}" -f ' +
        '$_.LocalAddress, $_.LocalPort, $procName, $_.OwningProcess)');
      lines.push('}');
    }

    if (want.temp) {
      // Usually needs elevation; when it fails the UI simply hides the temperature card.
      lines.push("Write-Output '==SEC:temp=='");
      lines.push('Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature | ForEach-Object {');
      lines.push('  $c = [int]($_.CurrentTemperature / 10 - 273.15)');
      lines.push("  $n = ($_.InstanceName -replace '[^\\w]', '_')");
      lines.push('  Write-Output ("{0}:{1}" -f $n, $c)');
      lines.push('}');
    }

    if (want.proc) {
      lines.push("Write-Output '==SEC:proc=='");
      lines.push("Write-Output '  PID  PPID USER %CPU %MEM RSS ELAPSED STAT COMMAND'");
      lines.push('$totalMem = $os.TotalVisibleMemorySize * 1KB');
      lines.push('$upSec = ((Get-Date) - $os.LastBootUpTime).TotalSeconds');
      lines.push('$cores = (Get-CimInstance Win32_ComputerSystem).NumberOfLogicalProcessors');
      // One CIM listing carries pid/ppid/owner/CPU/memory/command line; the previous
      // version enumerated it once for the parent map and again through Get-Process.
      lines.push('Get-CimInstance Win32_Process | Sort-Object -Descending ' +
        '{ [double]$_.UserModeTime + [double]$_.KernelModeTime } | Select-Object -First 150 | ForEach-Object {');
      lines.push('  $cpuSec = ([double]$_.UserModeTime + [double]$_.KernelModeTime) / 10000000');
      lines.push('  $cpuPct = if ($upSec -gt 0 -and $cores -gt 0) { ' +
        '[math]::Round(100 * $cpuSec / $upSec / $cores, 1) } else { 0 }');
      lines.push('  $rss = [int64]$_.WorkingSetSize');
      lines.push('  $memPct = if ($totalMem -gt 0) { [math]::Round(100 * $rss / $totalMem, 1) } else { 0 }');
      lines.push('  $started = if ($_.CreationDate) { (Get-Date) - $_.CreationDate } else { [TimeSpan]::Zero }');
      lines.push('  $elapsed = "{0:d2}:{1:d2}:{2:d2}" -f [int]$started.TotalHours, $started.Minutes, $started.Seconds');
      lines.push('  Write-Output ("{0} {1} {2} {3} {4} {5} {6} {7} {8} {9}" -f ' +
        '$_.ProcessId, $_.ParentProcessId, $env:USERNAME, $cpuPct, $memPct, [int]($rss / 1KB), ' +
        '$elapsed, "S", ($_.Name -replace "\\.exe$", ""), $_.CommandLine)');
      lines.push('}');
    }

    return lines.join('\n');
  }

  return {
    id: 'windows',
    /**
     * Every plugin call starts a fresh PowerShell, and the CIM calls behind the dynamic
     * sections cost a few hundred milliseconds each — so Windows refreshes less often than
     * a /proc-backed host does.
     */
    tickIntervalMs: 4000,
    tickCmd: tick,
    killCmd: function (pid) {
      return "$ErrorActionPreference='Stop'; Stop-Process -Id " + Number(pid) + ' -Force';
    },
    probeCmd: function () { return 'Write-Output ok' }
  };
})();
