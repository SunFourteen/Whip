/* System Monitor - host platform: POSIX.
 *
 * One command per tick, sectioned with ==SEC:<name>== markers; the Windows file emits the
 * same sections so the parser and the whole UI stay platform-neutral.
 */
window.SysinfoPlatformPosix = (function () {
  'use strict';
  return {
    id: 'posix',
    /** A /proc read is cheap: keep the fast refresh. */
    tickIntervalMs: 2000,
    tickCmd: function (want) {
      var cmds = [
        ['stat', 'cat /proc/stat'],
        ['mem', 'cat /proc/meminfo'],
        ['net', 'cat /proc/net/dev'],
        ['load', 'cat /proc/loadavg'],
        ['uptime', 'cat /proc/uptime']
      ];
      if (want.static) {
        cmds.push(['host', 'hostname']);
        cmds.push(['kernel', 'uname -srm']);
        cmds.push(['cores', 'nproc']);
        cmds.push(['cpuModel', "grep 'model name' /proc/cpuinfo | head -1 | cut -d: -f2"]);
        cmds.push(['os', "grep 'PRETTY_NAME' /etc/os-release 2>/dev/null | head -1 | cut -d= -f2 | tr -d '\"'"]);
      }
      if (want.disk) cmds.push(['disk', 'df -P -B1 -T 2>/dev/null']);
      if (want.net) {
        cmds.push(['ips', 'ip -4 -o addr show 2>/dev/null || hostname -I 2>/dev/null']);
        cmds.push(['ports', 'ss -tulnp 2>/dev/null | tail -n +2 || netstat -tulnp 2>/dev/null | tail -n +2']);
      }
      if (want.temp) {
        cmds.push(['temp', 'for z in /sys/class/thermal/thermal_zone*/temp; do ' +
          '[ -r "$z" ] && echo "$(basename $z):$(( $(cat $z) / 1000 ))"; done 2>/dev/null; true']);
      }
      if (want.proc) {
        cmds.push(['proc', 'ps -eo pid,ppid,user,%cpu,%mem,rss,etime,stat,comm,args ' +
          '--sort=-%cpu 2>/dev/null | head -n 151']);
      }
      return cmds.map(function (c) { return 'echo "==SEC:' + c[0] + '=="; ' + c[1]; }).join('; ');
    },
    killCmd: function (pid) { return 'kill -9 ' + Number(pid) + ' 2>&1'; },
    probeCmd: function () { return 'echo ok'; }
  };
})();
