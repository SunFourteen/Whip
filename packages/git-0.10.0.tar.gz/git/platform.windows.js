/* Git Repo - host platform: Windows.
 *
 * Same API as platform.posix.js, spelled in PowerShell. Two Windows notes:
 *   - git itself is Git for Windows, so its output format matches the POSIX plugin;
 *   - temporary files (commit message, rebase todo) go to %TEMP%, and the sequence editor
 *     is a command that Git's own sh runs, so it is given a forward-slash path.
 */
window.GitPlatformWindows = (function () {
  'use strict';

  var env = {};
  try { env = JSON.parse(SshBridge.env() || '{}') || {}; } catch (e) {}
  var HOME = env.home || '';

  function q(s) { return "'" + String(s == null ? '' : s).replace(/'/g, "''") + "'"; }
  /** %TEMP% file, safe in both argument and expression position */
  function tempPath(name) { return "(Join-Path $env:TEMP " + q(name) + ")"; }

  return {
    id: 'windows',
    home: HOME,
    quotePath: q,

    gitCmd: function (repo, args) { return 'git -C ' + q(repo) + ' ' + args; },

    expandHome: function (p) {
      p = String(p || '').trim();
      if (p === '~') return HOME;
      if (p.indexOf('~/') === 0 || p.indexOf('~\\') === 0) return HOME + '\\' + p.slice(2);
      return p;
    },

    discoverCmd: function () {
      return [
        // Not "$home": PowerShell's $HOME is read-only, and assigning to it fails the whole
        // script under the error-action wrapper every command runs in.
        "$userHome = $env:USERPROFILE",
        "$cands = New-Object System.Collections.Generic.List[string]",
        "$roots = @($userHome, (Join-Path $userHome 'workspace'), (Join-Path $userHome 'projects'),",
        "  (Join-Path $userHome 'src'), (Join-Path $userHome 'code'), (Join-Path $userHome 'repos'))",
        "foreach ($r in $roots) {",
        "  if (Test-Path -LiteralPath $r) { $cands.Add($r) }",
        "  Get-ChildItem -LiteralPath $r -Directory -ErrorAction SilentlyContinue |",
        "    ForEach-Object { $cands.Add($_.FullName) }",
        "}",
        "$cards = Join-Path $userHome '.whip\\monitor\\state\\cards.json'",
        "if (Test-Path -LiteralPath $cards) {",
        "  try {",
        "    $idx = Get-Content -LiteralPath $cards -Raw -Encoding UTF8 | ConvertFrom-Json",
        "    foreach ($s in $idx.sessions) { if ($s.workspace) { $cands.Add([string]$s.workspace) } }",
        "  } catch { }",
        "}",
        "$cands | Sort-Object -Unique | Where-Object {",
        "  $_ -and (Test-Path -LiteralPath (Join-Path $_ '.git')) }"
      ].join('\n');
    },

    discardCmd: function (path) {
      return 'Remove-Item -LiteralPath ' + q(path) + ' -Force -ErrorAction SilentlyContinue';
    },

    /**
     * Run several git commands in one round trip. On Windows each round trip is a fresh
     * PowerShell, so the page's whole state comes back from a single call.
     */
    batchSeparator: '==WHIP-B==',

    batchCmd: function (commands) {
      return commands.map(function (c) { return '(' + c + ') 2>&1' })
        .join("; Write-Output '==WHIP-B=='; ");
    },

    commitCmd: function (repo, messageB64, extraArgs) {
      return '[IO.File]::WriteAllBytes(' + tempPath('whip_msg') + ', '
        + '[Convert]::FromBase64String(' + q(messageB64) + ')); '
        + 'git -C ' + q(repo) + ' commit' + (extraArgs || '')
        + ' -F ' + tempPath('whip_msg') + ' 2>&1';
    },

    interactiveRebaseCmd: function (repo, todoB64, sha) {
      // Git runs the sequence editor through its own sh, so hand it a forward-slash path.
      return '[IO.File]::WriteAllBytes(' + tempPath('whip_todo') + ', '
        + '[Convert]::FromBase64String(' + q(todoB64) + ')); '
        + "$env:GIT_SEQUENCE_EDITOR = 'cp \"' + ((Join-Path $env:TEMP 'whip_todo') -replace '\\\\', '/') + '\"'; "
        + "$env:GIT_EDITOR = 'true'; "
        + 'git -C ' + q(repo) + ' -c rebase.autoStash=true rebase -i ' + sha + ' 2>&1';
    }
  };
})();
