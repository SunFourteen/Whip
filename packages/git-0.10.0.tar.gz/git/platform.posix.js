/* Git Repo - host platform: POSIX.
 *
 * Everything the plugin does through the shell lives here: quoting, the git command line,
 * repository discovery, the temporary files git needs for commit messages and interactive
 * rebase. platform.windows.js provides the same API for Windows hosts.
 */
window.GitPlatformPosix = (function () {
  'use strict';

  var env = {};
  try { env = JSON.parse(SshBridge.env() || '{}') || {}; } catch (e) {}
  var HOME = env.home || '/root';

  function q(s) { return "'" + String(s == null ? '' : s).replace(/'/g, "'\\''") + "'"; }

  return {
    id: 'posix',
    home: HOME,
    quotePath: q,

    gitCmd: function (repo, args) { return 'git -C ' + q(repo) + ' ' + args; },

    expandHome: function (p) {
      p = String(p || '').trim();
      if (p === '~') return HOME;
      if (p.indexOf('~/') === 0) return HOME + p.slice(1);
      return p;
    },

    /** One round trip that prints only directories that really are git repositories. */
    discoverCmd: function () {
      return [
        'ws=$(sed -n \'s/.*"workspace":"\\([^"]*\\)".*/\\1/p\' ' +
          '"$HOME/.whip/monitor/state/cards.json" 2>/dev/null | sort -u)',
        'for p in "$HOME" "$HOME/workspace" "$HOME/projects" "$HOME/src" ' +
          '"$HOME/code" "$HOME/repos" "$HOME/workspace"/* "$HOME/projects"/* ' +
          '"$HOME/src"/* "$HOME/code"/* "$HOME/repos"/* $ws; do',
        '  [ -n "$p" ] && [ -d "$p/.git" ] && printf "%s\\n" "$p"',
        'done 2>/dev/null; true'
      ].join('\n');
    },

    discardCmd: function (path) { return 'rm -f -- ' + q(path) + ' 2>&1'; },

    /**
     * Run several git commands in one round trip, separated by a marker line. Every extra
     * round trip is a new shell process on some hosts, so the page loads its state in one.
     */
    batchSeparator: '==WHIP-B==',

    batchCmd: function (commands) {
      return commands.map(function (c) { return '{ ' + c + '; } 2>&1'; })
        .join('; echo ' + "'==WHIP-B=='" + '; ');
    },

    commitCmd: function (repo, messageB64, extraArgs) {
      return 'echo ' + messageB64 + ' | base64 -d > /tmp/whip_msg && '
        + 'git -C ' + q(repo) + ' commit' + (extraArgs || '') + ' -F /tmp/whip_msg 2>&1';
    },

    interactiveRebaseCmd: function (repo, todoB64, sha) {
      return 'echo ' + todoB64 + ' | base64 -d > /tmp/whip_todo && '
        + "GIT_SEQUENCE_EDITOR='cp /tmp/whip_todo' GIT_EDITOR=true "
        + 'git -C ' + q(repo) + ' -c rebase.autoStash=true rebase -i ' + sha + ' 2>&1';
    }
  };
})();
