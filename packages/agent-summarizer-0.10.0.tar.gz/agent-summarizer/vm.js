'use strict';

/* Agent Summarizer - square/round renderer. State and data access live in
 * ../agent-base/base.js (Agents + Driver); this file renders list/detail/rename only. */

var BASE = (typeof WhipBase !== 'undefined') ? WhipBase : null;
var HOST_PATHS = (BASE && BASE.paths) || {};
var Driver = BASE ? BASE.Driver : null;
var Agents = BASE ? BASE.Agents : null;

var CARD_PATH = HOST_PATHS.cardsPath || '';
var STREAM_PATH = HOST_PATHS.streamPath || '';
var FEED_ID = 'summ-stream-vm';

var detailSid = null;
var renameSid = null;
var lastFp = '';

function esc2(s) { return String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function cap2(s, n) {
  s = String(s == null ? '' : s);
  return s.length > n ? s.slice(0, n) + '…' : s;
}
function sidShort(sid) {
  sid = String(sid || '');
  return sid.length > 14 ? sid.slice(0, 14) + '…' : sid;
}
function fmtSince(ms) {
  if (!ms) return '';
  var s = Math.max(0, Math.floor((Date.now() - ms) / 1000));
  if (s < 60) return s + 's';
  if (s < 3600) return Math.floor(s / 60) + 'm';
  return Math.floor(s / 3600) + 'h';
}

function startDriver() {
  if (!Driver) return;
  Driver.start({
    cardsPath: CARD_PATH,
    streamPath: STREAM_PATH,
    feedId: FEED_ID,
    backlog: 10,
    legacyArchKey: 'summ_archived_v1',
    monitorIds: ['agent-base', 'agent-monitor', 'agent-summarizer']
  });
}

function go(r) {
  if (!BASE || !r) return;
  BASE.act(BASE.actRow(r), BASE.shellHooks());
}

function arch(r) {
  Agents.archive(r.agent, r.sessionId);
  render();
  closeDetail();
}

function rowFp(rs) {
  return JSON.stringify(rs.map(function (r) {
    var d = r.details || {};
    var sm = d.summary || null;
    return [r.agent, r.sessionId, r.name, r.lastActiveMs,
      sm ? [sm.headline, sm.next, (sm.outcome || []).join('|'),
        sm.updatedAt, sm.toolCalls].join('\u0001') : ''];
  }));
}

function render() {
  var list = document.getElementById('list');
  var dot = document.getElementById('dot');
  if (dot) dot.className = 'dot ' + (Driver.conn() ? 'on' : 'off');
  if (!Driver.conn()) {
    lastFp = '';
    list.innerHTML = '<div class="empty">No SSH.<br>Connect in Terminal first.</div>';
    if (detailSid) closeDetail();
    return;
  }
  var rs = Driver.rows();
  var fp = rowFp(rs);
  if (fp === lastFp) return;
  lastFp = fp;
  if (!rs.length) {
    list.innerHTML = '<div class="empty">No summaries yet.<br>'
      + 'Run the summarizer on the host.</div>';
    return;
  }
  list.innerHTML = rs.map(function (r, i) {
    var d = r.details || {};
    var sm = d.summary || null;
    // Summary only: session identity + summary time/tool count + conclusion.
    var meta = sidShort(r.sessionId)
      + (sm && sm.updatedAt ? ' · summarized ' + fmtSince(sm.updatedAt)
        : (r.lastActiveMs ? ' · ' + fmtSince(r.lastActiveMs) : ''))
      + (sm && sm.toolCalls ? ' · tools ' + sm.toolCalls : '');
    var ui = BASE.stateUI(r.state || 'idle');
    return '<div class="row" data-i="' + i + '">'
      + '<div class="top">'
      + '<span class="st" style="background:' + ui.color + '"></span>'
      + '<span class="n">' + esc2(r.name || r.agent || 'agent')
        + (r.isActive ? ' ●' : '') + '</span>'
      + '<span class="state" style="background:' + ui.color + '">'
        + esc2(ui.tag) + '</span>'
      + '<button class="go" type="button">Go</button>'
      + '<button class="arch" type="button">Arch</button>'
      + '</div>'
      + '<div class="sub">' + esc2(meta) + '</div>'
      + (sm && sm.headline
          ? '<div class="sum">' + esc2(cap2(sm.headline, 140)) + '</div>'
          : '<div class="sum none">(no summary)</div>')
      + '</div>';
  }).join('');
  list.querySelectorAll('.row').forEach(function (rowEl) {
    var r = rs[Number(rowEl.getAttribute('data-i'))];
    var goEl = rowEl.querySelector('.go');
    var archEl = rowEl.querySelector('.arch');
    if (goEl) goEl.addEventListener('click', function (ev) {
      ev.stopPropagation(); go(r);
    });
    if (archEl) archEl.addEventListener('click', function (ev) {
      ev.stopPropagation(); arch(r);
    });
    rowEl.addEventListener('click', function (ev) {
      if (ev.target && ev.target.tagName === 'BUTTON') return;
      detailSid = r.sessionId;
      renderDetail();
    });
  });
}

/* This page carries the summary only: VM detail = the conclusion block. */
function sumBlockHtml(sem) {
  if (!sem || !(sem.headline || sem.next || (sem.outcome || []).length)) return '';
  var h = '<div class="dsum">';
  if (sem.headline) h += '<div class="dsumhead">' + esc2(sem.headline) + '</div>';
  (sem.outcome || []).slice(0, 3).forEach(function (x) {
    h += '<div class="dsumitem">✓ ' + esc2(x) + '</div>';
  });
  if (sem.next) h += '<div class="dsumnext">» ' + esc2(sem.next) + '</div>';
  return h + '</div>';
}

function renderDetail() {
  var dl = document.getElementById('detail');
  var r = detailSid ? Agents.find('', detailSid) : null;
  if (!r || Agents.isArchived(r.agent, r.sessionId)) { closeDetail(); return; }
  var d = r.details || {};
  document.getElementById('dTitle').textContent =
    (r.name || r.agent || 'agent') + ' · ' + sidShort(r.sessionId);
  var sm = d.summary || null;
  var metaTs = (sm && sm.updatedAt) ? sm.updatedAt : r.lastActiveMs;
  var ui = BASE.stateUI(r.state || 'idle');
  var html = '<span class="dchip" style="background:' + ui.color + '">'
      + esc2(ui.tag) + '</span>'
    + (r.isActive ? '<span class="dchip" style="background:#00cc66">live</span>' : '')
    + (metaTs ? '<span class="dchip" style="background:#333">'
      + esc2('summarized ' + fmtSince(metaTs)) + '</span>' : '')
    + (sm && sm.toolCalls ? '<span class="dchip" style="background:#333">tools '
      + sm.toolCalls + '</span>' : '')
    + (sumBlockHtml(sm)
      || '<div class="dmsg">No summary yet.</div>');
  document.getElementById('dbody').innerHTML = html;
  document.getElementById('dGo').onclick = function () { go(r); };
  document.getElementById('dArch').onclick = function () { arch(r); };
  dl.classList.add('show');
}

function closeDetail() {
  detailSid = null;
  var dl = document.getElementById('detail');
  if (dl) dl.classList.remove('show');
}

function openRename() {
  var r = detailSid ? Agents.find('', detailSid) : null;
  if (!r) return;
  renameSid = r.sessionId;
  document.getElementById('rName').value = r.name || r.agent || '';
  document.getElementById('rename').classList.add('show');
}

function saveRename() {
  var r = renameSid ? Agents.find('', renameSid) : null;
  if (r) {
    Agents.rename(r.agent, r.sessionId,
      document.getElementById('rName').value);
  }
  renameSid = null;
  document.getElementById('rename').classList.remove('show');
  render();
  if (detailSid) renderDetail();
}

function tick() {
  if (!BASE) return;
  if (!Driver) { Driver = BASE.Driver; Agents = BASE.Agents; }
  Driver.tick();
  render();
}

if (BASE) {
  startDriver();
  document.getElementById('back').addEventListener('click', function () {
    history.back();
  });
  document.getElementById('dBack').addEventListener('click', closeDetail);
  document.getElementById('dRen').addEventListener('click', openRename);
  document.getElementById('rBack').addEventListener('click', function () {
    renameSid = null;
    document.getElementById('rename').classList.remove('show');
  });
  document.getElementById('rCancel').addEventListener('click', function () {
    renameSid = null;
    document.getElementById('rename').classList.remove('show');
  });
  document.getElementById('rSave').addEventListener('click', saveRename);
  render();
  tick();
  setInterval(tick, 1000);
  window.addEventListener('pagehide', function () { Driver.stop(); });
}
