'use strict';

/* Agent Summarizer - fallback wearable layer for remote copies that lack square/round
 * entries. Same data source as VM/phone: base Agents + Driver. */
(function () {
  function screenMode() {
    var c = document.documentElement.className || '';
    if (c.indexOf('shape-round') >= 0) return 'round';
    if (c.indexOf('shape-square') >= 0) return 'square';
    if (c.indexOf('wearable') >= 0) return 'square';
    return 'phone';
  }

  var BASE = (typeof WhipBase !== 'undefined') ? WhipBase : null;
var HOST_PATHS = (BASE && BASE.paths) || {};
  var Driver = BASE ? BASE.Driver : null;
  var Agents = BASE ? BASE.Agents : null;
  var DETAIL = /index\.html(\?|$)/.test(location.pathname);
  var qKey = '';
  var qAgent = '';
  var qSession = '';
  if (DETAIL) {
    try {
      var u0 = new URLSearchParams(location.search);
      qKey = u0.get('key') || '';
      qAgent = u0.get('agent') || '';
      qSession = u0.get('session') || '';
    } catch (e) {}
  }
  var root = null;
  var bodyEl = null;
  var l3El = null;
  var l3BodyEl = null;
  var lastFp = '';
  var lastHomeFp = '';
  var started = false;

  var CFG = {
    cardsPath: HOST_PATHS.cardsPath,
    streamPath: HOST_PATHS.streamPath,
    feedId: DETAIL ? 'summ-wear-detail' : 'summ-wear-home',
    backlog: 10,
    legacyArchKey: 'summ_archived_v1',
    monitorIds: ['agent-base', 'agent-monitor', 'agent-summarizer']
  };
  if (DETAIL) {
    // Same as monitor: prefer agent+sessionId, key is only a fallback
    if (qSession) {
      CFG.focus = { agent: qAgent, sessionId: qSession,
        key: qKey, requireRaw: true };
    } else if (qKey) {
      CFG.focus = { key: qKey, requireRaw: true };
    }
  }

  function ensureDriver() {
    if (!BASE) return;
    if (!Driver) { Driver = BASE.Driver; Agents = BASE.Agents; }
    if (Driver && !Driver.cfg) Driver.start(CFG);
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  function cap(s, n) {
    s = String(s == null ? '' : s);
    return s.length > n ? s.slice(0, n) + '…' : s;
  }
  function ago(ms) {
    if (!ms) return '';
    var s = Math.max(0, Math.floor((Date.now() - ms) / 1000));
    if (s < 60) return s + 's';
    if (s < 3600) return Math.floor(s / 60) + 'm';
    return Math.floor(s / 3600) + 'h';
  }
  function conn() {
    try { return !!SshBridge.isConnected(); } catch (e) { return false; }
  }
  function dotCls() {
    var d = root && root.querySelector('.wear-dot');
    if (d) d.className = 'wear-dot ' + (conn() ? 'on' : 'off');
  }

  function build(title, back) {
    root = document.createElement('div');
    root.id = 'wearRoot';
    root.setAttribute('data-screen', screenMode());
    root.innerHTML = '<div class="wear-head">'
      + (back ? '<button class="wear-back" id="wearBack">‹</button>' : '')
      + '<div class="wear-title">' + esc(title) + '</div>'
      + '<span class="wear-dot off"></span></div>'
      + '<div class="wear-scroll" id="wearScroll"></div>'
      + '<div class="wear-l3" id="wearL3">'
      + '<div class="wear-head"><button class="wear-back" id="wearL3Back">‹</button>'
        + '<div class="wear-title">Terminal</div></div>'
      + '<div class="wear-l3-body" id="wearL3Body"></div></div>';
    document.body.appendChild(root);
    bodyEl = root.querySelector('#wearScroll');
    l3El = root.querySelector('#wearL3');
    l3BodyEl = root.querySelector('#wearL3Body');
    var b = root.querySelector('#wearBack');
    if (b) b.addEventListener('click', function () { history.back(); });
    var b3 = root.querySelector('#wearL3Back');
    if (b3) b3.addEventListener('click', closeChooser);
  }

  function shellList() {
    try {
      var arr = JSON.parse(SshBridge.listShells() || '[]');
      return Array.isArray(arr) ? arr : [];
    } catch (e) { return []; }
  }
  function matchedShell(tty) {
    if (!tty) return null;
    var list = shellList();
    for (var i = 0; i < list.length; i++) {
      if (list[i] && list[i].tty === tty) return list[i];
    }
    return null;
  }
  function showChooserMsg(text) {
    l3BodyEl.innerHTML = '<div class="wear-empty">' + esc(text) + '</div>';
    l3El.classList.add('show');
  }
  function closeChooser() {
    l3El.classList.remove('show');
    l3BodyEl.innerHTML = '';
  }
  function jumpToShell(sh) {
    if (!sh || !sh.id) return;
    try {
      var r = JSON.parse(SshBridge.openTerminalShell(sh.id));
      if (!r || !r.ok) {
      showChooserMsg('Cannot open terminal: ' + (r && r.error ? r.error : 'unknown'));
      }
    } catch (e) {
      showChooserMsg('Terminal failed: ' + e.message);
    }
  }
  function openTermChooser() {
    var shells = shellList();
    if (!shells.length) {
      showChooserMsg('No terminal shells.');
      return;
    }
    if (shells.length === 1) { jumpToShell(shells[0]); return; }
    var html = '';
    shells.forEach(function (sh) {
      html += '<div class="wear-term-row" data-id="' + esc(sh.id) + '">'
        + '<span class="tn">' + esc(sh.name || sh.id) + '</span>'
        + '<span class="ts' + (sh.status === 'closed' ? ' closed' : '') + '">'
        + (sh.status === 'closed' ? 'closed' : 'running') + '</span></div>';
    });
    l3BodyEl.innerHTML = html;
    var th = l3El.querySelector('.wear-title');
    if (th) th.textContent = 'Select terminal';
    l3El.classList.add('show');
    l3BodyEl.querySelectorAll('.wear-term-row').forEach(function (row) {
      row.addEventListener('click', function () {
        var id = row.getAttribute('data-id');
        var found = null;
        shells.forEach(function (sh) { if (sh.id === id) found = sh; });
        closeChooser();
        jumpToShell(found);
      });
    });
  }
  function rowJump(r) {
    if (!BASE || !r) return;
    var sh = matchedShell((r.details && r.details.tty) || '');
    if (sh && r.isActive) { jumpToShell(sh); return; }
    var ws = (r.details && r.details.workspace) || '';
    var cmd = BASE.resumeCmd(r.agent, r.sessionId);
    if (ws || cmd) {
      try {
        // Through the shared hook: it also remembers the resume, so the row stops offering
        // Resume while the resumed agent starts up.
        BASE.shellHooks().openShellWith(ws || '', cmd);
      } catch (e) {
      showChooserMsg('Resume failed: ' + e.message);
      }
      return;
    }
    openTermChooser();
  }

  function summaryOf(r) {
    var d = r.details || {};
    // Summarizer shows the LLM summary (d.summary) only, never the monitoring text
    return (d.summary && d.summary.headline) || '';
  }

  function renderHome() {
    if (!conn()) {
    bodyEl.innerHTML = '<div class="wear-empty">SSH not connected.</div>';
      return;
    }
    if (!Driver || !Agents) {
      bodyEl.innerHTML = '<div class="wear-empty">Data layer not ready.</div>';
      return;
    }
    var rs = Driver.rows();
    if (!rs.length) {
      lastHomeFp = '';
      bodyEl.innerHTML = '<div class="wear-empty">No summaries.</div>';
      return;
    }
    var fp = JSON.stringify(rs.map(function (r) {
      var sm = (r.details && r.details.summary) || null;
      return [r.agent, r.sessionId, r.key, r.lastActiveMs,
        sm ? [sm.headline, sm.next, (sm.outcome || []).join('|'),
          sm.updatedAt, sm.toolCalls].join('\u0001') : ''];
    }));
    if (fp === lastHomeFp) return;
    lastHomeFp = fp;
    var groups = {};
    rs.forEach(function (r) {
      groups[r.agent] = (groups[r.agent] || 0) + 1;
      r.__n = groups[r.agent];
    });
    var html = '';
    rs.forEach(function (r) {
      var name = groups[r.agent] > 1
        ? (r.agent + ' #' + r.__n) : (r.name || r.agent);
      var sum = summaryOf(r);
      var st = BASE.stateUI(r.state || 'idle');
      html += '<div class="wear-row" data-key="' + esc(r.key || '')
        + '" data-agent="' + esc(r.agent || '')
        + '" data-sid="' + esc(r.sessionId || '') + '">'
        + '<span class="wear-stdot" style="background:' + st.color + '"></span>'
        + '<span class="wear-row-main"><span class="wear-row-name">'
        + esc(name) + (r.isActive ? ' ●' : '') + '</span>'
        + (sum
            ? '<div class="wear-headline">' + esc(cap(sum, 90)) + '</div>'
            : '<div class="wear-headline none">(no summary)</div>')
        + '</span>'
        + '<span class="wear-state" style="background:' + st.color + '">'
        + esc(st.label) + '</span>'
        + '<button class="wear-term" type="button">›_</button>'
        + '<button class="wear-term wear-arch" type="button">Arc</button></div>';
    });
    bodyEl.innerHTML = html;
    bodyEl.querySelectorAll('.wear-row').forEach(function (row) {
      var key = row.getAttribute('data-key');
      var agent = row.getAttribute('data-agent');
      var sid = row.getAttribute('data-sid');
      row.addEventListener('click', function () {
        location.href = 'index.html?agent=' + encodeURIComponent(agent)
          + '&session=' + encodeURIComponent(sid)
          + (key ? '&key=' + encodeURIComponent(key) : '');
      });
      var tb = row.querySelector('.wear-term');
      if (tb) {
        tb.addEventListener('click', function (e) {
          e.stopPropagation();
          var hit = null;
          rs.forEach(function (r) { if (r.key === key) hit = r; });
          rowJump(hit);
        });
      }
      var ab = row.querySelector('.wear-arch');
      if (ab) {
        ab.addEventListener('click', function (e) {
          e.stopPropagation();
          var hit = null;
          rs.forEach(function (r) { if (r.key === key) hit = r; });
          if (hit) Agents.archive(hit.agent, hit.sessionId);
          renderHome();
        });
      }
    });
  }

  function current() {
    if (!Driver || !Agents) return null;
    // Same as monitor: Driver.rows() triggers resolve, refreshing isActive / real tty /
    // shell match; without it a restored session cannot be located again.
    var rows = Driver.rows();
    if (!DETAIL) return rows[0] || null;
    if (!qSession && !qKey) return rows[0] || null;
    // First ?key= load merges the full card to learn agent/sessionId, then ensureFocus
    if (!qSession && qKey
        && (!Driver.cfg.focus || !Driver.cfg.focus.sessionId)) {
      var r0 = Driver.loadCard(null, null, qKey);
      if (r0 && r0.sessionId) {
        qAgent = r0.agent || '';
        qSession = r0.sessionId;
        Driver.cfg.focus = {
          agent: qAgent, sessionId: qSession,
          key: qKey, requireRaw: true
        };
      }
      return r0 || null;
    }
    if (!qSession) return rows[0] || null;
    return Driver.ensureFocus(true) || null;
  }

  function fpOf(c) {
    if (!c) return '';
    return JSON.stringify([c.agent, c.sessionId, c.state, c.lastActiveMs,
      c.details, c.raw]);
  }

  function renderDetail() {
    if (!conn()) {
      lastFp = '';
      bodyEl.innerHTML = '<div class="wear-empty">SSH not connected.</div>';
      return;
    }
    var c = current();
    var fp = fpOf(c);
    if (fp === lastFp) { dotCls(); return; }
    lastFp = fp;
    if (!c) {
      bodyEl.innerHTML = '<div class="wear-empty">Waiting for session cards…</div>';
      return;
    }
    if (Agents.isArchived(c.agent, c.sessionId)) {
      bodyEl.innerHTML = '<div class="wear-chiprow">'
        + '<span class="wear-chip" style="background:#555">archived</span></div>'
        + '<div class="wear-msgbox">Session archived.</div>'
        + '<div class="wear-actions"><button class="wear-termbtn" id="wearArchBtn" '
        + 'type="button">Unarchive</button></div>';
      var ub = bodyEl.querySelector('#wearArchBtn');
      if (ub) {
        ub.onclick = function () {
          Driver.unarchive(c.agent, c.sessionId, c.key);
          Driver.loadCard(c.agent, c.sessionId, c.key);
          renderDetail();
        };
      }
      return;
    }
    var d = c.details || {};
    root.querySelector('.wear-title').textContent =
      'Summary · ' + (c.name || c.agent || 'agent');
    // LLM summary only: state/tools/raw text/counts belong to Agent Monitor.
    var raw = c.raw || null;
    var sem = d.summary || (raw && raw.semantic) || null;
    var st = BASE.stateUI(c.state || 'idle');
    var chips = '<span class="wear-chip" style="background:' + st.color + '">'
      + '<span class="wear-stdot" style="background:#fff"></span>'
      + esc(st.label) + '</span>'
      + (c.isActive ? '<span class="wear-chip">live</span>' : '')
      + ((sem && sem.updatedAt)
      ? '<span class="wear-chip ago">' + ago(sem.updatedAt) + ' ago</span>'
      : (c.lastActiveMs ? '<span class="wear-chip ago">' + ago(c.lastActiveMs)
        + ' ago</span>' : ''));
    if (sem && sem.toolCalls) {
      chips += '<span class="wear-chip ago">tools ' + sem.toolCalls + '</span>';
    }
    var h = '<div class="wear-chiprow">' + chips + '</div>';
    if (sem && sem.headline) {
      h += '<div class="wear-msgbox">' + esc(sem.headline) + '</div>';
    }
    var outs = (sem && sem.outcome || []).slice(0, 4);
    if (outs.length) {
      h += '<div class="wear-grp"><div class="wear-grp-title">outcome</div>';
      outs.forEach(function (x) {
        h += '<div class="wear-item"><span class="ok">✓</span><span>'
          + esc(x) + '</span></div>';
      });
      h += '</div>';
    }
    if (sem && sem.next) {
      h += '<div class="wear-grp"><div class="wear-grp-title">next</div>'
        + '<div class="wear-item"><span class="nx">»</span><span>'
        + esc(sem.next) + '</span></div></div>';
    }
    if (!(sem && sem.headline) && !outs.length && !(sem && sem.next)) {
      h += '<div class="wear-empty">No summary yet.</div>';
    }
    h += '<div class="wear-actions"><button class="wear-termbtn" id="wearTermBtn" '
      + 'type="button">›_ Terminal</button>'
      + '<button class="wear-termbtn" id="wearArchBtn" type="button">Archive</button></div>';
    bodyEl.innerHTML = h;
    var tb = bodyEl.querySelector('#wearTermBtn');
    if (tb) tb.onclick = function () { rowJump(c); };
    var ab = bodyEl.querySelector('#wearArchBtn');
    if (ab) {
      ab.onclick = function () {
        Agents.archive(c.agent, c.sessionId);
        location.href = 'home.html';
      };
    }
    dotCls();
  }

  function tick() {
    ensureDriver();
    if (!root) return;
    if (Driver) Driver.tick();
    if (DETAIL) renderDetail();
    else renderHome();
  }

  var tries = 0;
  var iv = setInterval(function () {
    if (screenMode() === 'phone') {
      if (++tries > 60) clearInterval(iv);
      return;
    }
    clearInterval(iv);
    if (started) return;
    started = true;
    ensureDriver();
    try {
      var h = document.documentElement;
      if (h) {
        h.className = h.className.replace(/\bvm-boot\b/g, '')
          .replace(/\s+/g, ' ').trim();
      }
    } catch (e) {}
    if (DETAIL) build('Summary', true);
    else build('Summaries', false);
    tick();
    setInterval(tick, 1000);
  }, 150);
})();
